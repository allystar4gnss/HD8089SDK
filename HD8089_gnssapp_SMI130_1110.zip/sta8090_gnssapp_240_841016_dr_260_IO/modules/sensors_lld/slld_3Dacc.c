/*!
 * slld_3Dacc.c
 * Implements the basic driver blocks for a 3d accelerometer or a accelerometer in a combo.
 * Initialization, get message functions
 * \date 23/01/2017
 */

#include "gpOS.h"
#include "clibs.h"
#include "gnss_bsp_defs.h"
#include "slld_api.h"

#if defined(__linux__)
gnss_error_t slld_3Dacc_init( const tU8 bus_type, const tU8 SA0, const tU8 i2c_SlaveAd_conf, const slld_fifo_info_t fifo_info)
{
   return GNSS_NO_ERROR;
}

#else
#include "lld_gpio.h"
#include "svc_ssp.h"
#include "svc_i2c.h"
//#define DR_DEBUG
#include "gnss_debug.h"



svc_ssp_com_handler_t *                       slld_3D6Dacc_spi_com_hnd;
svc_i2c_com_handler_t *                       slld_3D6Dacc_i2c_com_hnd;
static boolean_t                              slld_3D6Dacc_initialized = FALSE;
tU8                                           slld_3D6Dacc_bus_type = SLLD_3D6DACC_SPI_BUS_TYPE;
static tU32                                   slld_3D6Dacc_cs_gpio_id = SLLD_3D6DACC_NOT_CONFIG;

tU8 slld_3D6Dacc_type = SLLD_ST_MEMS_3DACC_TYPE;

static tU8 slld_3Dacc_spi_read_command[7] = {SLLD_3DACC_SPI_READ_COMMAND_BYTE,0,0,0,0,0,0};
static tU8 slld_6Dacc_spi_read_command[7] = {SLLD_6DACC_SPI_READ_COMMAND_BYTE,0,0,0,0,0,0};
static tU8 slld_6Dacc_bosch_spi_read_command[7] = {SLLD_6DACC_BOSCH_SPI_READ_COMMAND_BYTE,0,0,0,0,0,0};

static tU8 *slld_acc_spi_read_command = (tU8*)slld_3Dacc_spi_read_command;

/* Prototypes */
gnss_error_t  slld_3Dacc_init_CtrlReg_spi (const slld_fifo_info_t);
gnss_error_t  slld_3Dacc_init_CtrlReg_i2c (const slld_fifo_info_t) ;
void          slld_3Dacc_spi_cs_enable    (void *);
void          slld_3Dacc_spi_cs_disable   (void *) ;
gnss_error_t  slld_3Dacc_setup            (const slld_fifo_info_t );


void slld_3Dacc_get_sample(slld_3Dacc_sample_t *sample)
{
  if(SLLD_3D6DACC_SPI_BUS_TYPE == slld_3D6Dacc_bus_type)
  {
     tU8 *in_buf_ptr;
     in_buf_ptr = (tU8 *)((tUInt)&sample->acc_3D_x_data - 1) ;

    if ( svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_acc_spi_read_command,7,in_buf_ptr,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_3Dacc] SPI read sample error!\r\n"));
    }
  }
  else
  {
     gpOS_clock_t timeout;
     tU8 slld_3D6Dacc_i2c_data[6]={0,0,0,0,0,0};

    switch (slld_3D6Dacc_type)
    {
     /* 3D acc ST Mems type */
     case SLLD_ST_MEMS_3DACC_TYPE:
      {
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_3D6DACC_OUT_X_L_ADDRESS|SLLD_3DACC_I2C_AUTO_INC_MASK, 1, slld_3D6Dacc_i2c_data, 6, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] I2c read error!\r\n"));
        }

        sample->acc_3D_x_data = ((tU16)slld_3D6Dacc_i2c_data[1]<<8)+ slld_3D6Dacc_i2c_data[0];
        sample->acc_3D_y_data = ((tU16)slld_3D6Dacc_i2c_data[3]<<8)+ slld_3D6Dacc_i2c_data[2];
        sample->acc_3D_z_data = ((tU16)slld_3D6Dacc_i2c_data[5]<<8)+ slld_3D6Dacc_i2c_data[4];
      }
      break;

      case SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE:
      case SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE:
      case SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE:
      case SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE:
      {
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_3D6DACC_OUT_X_L_ADDRESS, 1, slld_3D6Dacc_i2c_data, 6, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] I2c read error!\r\n"));
        }

        sample->acc_3D_x_data = ((tU16)slld_3D6Dacc_i2c_data[1]<<8)+ slld_3D6Dacc_i2c_data[0];
        sample->acc_3D_y_data = ((tU16)slld_3D6Dacc_i2c_data[3]<<8)+ slld_3D6Dacc_i2c_data[2];
        sample->acc_3D_z_data = ((tU16)slld_3D6Dacc_i2c_data[5]<<8)+ slld_3D6Dacc_i2c_data[4];

      }
      break;

      case SLLD_MEMS_6DACC_BMI160_TYPE:
      {
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_BMI160_ACC_OUT_X_L_ADDRESS, 1, slld_3D6Dacc_i2c_data, 6, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] I2c read error!\r\n"));
        }

        sample->acc_3D_x_data = ((tU16)slld_3D6Dacc_i2c_data[1]<<8)+ slld_3D6Dacc_i2c_data[0];
        sample->acc_3D_y_data = ((tU16)slld_3D6Dacc_i2c_data[3]<<8)+ slld_3D6Dacc_i2c_data[2];
        sample->acc_3D_z_data = ((tU16)slld_3D6Dacc_i2c_data[5]<<8)+ slld_3D6Dacc_i2c_data[4];

      }
      break;

      case SLLD_MEMS_6DACC_SMI130_TYPE:
      {
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_SMI130_ACC_OUT_X_L_ADDRESS, 1, slld_3D6Dacc_i2c_data, 6, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[dr_3Dacc] I2c read error!\r\n"));
        }

        sample->acc_3D_x_data = ((tU16)slld_3D6Dacc_i2c_data[1]<<4) | ((tU16)slld_3D6Dacc_i2c_data[0]>>4);
        /* If the value is negative, force the high part (bit12-15) to 1*/
        if ( (sample->acc_3D_x_data & (tU16)0x0800) != 0U )
        {
          sample->acc_3D_x_data |= (tU16)0xF000;
        }
        sample->acc_3D_y_data = ((tU16)slld_3D6Dacc_i2c_data[3]<<4) | ((tU16)slld_3D6Dacc_i2c_data[2]>>4);
        /* If the value is negative, force the high part (bit12-15) to 1*/
        if ( (sample->acc_3D_y_data & (tU16)0x0800) != 0U )
        {
          sample->acc_3D_y_data |= (tU16)0xF000;
        }

        sample->acc_3D_z_data = ((tU16)slld_3D6Dacc_i2c_data[5]<<4) | ((tU16)slld_3D6Dacc_i2c_data[4]>>4);
        /* If the value is negative, force the high part (bit12-15) to 1*/
        if ( (sample->acc_3D_z_data & (tU16)0x0800) != 0U )
        {
          sample->acc_3D_z_data |= (tU16)0xF000;
        }

        DR_DEBUG_MSG(("[slld_3Dacc] get sample SMI130 x=%0x, y=%0x z=%0x\r\n",
            sample->acc_3D_x_data, sample->acc_3D_y_data, sample->acc_3D_z_data));

      }
      break;

      default:
      {
        // impossible case
      }
      break;
    }

  }
  sample->acc_3D_cpu_time = gpOS_time_now();

  //DR_DEBUG_MSG(("[slld_3Dacc] sample->acc_3D_x_data:0x%x sample->acc_3D_y_data:0x%x sample->acc_3D_z_data:0x%x\r\n",sample->acc_3D_x_data,sample->acc_3D_y_data,sample->acc_3D_z_data));

}

void slld_3Dacc_get_fifo(slld_3Dacc_sample_t *sample, slld_fifo_msg_t* fifo_msg, const slld_fifo_info_t slld_fifo_info)
{
  //static gpOS_clock_t TimeNow = 0 ;
  tU16 unread_words_in_fifo =0U;
  tU16 i=0;
  gpOS_clock_t delta_time;
  tUInt fifo_pattern;

  /* Spi mode */
  tU8 *read_buf_rx_ptr;
  tU8 slld_3Dacc_spi_fifo_status_reg[5] = { (tU8)(SLLD_3D6DACC_READ_OPERATION| SLLD_COMBO_LSM6DS3_FIFO_STATUS1),0,0,0,0};
  tU8 slld_3Dacc_spi_fifo_status_reg_response[5];
  /* i2c mode */
  gpOS_clock_t timeout;
  tU8 slld_i2c_CtrlRgr[4];
  tU8 *slld_3D6Dacc_i2c_data=(tU8*)fifo_msg->fifo_buf;

  tU8 *slld_StatusRegister;
  tU8 read_buf_tx_ptr;

  read_buf_rx_ptr = (tU8 *)((tUInt)fifo_msg->fifo_buf - 1) ;

  //DR_DEBUG_MSG(("[dr_3Dacc] sampling delta cputime:%u\r\n",gpOS_time_minus(gpOS_time_now(),TimeNow)));
  //TimeNow = gpOS_time_now() ;


  if(SLLD_3D6DACC_SPI_BUS_TYPE == slld_3D6Dacc_bus_type)
  {
    // Read FIFO_STATUS1, FIFO_STATUS2, FIFO_STATUS3,, FIFO_STATUS4 register
    if ( svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3Dacc_spi_fifo_status_reg,5,slld_3Dacc_spi_fifo_status_reg_response,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_3Dacc] SPI read FIFO_STATUSx error!\r\n"));
      slld_StatusRegister[0] = 0U;
      slld_StatusRegister[1] = 0U;
    }
    else
    {
      //DR_DEBUG_MSG(("[dr_3Dacc] FIFO_STATUS1:0x%x\r\n",slld_3Dacc_spi_fifo_status_reg_response[1]));
      //DR_DEBUG_MSG(("[dr_3Dacc] FIFO_STATUS2:0x%x\r\n",slld_3Dacc_spi_fifo_status_reg_response[2]));

      slld_StatusRegister = (tU8*)&slld_3Dacc_spi_fifo_status_reg_response[1];
    }
  }
  else
  {
    // Read FIFO_STATUS1, FIFO_STATUS2, FIFO_STATUS3,, FIFO_STATUS4 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_STATUS1, 1, slld_i2c_CtrlRgr, 4, &timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_3Dacc] I2c read FIFO_STATUSx error!\r\n"));
      slld_StatusRegister[0] = 0U;
      slld_StatusRegister[1] = 0U;
    }
    else
    {
      //DR_DEBUG_MSG(("[slld_3Dacc] FIFO_STATUS1:0x%x\r\n",slld_i2c_CtrlRgr[0]));
      //DR_DEBUG_MSG(("[slld_3Dacc] FIFO_STATUS2:0x%x\r\n",slld_i2c_CtrlRgr[1]));

      slld_StatusRegister = (tU8*)&slld_i2c_CtrlRgr[0];
    }
  }

  /* If the Fifo is empty */
  if  ( (slld_StatusRegister[1] & SLLD_COMBO_LSM6DS3_FIFO_EMPTY_MASK) == SLLD_COMBO_LSM6DS3_FIFO_EMPTY_MASK )
  {
    DR_DEBUG_MSG(("[slld_3Dacc] Fifo Empty!\r\n"));
  }

  /* If FTH max is reached */
  if  ( (slld_StatusRegister[1] & SLLD_COMBO_LSM6DS3_FIFO_FTH_MASK) == SLLD_COMBO_LSM6DS3_FIFO_FTH_MASK )
  {
    DR_DEBUG_MSG(("[slld_3Dacc] FTH max reached!\r\n"));
  }

  /* If Fifo full */
  if  ( (slld_StatusRegister[1] & SLLD_COMBO_LSM6DS3_FIFO_FULL_MASK) == SLLD_COMBO_LSM6DS3_FIFO_FULL_MASK )
  {
    DR_DEBUG_MSG(("[slld_3Dacc] Fifo full !\r\n"));
  }

  /* If an overrun occurs on the Fifo */
  if  ( (slld_StatusRegister[1] & SLLD_COMBO_LSM6DS3_FIFO_OVERRUN_MASK) == SLLD_COMBO_LSM6DS3_FIFO_OVERRUN_MASK )
  {
    DR_DEBUG_MSG(("[slld_3Dacc] Fifo overrun!\r\n"));
  }

  /* number of read words in FIFO_STATUS1 and FIFO_STATUS2 */
  unread_words_in_fifo =  ( (tU16)((tU16)slld_StatusRegister[1]<<8)+ (tU16)slld_StatusRegister[0] ) & 0x0FFFU  ;
  DR_DEBUG_MSG(("[slld_3Dacc] number of words in Fifo:%u\r\n",unread_words_in_fifo));
  /* pattern x, y, z in FIFO_STATUS3 and FIFO_STATUS4 */
  fifo_pattern =  ((tU16)slld_StatusRegister[3]<<8)+ (tU16)slld_StatusRegister[2];

  if(SLLD_3D6DACC_SPI_BUS_TYPE == slld_3D6Dacc_bus_type)
  {
    /* Read the acc Fifo */
    read_buf_tx_ptr  = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_LSM6DS3_FIFO_DATA_OUT_L);
    if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,(tU8*)&read_buf_tx_ptr,(tU32)((unread_words_in_fifo*2) +1U) ,read_buf_rx_ptr,NULL) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_3Dacc] SPI read FIFO error!\r\n"));
    }
  }
  else
  {
    // Read The FIFO
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, (tU32)SLLD_COMBO_LSM6DS3_FIFO_DATA_OUT_L, 1U, slld_3D6Dacc_i2c_data, (tU32)(unread_words_in_fifo*2), &timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_3Dacc] I2c read FIFO error!\r\n"));
    }
  }

  /* If there are at least 3 elements in the FIFO */
  /* and the first element in FIFO is X */
  /* In general the first element in FIFO is x. Otherwise this is an error case */
  /* and there is a multiple of 3 elements in the FIFO (=normal case)*/
  if ( (unread_words_in_fifo >=3U) && (fifo_pattern==0U) && (( unread_words_in_fifo%3U) == 0U))
  {
    tU32 x=0U,y=0U,z=0U;

    sample->acc_3D_cpu_time = gpOS_time_now();

    for (i=unread_words_in_fifo; i>=3U; i=i-3U)
    {
      z += (tU32)fifo_msg->fifo_buf[i-1U] ;
      y += (tU32)fifo_msg->fifo_buf[i-2U] ;
      x += (tU32)fifo_msg->fifo_buf[i-3U] ;
    }

    /* Make an average for x,y,z */
    sample->acc_3D_x_data = (tU16)( x/ (unread_words_in_fifo/3U));
    sample->acc_3D_y_data = (tU16)( y/ (unread_words_in_fifo/3U));
    sample->acc_3D_z_data = (tU16)( z/ (unread_words_in_fifo/3U));

  }
  else
  {
    /* Read OUT_X, OUT_Y, OUT_Z */
    slld_3Dacc_get_sample(sample);

    DR_DEBUG_MSG(("[slld_3dacc] error: incorrect fifo pattern/ number of fifo elements is not a multiple of 3\r\n "))
  }

  /*dr_fifo_info.dr_3DGyro_FiFoModeEn always FALSE; mode not supported yet */
  fifo_msg->fifo_pattern = DR_ACC_XYZ;
  fifo_msg->number_words_fifo_read = (tU8)unread_words_in_fifo;

  if (unread_words_in_fifo >=3U)
  {
    if (( unread_words_in_fifo%3U) != 0U)
      delta_time = ((slld_fifo_info.Decimation_Fifo_Acc*NAV_CPU_TICKS_PER_SECOND)/slld_fifo_info.odr_freq)*(unread_words_in_fifo/3U);
    else
      delta_time = ((slld_fifo_info.Decimation_Fifo_Acc*NAV_CPU_TICKS_PER_SECOND)/slld_fifo_info.odr_freq)*(unread_words_in_fifo/3U-1U);

    fifo_msg->first_elem_cpu_time = sample->acc_3D_cpu_time - delta_time;
  }
  else
  {
    fifo_msg->first_elem_cpu_time = sample->acc_3D_cpu_time;
  }

}


gnss_error_t slld_3Dacc_init_CtrlReg_spi(const slld_fifo_info_t slld_fifo_info)
{
  tU8 slld_3D6Dacc_spi_command[7];
  tU8 slld_3D6Dacc_spi_command_response[7];

  switch (slld_3D6Dacc_type)
  {
    /* 3D acc ST Mems type */
    case SLLD_ST_MEMS_3DACC_TYPE:
    {
      // Read CTRL_REG1 register
      slld_3D6Dacc_spi_command[0] = (tU8) (SLLD_3D6DACC_READ_OPERATION | SLLD_3DACC_CTRL_REG1);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI read CTRL_REG1 error!\r\n"));
      }

      // Write in the CTRL_REG1 register
      slld_3D6Dacc_spi_command[0] = SLLD_3DACC_CTRL_REG1;
      slld_3D6Dacc_spi_command[1] = (slld_3D6Dacc_spi_command_response[1] | SLLD_3DACC_NORNAL_MODE_ENABLE) & ~SLLD_3DACC_SELF_TEST_MODE_BIT;
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI write CTRL_REG1 error!\r\n"));
      }
    }
    break;


    // 6D COMBO ST Mems
    case SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE:
    {
      // Read CTRL3_C register
      slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_CTRL3_C);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI read CTRL3_C error!\r\n"));
      }

      // Write in the CTRL3_C register
      slld_3D6Dacc_spi_command[0] = SLLD_COMBO_CTRL3_C;
      // Configure the Multi Access; only when more than 8bits are programmed in read/write mode
      slld_3D6Dacc_spi_command[1] = ( slld_3D6Dacc_spi_command_response[1] & ~SLLD_COMBO_IF_ADD_INC & ~SLLD_COMBO_BDU_MASK) | SLLD_COMBO_IF_ADD_INC | SLLD_COMBO_BDU_MASK;
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI write CTRL3_C error!\r\n"));
      }


      if (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE)
      {
        // Read CTRL1_XL register
        slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_6DACC_CTRL1_XL);
        if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] SPI read CTRL1_XL error!\r\n"));
        }

        // Write in the CTRL1_XL register
        // ODR shall be the same for Accelerometer and gyro
        slld_3D6Dacc_spi_command[0] = SLLD_6DACC_CTRL1_XL;
        slld_3D6Dacc_spi_command[1] = (tU8)((tU8)((slld_3D6Dacc_spi_command_response[1] & ~SLLD_COMBO_ASM330LXH_ODR_MASK) | SLLD_COMBO_ASM330LXH_ODR_50Hz) & ~SLLD_COMBO_ASM330LXH_BW_SCAL_ODR_0 );
        if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] SPI write CTRL1_XL error!\r\n"));
        }

        // Read FIFO_CTRL register
        slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_ASM330LXH_FIFO_CTRL);
        if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] SPI read FIFO_CTRL error!\r\n"));
        }

        // Write in the FIFO_CTRL register
        // Configure the Bypass mode
        slld_3D6Dacc_spi_command[0] = SLLD_COMBO_ASM330LXH_FIFO_CTRL;
        slld_3D6Dacc_spi_command[1] = (slld_3D6Dacc_spi_command_response[1] & ~SLLD_COMBO_ASM330LXH_FIFO_MODE_MASK) ;
        if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] SPI write FIFO_CTRL error!\r\n"));
        }

      }
      else
      /* SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE */
      /* SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE */
      /* SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE */
        {
          /* Fifo Mode requested */
          // Write in the CTRL4_C register
          // Write in CTRL1_XL register for acc odr
          // Write in FIFO_CTRL1 register for number of elements in fifo
          // Write in FIFO_CTRL3 register for odr fifo decimation
          // Write in FIFO_CTRL5 register for Fifo mode
          if (slld_fifo_info.slld_3Dacc_FiFoModeEn == TRUE)
          {
            // Read MASTER_CONFIG register
            slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_LSM6DS3_MASTER_CONFIG);
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI read MASTER_CONFIG error!\r\n"));
            }

            // Write in MASTER_CONFIG register
            // reset DATA_VALID_SEL_FIFO and PASS_THROUGH_MODE; it is used for the sensor hub
            slld_3D6Dacc_spi_command[0] = SLLD_LSM6DS3_MASTER_CONFIG;
            slld_3D6Dacc_spi_command[1] = (tU8)(slld_3D6Dacc_spi_command_response[1] & ~SLLD_LSM6DS3_DATA_VALID_SEL_FIFO & ~SLLD_LSM6DS3_PATH_THROUGH_MODE & ~SLLD_LSM6DS3_START_CONFIG & ~SLLD_LSM6DS3_PUSLLD_UP_EN)   ;
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI write MASTER_CONFIG error!\r\n"));
            }

            if (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
            {
              // Read CTRL4_C register
              slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_CTRL4_C);
              if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dacc] SPI read CTRL4_C error!\r\n"));
              }

              // Write in CTRL4_C register
              // BW_SCAL_ODR set to 0 the BW depends on the ODR value
              slld_3D6Dacc_spi_command[0] = SLLD_COMBO_CTRL4_C;
              slld_3D6Dacc_spi_command[1] = ((slld_3D6Dacc_spi_command_response[1] & ~SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR & ~SLLD_COMBO_STOP_ON_FTH) | SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR | SLLD_COMBO_STOP_ON_FTH)  ;
              if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dacc] SPI write CTRL4_C error!\r\n"));
              }
            }

            // Read CTRL1_XL register
            slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_6DACC_CTRL1_XL);
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI read CTRL1_XL error!\r\n"));
            }

            // Write in CTRL1_XL register
            // ODR shall be the same for Accelerometer and gyro
            slld_3D6Dacc_spi_command[0] = SLLD_6DACC_CTRL1_XL;
            slld_3D6Dacc_spi_command[1] = (tU8)( (tU8)(slld_3D6Dacc_spi_command_response[1] & ~SLLD_COMBO_LSM6DS3_ODR_MASK) | ( (tU8)slld_fifo_info.odr_val.odr_fifo_LSM6DS3 << 4U) )  ;
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI write CTRL1_XL error!\r\n"));
            }

            // Write in FIFO_CTRL1 The number of bytes in the FIFO
            slld_3D6Dacc_spi_command[0] = SLLD_COMBO_LSM6DS3_FIFO_CTRL1;
            slld_3D6Dacc_spi_command[1] =  (tU8)(slld_fifo_info.number_elements_in_Fifo & 0xFFU);
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] SPI write FIFO_CTRL1 error!\r\n"));
            }

           // Write in FIFO_CTRL2
            slld_3D6Dacc_spi_command[0] = SLLD_COMBO_LSM6DS3_FIFO_CTRL2;
            if (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
            {
              slld_3D6Dacc_spi_command[1] =  (tU8)( (slld_fifo_info.number_elements_in_Fifo >>8) & 0xFU);
            }
            else
            /* DR_ST_MEMS_6DACC_LSM6DSM_TYPE*/
            {
              slld_3D6Dacc_spi_command[1] =  (tU8)( (slld_fifo_info.number_elements_in_Fifo >>8) & 0x7U);
            }

            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI write FIFO_CTRL2 error!\r\n"));
            }

           // Write in FIFO_CTRL3 register
            // Set the Decimation for ODR_FIFO Accelerometer and gyro
            slld_3D6Dacc_spi_command[0] = SLLD_COMBO_LSM6DS3_FIFO_CTRL3;
            slld_3D6Dacc_spi_command[1] = (slld_fifo_info.Decimation_Fifo_Acc |  (tU8)( slld_fifo_info.Decimation_Fifo_Gyro << 3U) ) ;
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI write FIFO_CTRL3 error!\r\n"));
            }

            // Write in FIFO_CTRL4 register
            slld_3D6Dacc_spi_command[0] = SLLD_COMBO_LSM6DS3_FIFO_CTRL4;
            if (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
            {
              slld_3D6Dacc_spi_command[1] = 0;
            }
            else
            {
              slld_3D6Dacc_spi_command[1] = SLLD_COMBO_STOP_ON_FTH << 7;
            }

            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI write FIFO_CTRL4 error!\r\n"));
            }

             // Write in FIFO_CTRL5 register
            // Configure the Fifo mode
            slld_3D6Dacc_spi_command[0] = SLLD_COMBO_LSM6DS3_FIFO_CTRL5;
            slld_3D6Dacc_spi_command[1] = ( (tU8)( (tU8)slld_fifo_info.odr_val.odr_fifo_LSM6DS3 << 3U) | SLLD_COMBO_LSM6DS3_FIFO_CONT_MODE ) ;
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI write FIFO_CTRL5 error!\r\n"));
            }

          }
          /* Fifo Mode not requested */
          else
          // Write in the CTRL4_C register
          // Write in CTRL1_XL register for acc odr
          // Write in FIFO_CTRL5 register for bypass mode
          {
            if (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
            {
              // Read CTRL4_C register
              slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_CTRL4_C);
              if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dacc] SPI read CTRL4_C error!\r\n"));
              }

              // Write in the CTRL4_C register
              // BW_SCAL_ODR set to 0 the BW depends on the ODR value
              slld_3D6Dacc_spi_command[0] = SLLD_COMBO_CTRL4_C;
              slld_3D6Dacc_spi_command[1] = (tU8)( (slld_3D6Dacc_spi_command_response[1] & ~SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR) | SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR)  ;
              if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dacc] SPI write CTRL4_C error!\r\n"));
              }
            }

            // Read CTRL1_XL register
            slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_6DACC_CTRL1_XL);
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI read CTRL1_XL error!\r\n"));
            }

            // Write in the CTRL1_XL register
            // ODR shall be the same for Accelerometer and gyro
            slld_3D6Dacc_spi_command[0] = SLLD_6DACC_CTRL1_XL;
            slld_3D6Dacc_spi_command[1] = (tU8)( (slld_3D6Dacc_spi_command_response[1] & ~SLLD_COMBO_LSM6DS3_ODR_MASK) | SLLD_COMBO_LSM6DS3_ODR_52Hz )  ;
            if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dacc] SPI write CTRL1_XL error!\r\n"));
            }

            /* SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE */
            /* SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE */
            if ( (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE) ||
                 (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE) )
            {
              // Read FIFO_CTRL5 register
              slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_LSM6DS3_FIFO_CTRL5);
              if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dacc] SPI read FIFO_CTRL5 error!\r\n"));
              }

              // Write in the FIFO_CTRL5 register
              // Configure the Bypass mode
              slld_3D6Dacc_spi_command[0] = SLLD_COMBO_LSM6DS3_FIFO_CTRL5;
              slld_3D6Dacc_spi_command[1] = (slld_3D6Dacc_spi_command_response[1] & ~SLLD_COMBO_LSM6DS3_BYPASS_MODE_MASK) ;
              if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dacc] SPI write FIFO_CTRL5 error!\r\n"));
              }
            }
          }
        }

      if (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
      {

        //Read CTRL9_XL register
        slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_6DACC_CTRL9_XL);
        if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] SPI read CTRL9_XL error!\r\n"));
        }
        // Write in the CTRL9_XL register
        slld_3D6Dacc_spi_command[0] = SLLD_6DACC_CTRL9_XL;
        slld_3D6Dacc_spi_command[1] = (tU8)(slld_3D6Dacc_spi_command_response[1] | SLLD_6DACC_ACC_XYZ_ENABLED);
        if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] SPI write CTRL9_XL error!\r\n"));
        }
      }


    }
    break;

    case SLLD_MEMS_6DACC_BMI160_TYPE:
    {

      GPS_DEBUG_MSG(("[l_l3Dacc] BMI160 recognized SPI mode \r\n"));

      // Write in the DR_COMBO_BMI160_CMD registers
      slld_3D6Dacc_spi_command[0] = SLLD_COMBO_BMI160_CMD_REGISTER;
      slld_3D6Dacc_spi_command[1] = SLLD_COMBO_BMI160_ACC_SET_PMU_NORMAL_MODE;
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI write DR_COMBO_BMI160_CMD_REGISTER error!\r\n"));
      }

       // Read the DR_COMBO_BMI160_ACC_CONF/DR_COMBO_BMI160_ACC_RANGE register
      slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_BMI160_ACC_CONF);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,3,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI read DR_COMBO_BMI160_ACC_CONF error!\r\n"));
      }

      // Set ACC_CONF register
      slld_3D6Dacc_spi_command[0] = SLLD_COMBO_BMI160_ACC_CONF;
      slld_3D6Dacc_spi_command[1] = (tU8)(SLLD_COMBO_BMI160_ACC_US_NORMAL | SLLD_COMBO_BMI160_ACC_BWP_NORMAL |  SLLD_COMBO_BMI160_ACC_ODR_50Hz) ;
      // Set ACC_RANGE register
      slld_3D6Dacc_spi_command[2] = (slld_3D6Dacc_spi_command_response[2] & SLLD_COMBO_BMI160_ACC_RANGE_RESET ) | SLLD_COMBO_BMI160_ACC_RANGE_FS_2G ;
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,3,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI write DR_COMBO_BMI160_ACC_CONF/DR_COMBO_BMI160_ACC_RANGE error!\r\n"));
      }

      // Read the DR_COMBO_BMI160_FIFO_CONFIG1
      slld_3D6Dacc_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_BMI160_FIFO_CONFIG1);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI read DR_COMBO_BMI160_ACC_CONF error!\r\n"));
      }

       // Set FIFO_CONFIG_1 register
      slld_3D6Dacc_spi_command[0] = SLLD_COMBO_BMI160_FIFO_CONFIG1;
      slld_3D6Dacc_spi_command[1] = (slld_3D6Dacc_spi_command_response[1] & SLLD_COMBO_BMI160_FIFO1_RES ) | SLLD_COMBO_BMI160_NO_FIFO ;
      DR_DEBUG_MSG(("[slld_3Dacc] SPI write DR_COMBO_BMI160_FIFO_CONFIG1 =0x%x\r\n",slld_3D6Dacc_spi_command[1]));
     // Write in the DR_COMBO_BMI160_FIFO_CONFIG1 register
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI write DR_COMBO_BMI160_FIFO_CONFIG1 error!\r\n"));
      }

    }
    break;

    default:
    {
     // Impossible case
    }
    break;
  }
  return GNSS_NO_ERROR;
}

gnss_error_t slld_3Dacc_init_CtrlReg_i2c(const slld_fifo_info_t slld_fifo_info)
{
  gpOS_clock_t timeout;
  gnss_error_t return_error= GNSS_NO_ERROR;

  switch (slld_3D6Dacc_type)
  {
    /* 3D acc ST Mems type */
    case SLLD_ST_MEMS_3DACC_TYPE:
    {
      tU8 slld_3Dacc_i2c_command_response;

      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_3DACC_CTRL_REG1, 1, &slld_3Dacc_i2c_command_response, 1, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] I2c read DR_3DACC_CTRL_REG1 error!\r\n"));
        return_error = GNSS_ERROR;
      }

      slld_3Dacc_i2c_command_response = (slld_3Dacc_i2c_command_response|SLLD_3DACC_NORNAL_MODE_ENABLE);
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_3DACC_CTRL_REG1, 1, &slld_3Dacc_i2c_command_response, 1, 1,&timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] I2c write DR_3DACC_CTRL_REG1 error!\r\n"));
        return_error = GNSS_ERROR;
      }
    }
    break;

    case SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE:
    {
      tU8 Ctrl3RegisterValue;
      tU8 CtrlRegisterValue[11];
      tU8 Ctrl1XlRegisterValue;
      tU8 Ctrl4CRegisterValue;
      tU8 CtrlFifoRegisterValue;
      tU8 Ctrl9XlRegisterValue;
      tU8 FifoCtrl1RegisterValue;
      tU8 FifoCtrl2RegisterValue;
      tU8 FifoCtrl3RegisterValue;
      tU8 FifoCtrl4RegisterValue;
      tU8 FifoCtrl5RegisterValue;
      tU8 CtrlMasterConfigRegister;

       /*read DR_COMBO_CTRL3_C*/
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_CTRL3_C, 1, &Ctrl3RegisterValue, 1, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[dr_3Dacc] I2c read DR_COMBO_CTRL3_C error!\r\n"));
        return_error = GNSS_ERROR;
      }

      // Configure CTRL3_C register to read several address and set BDU to 1 (output registers not updated until MSB and LSB have been read)
      Ctrl3RegisterValue = ( Ctrl3RegisterValue & ~SLLD_COMBO_IF_ADD_INC & ~SLLD_COMBO_BDU_MASK) | SLLD_COMBO_IF_ADD_INC | SLLD_COMBO_BDU_MASK;
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_CTRL3_C, 1, &Ctrl3RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_COMBO_CTRL3_C error!\r\n"));
        return_error = GNSS_ERROR;
      }

      // Read other CTRL registers
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_6DACC_CTRL1_XL, 1, &CtrlRegisterValue[0], 11, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[dr_3Dacc] I2c read CTRL register error!\r\n"));
        return_error = GNSS_ERROR;
      }

      if (slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE)
      {
        /* Output Data Rate set to 50Hz in DR_6DACC_CTRL1_XL */
        Ctrl1XlRegisterValue = CtrlRegisterValue[0];
        Ctrl1XlRegisterValue = (tU8)((Ctrl1XlRegisterValue & ~SLLD_COMBO_ASM330LXH_ODR_MASK & ~SLLD_COMBO_ASM330LXH_BW_SCAL_ODR_0) | SLLD_COMBO_ASM330LXH_ODR_50Hz) ;
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_6DACC_CTRL1_XL, 1, &Ctrl1XlRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_6DACC_CTRL1_XL error!\r\n"));
          return_error = GNSS_ERROR;
        }

        /* Select the Bypass mode in FIFO_CTRL*/
        CtrlFifoRegisterValue = CtrlRegisterValue[10];
        CtrlFifoRegisterValue = (CtrlFifoRegisterValue & ~SLLD_COMBO_ASM330LXH_FIFO_MODE_MASK);
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_ASM330LXH_FIFO_CTRL, 1, &CtrlFifoRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_COMBO_ASM330LXH_FIFO_CTRL error!\r\n"));
          return_error = GNSS_ERROR;
        }

      }
      else
      /* DR_ST_MEMS_6DACC_LSM6DS3_TYPE */
      /* DR_ST_MEMS_6DACC_LSM6DSM_TYPE */
      /* SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE */
       {
            // If FIFO enabled for acc data
          if (slld_fifo_info.slld_3Dacc_FiFoModeEn == TRUE)
          {
            // Write in MASTER_CONFIG register
            // reset DATA_VALID_SEL_FIFO and PASS_THROUGH_MODE; it is used for the sensor hub
            CtrlMasterConfigRegister = CtrlRegisterValue[10];
            CtrlMasterConfigRegister = (CtrlMasterConfigRegister & ~SLLD_LSM6DS3_DATA_VALID_SEL_FIFO & ~SLLD_LSM6DS3_PATH_THROUGH_MODE & ~SLLD_LSM6DS3_START_CONFIG & ~SLLD_LSM6DS3_PUSLLD_UP_EN);
            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_LSM6DS3_MASTER_CONFIG, 1, &CtrlMasterConfigRegister, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_LSM6DS3_MASTER_CONFIG error!\r\n"));
              return_error = GNSS_ERROR;
            }

            if ( slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
            {
              /* BW ODR SCAL set to 0 in CTRL4_C , follows the ODR value*/
              Ctrl4CRegisterValue = CtrlRegisterValue[3];
              Ctrl4CRegisterValue = (Ctrl4CRegisterValue & ~SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR & ~SLLD_COMBO_STOP_ON_FTH) | SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR | SLLD_COMBO_STOP_ON_FTH ;
              timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
              if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_CTRL4_C, 1, &Ctrl4CRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_COMBO_CTRL4_C error!\r\n"));
                return_error = GNSS_ERROR;
              }
            }

            /* Output Data Rate set to dr_fifo_info.odr_val in DR_6DACC_CTRL1_XL*/
            Ctrl1XlRegisterValue = CtrlRegisterValue[0];
            Ctrl1XlRegisterValue = ( (Ctrl1XlRegisterValue & ~SLLD_COMBO_LSM6DS3_ODR_MASK) | (tU8)( (tU8)slld_fifo_info.odr_val.odr_fifo_LSM6DS3 << 4U)) ;
            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_6DACC_CTRL1_XL, 1, &Ctrl1XlRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_6DACC_CTRL1_XL error!\r\n"));
              return_error = GNSS_ERROR;
            }

            // Write in FIFO_CTRL1 registerThe number of bytes in the FIFO
            FifoCtrl1RegisterValue = (tU8)(slld_fifo_info.number_elements_in_Fifo & 0xFFU) ;
            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL1, 1, &FifoCtrl1RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_COMBO_LSM6DS3_FIFO_CTRL1 error!\r\n"));
              return_error = GNSS_ERROR;
            }

            // Write in FIFO_CTRL2 register
            if ( slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
            {
              FifoCtrl2RegisterValue =  (tU8)( (slld_fifo_info.number_elements_in_Fifo >>8) & 0xFU);
            }
            else
            /*DR_ST_MEMS_6DACC_LSM6DSM_TYPE*/
            {
              FifoCtrl2RegisterValue =  (tU8)( (slld_fifo_info.number_elements_in_Fifo >>8) & 0x7U);
            }

            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL2, 1, &FifoCtrl2RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] I2c write SLLD_COMBO_LSM6DS3_FIFO_CTRL2 error!\r\n"));
              return_error = GNSS_ERROR;
            }
            // Write in FIFO_CTRL3 register
            // Set the Decimation for ODR_FIFO Accelerometer and gyro
            FifoCtrl3RegisterValue = (slld_fifo_info.Decimation_Fifo_Acc |  (tU8)( slld_fifo_info.Decimation_Fifo_Gyro << 3U) ) ;
            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL3, 1, &FifoCtrl3RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_COMBO_LSM6DS3_FIFO_CTRL3 error!\r\n"));
              return_error = GNSS_ERROR;
            }

            // Write in FIFO_CTRL4 register
            if ( slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
            {
              FifoCtrl4RegisterValue = 0 ;
            }
            else
              /*DR_ST_MEMS_6DACC_LSM6DSM_TYPE*/
            {
              FifoCtrl4RegisterValue = SLLD_COMBO_STOP_ON_FTH << 7 ;
            }

            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL4, 1, &FifoCtrl4RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] I2c write SLLD_COMBO_LSM6DS3_FIFO_CTRL4 error!\r\n"));
              return_error = GNSS_ERROR;
            }

            // Configure FIFO_CTRL5 register
            // Configure the Fifo Mode Continuous
            FifoCtrl5RegisterValue = (tU8)( ( (tU8)slld_fifo_info.odr_val.odr_fifo_LSM6DS3 << 3U) | SLLD_COMBO_LSM6DS3_FIFO_CONT_MODE ) ;
            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL5, 1, &FifoCtrl5RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_COMBO_LSM6DS3_FIFO_CTRL5 error!\r\n"));
              return_error = GNSS_ERROR;
            }
          }
          /* Fifo Mode not requested */
          else
          {
            if ( slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
            {
              /* BW ODR SCAL set to 0 in CTRL4_C , follows the ODR value*/
              Ctrl4CRegisterValue = CtrlRegisterValue[3];
              Ctrl4CRegisterValue = (Ctrl4CRegisterValue & ~SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR ) | SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR  ;
              timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
              if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_CTRL4_C, 1, &Ctrl4CRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_COMBO_CTRL4_C error!\r\n"));
                return_error = GNSS_ERROR;
              }
            }

             /* Output Data Rate set to 50Hz in DR_6DACC_CTRL1_XL*/
            Ctrl1XlRegisterValue = CtrlRegisterValue[0];
            Ctrl1XlRegisterValue = (tU8)( (Ctrl1XlRegisterValue & ~SLLD_COMBO_LSM6DS3_ODR_MASK) | SLLD_COMBO_LSM6DS3_ODR_52Hz) ;
            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_6DACC_CTRL1_XL, 1, &Ctrl1XlRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_6DACC_CTRL1_XL error!\r\n"));
              return_error = GNSS_ERROR;
            }

            if ( ( slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)  ||
               ( slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE) )
            {
              // read FIFO_CTRL5
              timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
              if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL5, 1, &FifoCtrl5RegisterValue, 1, &timeout) == gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dacc] I2c read DR_COMBO_LSM6DS3_FIFO_CTRL5 error!\r\n"));
                return_error = GNSS_ERROR;
              }

              // Configure FIFO_CTRL5 register
              // Configure the Bypass mode
              FifoCtrl5RegisterValue &= ~SLLD_COMBO_LSM6DS3_BYPASS_MODE_MASK;
              timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
              if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL5, 1, &FifoCtrl5RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dacc] I2c write DR_COMBO_LSM6DS3_FIFO_CTRL5 error!\r\n"));
                return_error = GNSS_ERROR;
              }
            }
         }

        }

      if ( slld_3D6Dacc_type == SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE)
      {
        // Configure the CTRL9_Xl register
        Ctrl9XlRegisterValue = CtrlRegisterValue[8];
        Ctrl9XlRegisterValue = Ctrl9XlRegisterValue | SLLD_6DACC_ACC_XYZ_ENABLED;
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_6DACC_CTRL9_XL, 1, &Ctrl9XlRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dacc] I2c write DR_6DACC_CTRL9_XL error!\r\n"));
          return_error = GNSS_ERROR;
        }
      }

    }
    break;

    case SLLD_MEMS_6DACC_BMI160_TYPE:
    {
      tU8 AccCtrlRegister[8];
      tU8 FifoConfig1Register;
      tU8 CmdRegisterValue = SLLD_COMBO_BMI160_ACC_SET_PMU_NORMAL_MODE;

      GPS_DEBUG_MSG(("[dr_3Dacc] BMI160 recognized I2c mode \r\n"));

      // Write in the DR_COMBO_BMI160_CMD registers
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_BMI160_CMD_REGISTER, 1, &CmdRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[dr_3Dacc] I2c write DR_COMBO_BMI160_CMD_REGISTER error!\r\n"));
        return_error = GNSS_ERROR;
      }

      // Read the Ctrl registers for Acc
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_BMI160_ACC_CONF, 1, &AccCtrlRegister[0], 8, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[dr_3Dacc] I2c read CTRL register error!\r\n"));
        return_error = GNSS_ERROR;
      }


      // Set ACC_CONF register
      AccCtrlRegister[0] = (tU8)(SLLD_COMBO_BMI160_ACC_US_NORMAL | SLLD_COMBO_BMI160_ACC_BWP_NORMAL |  SLLD_COMBO_BMI160_ACC_ODR_50Hz);
      // Set GYR_RANGE register
      AccCtrlRegister[1] = (AccCtrlRegister[1] & SLLD_COMBO_BMI160_ACC_RANGE_RESET ) | SLLD_COMBO_BMI160_ACC_RANGE_FS_2G ;

      // Set FIFO_CONFIG_1 register
      FifoConfig1Register = (AccCtrlRegister[7] & SLLD_COMBO_BMI160_FIFO1_RES ) | SLLD_COMBO_BMI160_NO_FIFO ;

      // Write in the DR_COMBO_BMI160_ACC_CONF/DR_COMBO_BMI160_ACC_RANGE registers
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_BMI160_ACC_CONF, 1, &AccCtrlRegister[0], 2, 2,&timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] I2c write DR_COMBO_BMI160_ACC_CONF/DR_COMBO_BMI160_ACC_RANGE error!\r\n"));
        return_error = GNSS_ERROR;
      }

      // Write in the DR_COMBO_BMI160_FIFO_CONFIG1 register
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_BMI160_FIFO_CONFIG1, 1, &FifoConfig1Register, 1, 1,&timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] I2c write DR_COMBO_BMI160_FIFO_CONFIG1 error!\r\n"));
        return_error = GNSS_ERROR;
      }

    }
    break;

   case SLLD_MEMS_6DACC_SMI130_TYPE:
    {
      tU8 AccCtrlRegisterValue;

      GPS_DEBUG_MSG(("[slld_3Dacc] SMI130 recognized I2c mode \r\n"));

      // Write in the DR_SMI130_ACC_RANGE registers
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      AccCtrlRegisterValue = SLLD_SMI130_ACC_RANGE_FS_2G;
      if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_SMI130_ACC_RANGE, 1, &AccCtrlRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] I2c write SLLD_SMI130_ACC_RANGE error!\r\n"));
        return_error = GNSS_ERROR;
      }

      // Write in DR_SMI130_ACC_BW
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      AccCtrlRegisterValue = SLLD_SMI130_ACC_BW_MAX;
      if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_SMI130_ACC_BW, 1, &AccCtrlRegisterValue, 1, 1, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] I2c Write SLLD_SMI130_ACC_BW register error!\r\n"));
        return_error = GNSS_ERROR;
      }

      // Write in DR_SMI130_ACC_HBW
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      AccCtrlRegisterValue = (tU8) (SLLD_SMI130_ACC_HBW_FILT | SLLD_SMI130_ACC_HBW_SHADOW_EN);
      if( svc_i2c_write( slld_3D6Dacc_i2c_com_hnd, SLLD_SMI130_ACC_HBW, 1, &AccCtrlRegisterValue, 1, 1, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] I2c Write SLLD_SMI130_ACC_HBW register error!\r\n"));
        return_error = GNSS_ERROR;
      }

    }
    break;

    default:
    // unknown type
    {
      return_error = GNSS_ERROR;
    }
    break;
  }
  return return_error;
}

gnss_error_t slld_3Dacc_setup(const slld_fifo_info_t fifo_info)
{
  if(SLLD_3D6DACC_SPI_BUS_TYPE == slld_3D6Dacc_bus_type)
  {
    tU8 slld_3D6Dacc_spi_command = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_3D6DACC_WHO_AM_I);
    tU8 slld_3D6Dacc_spi_command_response[2];

    if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,&slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_3Dacc] SPI read WHO_AM_I error!\r\n"));
    }


    if ( (slld_3D6Dacc_spi_command_response[1] == SLLD_3DACC_ID) ||
         (slld_3D6Dacc_spi_command_response[1] == SLLD_3DACC_ID_1)  ||
         (slld_3D6Dacc_spi_command_response[1] == SLLD_6DACC_ASM330LXH_ID) ||
         (slld_3D6Dacc_spi_command_response[1] == SLLD_6DACC_LSM6DS3_ID)  ||
         (slld_3D6Dacc_spi_command_response[1] == SLLD_6DACC_LSM6DSM_ID) ||
         (slld_3D6Dacc_spi_command_response[1] == SLLD_6DACC_LSM6DSR_ID))
    {

      DR_DEBUG_MSG(("[slld_3Dacc] ID 0x%01x\r\n",slld_3D6Dacc_spi_command_response[1]));

      switch ( slld_3D6Dacc_spi_command_response[1])
      {
        /* 3D acc ST Mems type */
        case SLLD_3DACC_ID:
        case SLLD_3DACC_ID_1:
        {
          slld_3D6Dacc_type = SLLD_ST_MEMS_3DACC_TYPE;
          slld_acc_spi_read_command = (tU8*)slld_3Dacc_spi_read_command;
        }
        break;

        /* 6D acc ST Mems type */
        case SLLD_6DACC_ASM330LXH_ID:
        {
          slld_3D6Dacc_type = SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE;
          slld_acc_spi_read_command = (tU8*)slld_6Dacc_spi_read_command;
        }
        break;

        /* 6D acc ST Mems type */
        case SLLD_6DACC_LSM6DS3_ID:
        {
          /* 6D acc ST Mems type */
          slld_3D6Dacc_type = SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE;
          slld_acc_spi_read_command = (tU8*)slld_6Dacc_spi_read_command;
        }
        break;

        /* 6D acc ST Mems type */
        case SLLD_6DACC_LSM6DSM_ID:
        {
          /* 6D acc ST Mems type */
          slld_3D6Dacc_type = SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE;
          slld_acc_spi_read_command = (tU8*)slld_6Dacc_spi_read_command;
        }
        break;

         /* 6D acc ST Mems type */
        case SLLD_6DACC_LSM6DSR_ID:
        {
          /* 6D acc ST Mems type */
          slld_3D6Dacc_type = SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE;
          slld_acc_spi_read_command = (tU8*)slld_6Dacc_spi_read_command;
        }
        break;

        default:
        {
          // Impossible case
        }
        break;
      }
    }
    /* Other components */
    else
    {
      slld_3D6Dacc_spi_command = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_CHIPID_REGISTER);

      /* Read Other Who Am I register */
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,&slld_3D6Dacc_spi_command,2,slld_3D6Dacc_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] SPI read CHIP_ID register error!\r\n"));
      }

      DR_DEBUG_MSG(("[slld_3Dacc] SPI ID 0x%01x\r\n",slld_3D6Dacc_spi_command_response[1]));

      /* 6D acc BMI160 type */
      if (slld_3D6Dacc_spi_command_response[1] == SLLD_COMBO_ID_BMI160)
      {
        slld_3D6Dacc_type = SLLD_MEMS_6DACC_BMI160_TYPE;
        slld_acc_spi_read_command = (tU8*)slld_6Dacc_bosch_spi_read_command;
      }
      else
      {
        DR_DEBUG_MSG(("[slld_3Dacc] Device not recognized!\r\n"));
        return GNSS_ERROR;
      }
    }

    return slld_3Dacc_init_CtrlReg_spi(fifo_info);

  }
  else
  {
    tU8 slld_3Dacc_i2c_command_response[1] = {0};
    gpOS_clock_t timeout;

    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());

    if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_3D6DACC_WHO_AM_I, 1, &slld_3Dacc_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_3Dacc] I2c read SLLD_3D6DACC_WHO_AM_I error!\r\n"));
      return GNSS_ERROR;
    }

    /* If ST Mems */
    if ( (slld_3Dacc_i2c_command_response[0] == SLLD_3DACC_ID) ||
         (slld_3Dacc_i2c_command_response[0] == SLLD_3DACC_ID_1) ||
         (slld_3Dacc_i2c_command_response[0] == SLLD_6DACC_ASM330LXH_ID) ||
         (slld_3Dacc_i2c_command_response[0] == SLLD_6DACC_LSM6DS3_ID) ||
         (slld_3Dacc_i2c_command_response[0] == SLLD_6DACC_LSM6DSM_ID) ||
         (slld_3Dacc_i2c_command_response[0] == SLLD_6DACC_LSM6DSR_ID))
    {
      DR_DEBUG_MSG(("[slld_3Dacc] ID 0x%01x\r\n",slld_3Dacc_i2c_command_response[0]));

      switch ( slld_3Dacc_i2c_command_response[0] )
      {
        case SLLD_3DACC_ID:
        case SLLD_3DACC_ID_1:
        {
          /* 3D acc ST Mems type */
          slld_3D6Dacc_type = SLLD_ST_MEMS_3DACC_TYPE;
        }
        break;

        case SLLD_6DACC_ASM330LXH_ID:
        {
          /* 6D acc ST Mems type */
          slld_3D6Dacc_type = SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE;
        }
        break;

        case SLLD_6DACC_LSM6DS3_ID:
        {
          /* 6D acc ST Mems type */
          slld_3D6Dacc_type = SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE;
        }
        break;

        case SLLD_6DACC_LSM6DSM_ID:
        {
          /* 6D acc ST Mems type */
          slld_3D6Dacc_type = SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE;
        }
        break;

        case SLLD_6DACC_LSM6DSR_ID:
        {
          /* 6D acc ST Mems type */
          slld_3D6Dacc_type = SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE;
        }
        break;

        default:
        {
          // Impossible case
        }
        break;
      }
    }
    /* Other components */
    else
    {
      // Read other WHO_AMI_I register
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_CHIPID_REGISTER, 1, &slld_3Dacc_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dacc] I2c SLLD_COMBO_CHIP_REGISTER read error!\r\n"));
        return GNSS_ERROR;
      }

      DR_DEBUG_MSG(("[slld_3Dacc] I2c ID 0x%01x\r\n",slld_3Dacc_i2c_command_response[0]));

      switch (slld_3Dacc_i2c_command_response[0])
      {
        case SLLD_COMBO_ID_BMI160:
        {
          /* 6D acc BMI160 type */
          slld_3D6Dacc_type = SLLD_MEMS_6DACC_BMI160_TYPE;
        }
        break;

        case SLLD_ACC_ID_SMI130:
        {
          /* 6D acc SMI130 type */
          slld_3D6Dacc_type = SLLD_MEMS_6DACC_SMI130_TYPE;
        }
        break;

        default:
        {
          DR_DEBUG_MSG(("[slld_3Dacc] Device not recognized!\r\n"));
          return GNSS_ERROR;
        }
        break;
      }

    }

    return slld_3Dacc_init_CtrlReg_i2c(fifo_info);
  }
}

void slld_3Dacc_spi_cs_enable(void *par)
{
  if(SLLD_3D6DACC_NOT_CONFIG == slld_3D6Dacc_cs_gpio_id)
  {
     LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SLLD_3DACC_SPI_GPIO_ADDR,(LLD_GPIO_PinTy)SLLD_3DACC_SPI_CS_PIN);
  }
  else
  { /* TO DO: GPIO ID management for N ports target */
    if(slld_3D6Dacc_cs_gpio_id < SLLD_3D6DACC_GPIO0_LAST_CH)
    {
       LLD_GPIO_SetStateLow((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (LLD_GPIO_PinTy) (1U << slld_3D6Dacc_cs_gpio_id));
    }
    else
      if(slld_3D6Dacc_cs_gpio_id < SLLD_3D6DACC_GPIO1_LAST_CH)
      {
       LLD_GPIO_SetStateLow((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << (slld_3D6Dacc_cs_gpio_id-32U)));
      }
      else
      {
       // Impossible case
      }
  }
}

void slld_3Dacc_spi_cs_disable(void *par)
{
  if(SLLD_3D6DACC_NOT_CONFIG == slld_3D6Dacc_cs_gpio_id)
  {
     LLD_GPIO_SetStateHigh(SLLD_3DACC_SPI_GPIO_ADDR,SLLD_3DACC_SPI_CS_PIN);
  }
  else
  { /* TO DO: GPIO ID management for N ports target */
    if(slld_3D6Dacc_cs_gpio_id < SLLD_3D6DACC_GPIO0_LAST_CH)
    {
       LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << slld_3D6Dacc_cs_gpio_id));
    }
    else
      if(slld_3D6Dacc_cs_gpio_id < SLLD_3D6DACC_GPIO1_LAST_CH)
      {
       LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << (slld_3D6Dacc_cs_gpio_id-32U)));
      }
      else
      {
       // Impossible case
      }

   }
}

gnss_error_t slld_3Dacc_init( const tU8 bus_type, const tU8 SA0, const tU8 i2c_SlaveAd_conf, const slld_fifo_info_t fifo_info)
{
  if(SLLD_3D6DACC_SPI_BUS_TYPE == bus_type)
  {
     slld_3D6Dacc_spi_com_hnd = svc_ssp_create_com((tUInt)SLLD_3D6DACC_SPI_ID, LLD_SSP_INTERFACE_MOTOROLA_SPI,(tU32)SLLD_3D6DACC_SPI_BUS_FREQUENCY, LLD_SSP_DATA_BITS_8,(svc_ssp_hook_t)slld_3Dacc_spi_cs_enable, NULL, (svc_ssp_hook_t)slld_3Dacc_spi_cs_disable, NULL);

     if(slld_3D6Dacc_spi_com_hnd == NULL)
     {
       DR_DEBUG_MSG(("[slld_3Dacc] SPI init failed!\r\n"));
       return GNSS_ERROR;
     }
     slld_3D6Dacc_bus_type = SLLD_3D6DACC_SPI_BUS_TYPE;
  }
  else
  {
    // Implementation for I2c bus type
    /* Backward Compatibility */
    if (0x00U == i2c_SlaveAd_conf)
    {
      DR_DEBUG_MSG(("[slld_3Dacc] I2C Slave Address: 0x%x\r\n",(SLLD_3DACC_SLAVE_ADDR|SA0)));
      slld_3D6Dacc_i2c_com_hnd = svc_i2c_create_com( 0U, (LLD_I2C_SpeedModeTy)LLD_I2C_STANDARD_MODE, (tU16)(SLLD_3DACC_SLAVE_ADDR|(tU16)SA0));
    }
    else
    {
      /* i2c Slave Address for Acc is in Param 672 */
      DR_DEBUG_MSG(("[slld_3Dacc] CDB-672 I2C Slave Address: 0x%x\r\n",i2c_SlaveAd_conf));
      slld_3D6Dacc_i2c_com_hnd = svc_i2c_create_com( 0U, LLD_I2C_STANDARD_MODE, (tU16)i2c_SlaveAd_conf);
    }

    if (svc_i2c_set_port_mode( 0U, LLD_I2C_BUSCTRLMODE_MASTER) != gpOS_SUCCESS )
     return GNSS_ERROR;

    if(slld_3D6Dacc_i2c_com_hnd == NULL)
    {
      DR_DEBUG_MSG(("[slld_3Dacc] I2C com handler error\r\n"));
      return GNSS_ERROR;
    }
    slld_3D6Dacc_bus_type = SLLD_3D6DACC_I2C_BUS_TYPE;
  }

  if(slld_3Dacc_setup(fifo_info) == GNSS_ERROR)
  {
    return GNSS_ERROR;
  }

  slld_3D6Dacc_initialized = TRUE;

  return GNSS_NO_ERROR;
}


gnss_error_t slld_3Dacc_CS_init( const tU8 bus_type, const tU8 cs_gpio_conf, const tU8 cs_pullup)
{
  tU32 cs_gpio;
  LLD_GPIO_ModeTy cs_mode;

  // if mode is SPI and cs gpio config is not set in nvm
  // Check for back compatibility
  if((SLLD_3D6DACC_SPI_BUS_TYPE == bus_type) && (0x0U == cs_gpio_conf))
  {
    LLD_GPIO_SetControlMode(SLLD_3DACC_SPI_GPIO_ADDR,SLLD_3DACC_SPI_CS_PIN,(LLD_GPIO_ModeTy)SLLD_3DACC_SPI_CS_PIN_MODE);
    LLD_GPIO_SetDirectionOutput(SLLD_3DACC_SPI_GPIO_ADDR,SLLD_3DACC_SPI_CS_PIN);
    LLD_GPIO_SetStateHigh(SLLD_3DACC_SPI_GPIO_ADDR,SLLD_3DACC_SPI_CS_PIN);
  }

  // if mode is SPI and cs gpio config is set in nvm or mode is I2C but cs pull up is set in nvm
  // pull up the cs
  if ( ((SLLD_3D6DACC_SPI_BUS_TYPE == bus_type)&&(0x0U != cs_gpio_conf)) || ((SLLD_3D6DACC_I2C_BUS_TYPE == bus_type) && (cs_pullup == 0x01U)) )
  {
    cs_gpio = (( tU32)cs_gpio_conf & SLLD_3D6DACC_CONF_GPIO_MASK);
    cs_mode = ( LLD_GPIO_ModeTy)(cs_gpio_conf >> 6U);
    slld_3D6Dacc_cs_gpio_id = cs_gpio;
    if(cs_gpio < SLLD_3D6DACC_GPIO0_LAST_CH)
    {
      LLD_GPIO_SetControlMode((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << cs_gpio), cs_mode);
      LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << cs_gpio));
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << cs_gpio));
    }
    else
      if(cs_gpio < SLLD_3D6DACC_GPIO1_LAST_CH)
      {
        LLD_GPIO_SetControlMode((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << (cs_gpio-32U)), cs_mode);
        LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << (cs_gpio-32U)));
        LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (LLD_GPIO_PinTy)(1U << (cs_gpio-32U)));
      }
      else
      {
        /* impossible case */
        return GNSS_ERROR;
      }
  }

  return GNSS_NO_ERROR;
}

boolean_t slld_get_acc_Init_Status(void)
{
  //DR_DEBUG_MSG(("[slld_get_acc_Init_Status] slld_3D6Dacc_initialized:%d\r\n",slld_3D6Dacc_initialized));
  return slld_3D6Dacc_initialized;
}

#endif  //__linux__

