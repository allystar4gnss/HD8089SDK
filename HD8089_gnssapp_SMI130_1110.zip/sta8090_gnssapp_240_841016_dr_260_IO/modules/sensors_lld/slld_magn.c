/*!
 * slld_magn.c
 * Implements the basic driver blocks for a magnetometer.
 * Initialization, get message functions
 * \date 23/01/2017
 */


#ifndef __linux__
#include "clibs.h"
#include "lld_gpio.h"
#include "svc_ssp.h"
#include "svc_i2c.h"
#include "gnss_debug.h"
#include "slld_api.h"


svc_ssp_com_handler_t *slld_Magn_spi_com_hnd=NULL;
svc_i2c_com_handler_t *slld_Magn_i2c_com_hnd=NULL;
static boolean_t slld_Magn_initialized = FALSE;
static tU8 slld_Magn_bus_type = SLLD_MAGN_SPI_BUS_TYPE;
static tU8 slld_Magn_type = SLLD_ST_MAGN_LIS3MDL_TYPE;
static tU32 slld_Magn_cs_gpio_id = SLLD_MAGN_NOT_CONFIG;

tU8 slld_Magn_spi_read_command[7] = {SLLD_MAGN_SPI_READ_COMMAND_BYTE,0,0,0,0,0,0};
tU8 slld_Magn_spi_read_temp_command[3] = {SLLD_MAGN_SPI_READ_TEMP_COMMAND_BYTE,0,0};

/* Prototypes */
gnss_error_t  slld_Magn_init_CtrlReg_spi (void);
gnss_error_t  slld_Magn_init_CtrlReg_i2c (void) ;
void          slld_Magn_spi_cs_enable    (void *);
void          slld_Magn_spi_cs_disable   (void *) ;
gnss_error_t  slld_Magn_setup            (void );



void slld_Magn_get_sample(slld_Magn_sample_t *sample)
{
  tS16 local_temp;

  if(SLLD_MAGN_SPI_BUS_TYPE == slld_Magn_bus_type)
  {
    if ( slld_Magn_type == SLLD_ST_MAGN_LIS3MDL_TYPE)
    {
      tU8 *in_buf_xyz_ptr;
      //Read 8bits or 16 bits temp sensor
      tU8 in_buf_temp_ptr[3];

      //Read x,y,z sensor
      in_buf_xyz_ptr = (tU8 *)((tUInt)&sample->magn_x_data - 1);

      // Read the magnetometer x,y,z data
      if ( svc_ssp_write(slld_Magn_spi_com_hnd,slld_Magn_spi_read_command,7,in_buf_xyz_ptr,NULL) == gpOS_FAILURE )
      {
        DR_DEBUG_MSG(("[slld_Magn] SPI read sample error!\r\n"));
      }
      // Read the temperature data
      if ( svc_ssp_write(slld_Magn_spi_com_hnd,slld_Magn_spi_read_temp_command,3,in_buf_temp_ptr,NULL)== gpOS_FAILURE )
      {
        DR_DEBUG_MSG(("[slld_Magn] SPI read temp error!\r\n"));
      }

      local_temp = ((tS16)(in_buf_temp_ptr[2]<<8)) +in_buf_temp_ptr[1];
    }
  }
  else
  {
     gpOS_clock_t timeout;
     tU8 slld_Magn_i2c_data[8]={0,0,0,0,0,0,0,0};

     if ( slld_Magn_type == SLLD_ST_MAGN_LIS3MDL_TYPE)
     {
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());

        if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OUT_X_L_ADDRESS, 1, slld_Magn_i2c_data, 8, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_Magn] I2c read Gyro Data error!\r\n"));
        }

        local_temp = ((tS16)slld_Magn_i2c_data[7]<<8)+ slld_Magn_i2c_data[6];
        sample->magn_temp = MCR_DOUBLE_TO_FP16_QM((((tDouble)local_temp)/ SLLD_MAGN_TEMP_SENSOR_SENSITIVITY),SLLD_TEMP_SHIFT);
     }
     else if ( slld_Magn_type == SLLD_ST_MAGN_LSM303AGR_TYPE)
     {
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());

        if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OUT_X_L_REG, 1, slld_Magn_i2c_data, 8, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_Magn] I2c read Gyro Data error!\r\n"));
        }
     }

     sample->magn_x_data = ((tU16)slld_Magn_i2c_data[1]<<8U)+ slld_Magn_i2c_data[0];
     sample->magn_y_data = ((tU16)slld_Magn_i2c_data[3]<<8U)+ slld_Magn_i2c_data[2];
     sample->magn_z_data = ((tU16)slld_Magn_i2c_data[5]<<8U)+ slld_Magn_i2c_data[4];
  }

  //DR_DEBUG_MSG(("[slld_Magn] temp after sensitivity factor:%f fix point value:%d\r\n",(((tDouble)local_temp)/ SLLD_6DGYRO_TEMP_SENSOR_SENSITIVITY),sample->gyro_3D_temp));

  sample->magn_cpu_time = gpOS_time_now();
}

void slld_Magn_spi_cs_enable(void *par)
{
  if(SLLD_MAGN_NOT_CONFIG == slld_Magn_cs_gpio_id)
  {
     LLD_GPIO_SetStateLow(SLLD_MAGN_SPI_GPIO_ADDR, SLLD_MAGN_SPI_CS_PIN);
  }
  else
  { /* TO DO: GPIO ID management for N ports target */
    if(slld_Magn_cs_gpio_id < SLLD_MAGN_GPIO0_LAST_CH)
    {
       LLD_GPIO_SetStateLow((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (1 << slld_Magn_cs_gpio_id));
    }
    else
      if(slld_Magn_cs_gpio_id < SLLD_MAGN_GPIO1_LAST_CH)
      {
       LLD_GPIO_SetStateLow((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1 << (slld_Magn_cs_gpio_id-32)));
      }
      else
      {
        //Impossible case
      }
  }
}

void slld_Magn_spi_cs_disable(void *par)
{
  if(SLLD_MAGN_NOT_CONFIG == slld_Magn_cs_gpio_id)
  {
     LLD_GPIO_SetStateHigh(SLLD_MAGN_SPI_GPIO_ADDR, SLLD_MAGN_SPI_CS_PIN);
  }
  else
  { /* TO DO: GPIO ID management for N ports target */
    if(slld_Magn_cs_gpio_id < SLLD_MAGN_GPIO0_LAST_CH)
    {
       LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (1 << slld_Magn_cs_gpio_id));
    }
    else
      if(slld_Magn_cs_gpio_id < SLLD_MAGN_GPIO1_LAST_CH)
      {
        LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1 << (slld_Magn_cs_gpio_id-32)));
      }
      else
      {
        //Impossible case
      }

  }
}

gnss_error_t slld_Magn_init_CtrlReg_spi(void)
{
  tU8 slld_Magn_spi_command[2];
  tU8 slld_Magn_spi_command_response[7];

  // 3D Gyro ST Mems
  if (slld_Magn_type == SLLD_ST_MAGN_LIS3MDL_TYPE)
  {
    // Write in the CTRL_REG1 register
    slld_Magn_spi_command[0] = SLLD_MAGN_CTRL_REG1;
    slld_Magn_spi_command[1] = 0x7C;
    if ( svc_ssp_write(slld_Magn_spi_com_hnd,slld_Magn_spi_command,2,slld_Magn_spi_command_response,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_Magn] SPI write SLLD_MAGN_CTRL_REG1!\r\n"));
    }

    // Write in the CTRL_REG1 register
    slld_Magn_spi_command[0] = SLLD_MAGN_CTRL_REG2;
    slld_Magn_spi_command[1] = 0x60;
    if (svc_ssp_write(slld_Magn_spi_com_hnd,slld_Magn_spi_command,2,slld_Magn_spi_command_response,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_Magn] SPI write SLLD_MAGN_CTRL_REG2!\r\n"));
    }

    // Write in the CTRL_REG1 register
    slld_Magn_spi_command[0] = SLLD_MAGN_CTRL_REG3;
    slld_Magn_spi_command[1] = 0x00;
    if (svc_ssp_write(slld_Magn_spi_com_hnd,slld_Magn_spi_command,2,slld_Magn_spi_command_response,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_Magn] SPI write SLLD_MAGN_CTRL_REG3!\r\n"));
    }

    // Write in the CTRL_REG1 register
    slld_Magn_spi_command[0] = SLLD_MAGN_CTRL_REG4;
    slld_Magn_spi_command[1] = 0x0C;
    if (svc_ssp_write(slld_Magn_spi_com_hnd,slld_Magn_spi_command,2,slld_Magn_spi_command_response,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_Magn] SPI write SLLD_MAGN_CTRL_REG4!\r\n"));
    }

    // Write in the CTRL_REG1 register
    slld_Magn_spi_command[0] = SLLD_MAGN_CTRL_REG5;
    slld_Magn_spi_command[1] = 0x40;
    if (svc_ssp_write(slld_Magn_spi_com_hnd,slld_Magn_spi_command,2,slld_Magn_spi_command_response,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_Magn] SPI write SLLD_MAGN_CTRL_REG5!\r\n"));
    }
  }
  // unknown type
  else
  {
    return GNSS_ERROR;
  }

  return GNSS_NO_ERROR;
}

gnss_error_t slld_Magn_init_CtrlReg_i2c(void)
{
  tU8 slld_Magn_i2c_data;
  gpOS_clock_t timeout;

  /* LIS3MDL 3-axis magnetometer type */
  if (slld_Magn_type == SLLD_ST_MAGN_LIS3MDL_TYPE)
  {
    tU8 slld_Magn_i2c_command_response[1] = {0};

    //***************************CTRL REG1*********************************************************
    // Read the CTRL_REG1 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG1, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG1 before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the CTRL_REG1 register
    slld_Magn_i2c_data = 0x7C;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG1, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the CTRL_REG1 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG1, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG1 after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************CTRL REG2*********************************************************
    // Read the CTRL_REG2 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG2, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG2 before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the CTRL_REG2 register
    slld_Magn_i2c_data = 0x60;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG2, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the CTRL_REG2 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG2, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG2 after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************CTRL REG3*********************************************************
    // Read the CTRL_REG3 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG3, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG3 before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the CTRL_REG3 register
    slld_Magn_i2c_data = 0x00;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG3, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the CTRL_REG3 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG3, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG3 after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************CTRL REG4*********************************************************
    // Read the CTRL_REG4 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG4, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG4 before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the CTRL_REG4 register
    slld_Magn_i2c_data = 0x0C;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG4, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the CTRL_REG4 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG4, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG4 after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************CTRL REG5*********************************************************
    // Read the CTRL_REG5 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG5, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG5 before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the CTRL_REG5 register
    slld_Magn_i2c_data = 0x40;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG5, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the CTRL_REG5 register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CTRL_REG5, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] CTRL_REG5 after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************
  }
  /* LSM303AGR 3D magnetometer type */
  else if (slld_Magn_type == SLLD_ST_MAGN_LSM303AGR_TYPE)
  {
    tU8 slld_Magn_i2c_command_response[1] = {0};

    //***************************SLLD_MAGN_OFFSET_X_REG_L*********************************************
    // Read the SLLD_MAGN_OFFSET_X_REG_L register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_X_REG_L, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_X_REG_L before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_OFFSET_X_REG_L register
    slld_Magn_i2c_data = 0x00;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_X_REG_L, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_OFFSET_X_REG_L register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_X_REG_L, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_X_REG_L after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************SLLD_MAGN_OFFSET_X_REG_H*********************************************
    // Read the SLLD_MAGN_OFFSET_X_REG_H register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_X_REG_H, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_X_REG_H before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_OFFSET_X_REG_H register
    slld_Magn_i2c_data = 0x00;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_X_REG_H, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_OFFSET_X_REG_H register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_X_REG_H, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_X_REG_H after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************SLLD_MAGN_OFFSET_Y_REG_L*********************************************
    // Read the SLLD_MAGN_OFFSET_Y_REG_L register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Y_REG_L, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_Y_REG_L before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_OFFSET_Y_REG_L register
    slld_Magn_i2c_data = 0x00;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Y_REG_L, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_OFFSET_Y_REG_L register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Y_REG_L, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_Y_REG_L after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************SLLD_MAGN_OFFSET_Y_REG_H*********************************************
    // Read the SLLD_MAGN_OFFSET_Y_REG_H register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Y_REG_H, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_Y_REG_H before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_OFFSET_Y_REG_H register
    slld_Magn_i2c_data = 0x00;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Y_REG_H, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_OFFSET_Y_REG_H register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Y_REG_H, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_Y_REG_H after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************SLLD_MAGN_OFFSET_Z_REG_L*********************************************
    // Read the SLLD_MAGN_OFFSET_Z_REG_L register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Z_REG_L, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_Z_REG_L before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_OFFSET_Z_REG_L register
    slld_Magn_i2c_data = 0x00;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Z_REG_L, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_OFFSET_Z_REG_L register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Z_REG_L, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_Z_REG_L after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************SLLD_MAGN_OFFSET_Z_REG_H*********************************************
    // Read the SLLD_MAGN_OFFSET_Z_REG_H register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Z_REG_H, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_Z_REG_H before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_OFFSET_Z_REG_H register
    slld_Magn_i2c_data = 0x00;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Z_REG_H, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_OFFSET_Z_REG_H register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_OFFSET_Z_REG_H, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_OFFSET_Z_REG_H after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************SLLD_MAGN_CFG_REG_A**************************************************
    // Read the SLLD_MAGN_CFG_REG_A register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_A, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_CFG_REG_A before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_CFG_REG_A register
    slld_Magn_i2c_data = 0x0C;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_A, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_CFG_REG_A register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_A, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_CFG_REG_A after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************SLLD_MAGN_CFG_REG_B**************************************************
    // Read the SLLD_MAGN_CFG_REG_B register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_B, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_CFG_REG_B before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_CFG_REG_B register
    slld_Magn_i2c_data = 0x02;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_B, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_CFG_REG_B register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_B, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_CFG_REG_B after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************

    //***************************SLLD_MAGN_CFG_REG_C**************************************************
    // Read the SLLD_MAGN_CFG_REG_C register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_C, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_CFG_REG_C before: 0x%02x\r\n",slld_Magn_i2c_command_response[0]));

    // Write in the SLLD_MAGN_CFG_REG_C register
    slld_Magn_i2c_data = 0x00;
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_write( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_C, 1, &slld_Magn_i2c_data, 1, 1,&timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c write error!\r\n"));
      return GNSS_ERROR;
    }

    // Read the SLLD_MAGN_CFG_REG_C register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_CFG_REG_C, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      return GNSS_ERROR;
    }
    GPS_DEBUG_MSG(("[slld_Magn] SLLD_MAGN_CFG_REG_C after:  0x%02x\r\n",slld_Magn_i2c_command_response[0]));
    //*******************************************************************************************
  }
  // unknown type
  else
  {
    return GNSS_ERROR;
  }

  return GNSS_NO_ERROR;
}

gnss_error_t slld_Magn_setup(void)
{
  gnss_error_t return_error = GNSS_NO_ERROR;

  if(SLLD_MAGN_SPI_BUS_TYPE == slld_Magn_bus_type)
  {
    tU8 slld_Magn_spi_command[2] = {(tU8)(SLLD_MAGN_READ_OPERATION | SLLD_MAGN_WHO_AM_I),0};
    tU8 slld_Magn_spi_command_response[7];

    // Read the WHO_AM_I register
    if ( svc_ssp_write(slld_Magn_spi_com_hnd,slld_Magn_spi_command,2,slld_Magn_spi_command_response,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_Magn] SPI write WHO_AM_I!\r\n"));
      return_error = GNSS_ERROR;
    }

    DR_DEBUG_MSG(("[slld_Magn] ID 0x%01x\r\n",slld_Magn_spi_command_response[1]));

    if (slld_Magn_spi_command_response[1] == SLLD_MAGN_ID_LIS3MDL)
    {
      /* LIS3MDL 3-axis magnetometer type */
      slld_Magn_type = SLLD_ST_MAGN_LIS3MDL_TYPE;
    }
    else
    {
        DR_DEBUG_MSG(("[slld_Magn] Device not recognized!\r\n"));
        return_error = GNSS_ERROR;
    }

    if ( return_error == GNSS_NO_ERROR)
    {
      return_error = slld_Magn_init_CtrlReg_spi();
    }
  }
  else
  {
    tU8 slld_Magn_i2c_command_response[1] = {0};
    gpOS_clock_t timeout;

    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());

    // Read the WHO_AMI_I register
    if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_WHO_AM_I, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Magn] I2c SLLD_MAGN_WHO_AM_I read error!\r\n"));
      return_error =  GNSS_ERROR;
    }

    DR_DEBUG_MSG(("[slld_Magn] I2c ID 0x%01x\r\n",slld_Magn_i2c_command_response[0]));

    if( slld_Magn_i2c_command_response[0] == SLLD_MAGN_ID_LIS3MDL)
    {
      /* LIS3MDL 3-axis magnetometer type */
      slld_Magn_type = SLLD_ST_MAGN_LIS3MDL_TYPE;
    }
    else
    {
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());

      // Read the WHO_AMI_I_M register
      if( svc_i2c_read( slld_Magn_i2c_com_hnd, SLLD_MAGN_WHO_AM_I_M, 1, &slld_Magn_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_Magn] I2c SLLD_MAGN_WHO_AM_I_M read error!\r\n"));
        return_error =  GNSS_ERROR;
      }

      DR_DEBUG_MSG(("[slld_Magn] I2c ID 0x%01x\r\n",slld_Magn_i2c_command_response[0]));

      if( slld_Magn_i2c_command_response[0] == SLLD_MAGN_ID_LSM303AGR)
      {
        /* LSM303AGR 3D magnetometer type */
        slld_Magn_type = SLLD_ST_MAGN_LSM303AGR_TYPE;
      }
      else
      {
        DR_DEBUG_MSG(("[slld_Magn] Device not recognized!\r\n"));
        return_error =  GNSS_ERROR;
      }
    }

   if ( return_error == GNSS_NO_ERROR)
    {
      return_error = slld_Magn_init_CtrlReg_i2c();
    }
  }

  return return_error;
}

gnss_error_t slld_Magn_init( const tU8 bus_type, const tU8 i2c_SlaveAd_conf)
{
  gnss_error_t return_error = GNSS_NO_ERROR;

  if(SLLD_MAGN_SPI_BUS_TYPE == bus_type)
  {
    slld_Magn_spi_com_hnd = svc_ssp_create_com(SLLD_MAGN_SPI_ID, LLD_SSP_INTERFACE_MOTOROLA_SPI,SLLD_MAGN_SPI_BUS_FREQUENCY, LLD_SSP_DATA_BITS_8,(svc_ssp_hook_t)slld_Magn_spi_cs_enable, NULL, (svc_ssp_hook_t)slld_Magn_spi_cs_disable, NULL);

    if(slld_Magn_spi_com_hnd == NULL)
    {
      return_error =  GNSS_ERROR;
    }
    slld_Magn_bus_type = SLLD_MAGN_SPI_BUS_TYPE;
  }
  else
  {
    /* i2c Slave address is in Param 672 of SwConfig*/
    DR_DEBUG_MSG(("[slld_Magn] I2C SLave Address: 0x%x!\r\n",i2c_SlaveAd_conf));
    slld_Magn_i2c_com_hnd = svc_i2c_create_com( 0, LLD_I2C_STANDARD_MODE, (tU16)i2c_SlaveAd_conf);

    svc_i2c_set_port_mode( 0, LLD_I2C_BUSCTRLMODE_MASTER);

    if(slld_Magn_i2c_com_hnd == NULL)
    {
      return_error =  GNSS_ERROR;
    }
    slld_Magn_bus_type = SLLD_MAGN_I2C_BUS_TYPE;
  }

  if ( return_error == GNSS_NO_ERROR)
  {
    return_error = slld_Magn_setup();

    if ( return_error == GNSS_NO_ERROR)
    {
      slld_Magn_initialized = TRUE;
    }
  }

  return return_error;
}


gnss_error_t slld_Magn_CS_init( const tU8 bus_type, const tU8 cs_gpio_conf, const tU8 cs_pullup)
{
  tU32 cs_gpio;
  LLD_GPIO_ModeTy cs_mode;

  // if mode is SPI and cs gpio config is set in nvm or mode is I2C but cs pull up is set in nvm
  // pull up the cs
  if ( (SLLD_MAGN_SPI_BUS_TYPE == bus_type) || ((SLLD_MAGN_I2C_BUS_TYPE == bus_type) && (cs_pullup == 0x01U)) )
  {
    cs_gpio = ( tU32)(cs_gpio_conf & SLLD_MAGN_CONF_GPIO_MASK);
    cs_mode = ( LLD_GPIO_ModeTy)(cs_gpio_conf >> 6U);
    slld_Magn_cs_gpio_id = cs_gpio;
    if(cs_gpio < SLLD_MAGN_GPIO0_LAST_CH)
    {
      LLD_GPIO_SetControlMode((LLD_GPIO_idTy)SLLD_MAGN_SPI_GPIO_ADDR, (1U << cs_gpio), cs_mode);
      LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)SLLD_MAGN_SPI_GPIO_ADDR, (1U << cs_gpio));
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SLLD_MAGN_SPI_GPIO_ADDR, (1U << cs_gpio));
    }
    else if(cs_gpio < SLLD_MAGN_GPIO1_LAST_CH)
    {
      LLD_GPIO_SetControlMode((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1U << (cs_gpio-32)), cs_mode);
      LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1U << (cs_gpio-32)));
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1U << (cs_gpio-32)));
    }
  }

  return GNSS_NO_ERROR;
}

boolean_t slld_get_Magn_Init_Status(void)
{
  return slld_Magn_initialized;
}
#endif   //__linux__

