// FreeRTOS task example

// general
#include "macros.h"
#include "fixpoint.h"

// freeRTOS related
#include "freeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"

#define mainDELAY_LOOP_COUNT  10000

static void vTask1(void *pvParameters)
{
    const char *pcTaskName = "Task 1 is running\r\n";
    char *pcParameters;
    volatile tU32 ul; /* volatile to ensure ul is not optimized away. */

    vPrintString(pcParameters);

    /* As per most tasks, this task is implemented in an infinite loop. */
    for( ;; )
    {
       /* Print out the name of this task. */
       vPrintString(pcTaskName);

       /* Delay for a period. */
       for( ul = 0; ul < mainDELAY_LOOP_COUNT; ul++ )
       {
         /* This loop is just a very crude delay implementation. There is
          nothing to do in here. Later examples will replace this crude
          loop with a proper delay/sleep function. */
       }
    }
}

static void vTask2( void *pvParameters )
{
    const char *pcTaskName = "Task 2 is running\r\n";
    char *pcParameters;
    volatile tU32 ul; /* volatile to ensure ul is not optimized away. */

    pcParameters = (char *)pvParameters;
    vPrintString(pcParameters);

    /* As per most tasks, this task is implemented in an infinite loop. */
    for( ;; )
    {
       /* Print out the name of this task. */
       vPrintString( pcTaskName );

       /* Delay for a period. */
       for( ul = 0; ul < mainDELAY_LOOP_COUNT; ul++ )
       {
         /* This loop is just a very crude delay implementation. There is
          nothing to do in here. Later examples will replace this crude
          loop with a proper delay/sleep function. */
       }
   }
}

int main(void)
{
  char *pcString = "pass parameters";

  /* Create one of the two tasks. Note that a real application should check
   the return value of the xTaskCreate() call to ensure the task was created
   successfully. */
  xTaskCreate( vTask1, "Task 1", 1000, (void *)pcString, 1, NULL );

  /* Create the other task in exactly the same way and at the same priority. */
  xTaskCreate( vTask2, "Task 2", 1000, (void *)pcString, 1, NULL );

  /* Start the scheduler so the tasks start executing. */
  vTaskStartScheduler();

  /* If all is well then main() will never reach here as the scheduler will
   now be running the tasks. If main() does reach here then it is likely that
   there was insufficient heap memory available for the idle task to be created.
   Chapter 2 provides more information on heap memory management. */
  for (;;);
}
