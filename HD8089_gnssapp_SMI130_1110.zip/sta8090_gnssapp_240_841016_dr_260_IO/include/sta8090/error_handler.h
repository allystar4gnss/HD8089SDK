/*****************************************************************************
   FILE:          error_handler.h
   PROJECT:
   SW PACKAGE:
------------------------------------------------------------------------------
   DESCRIPTION:
------------------------------------------------------------------------------
   COPYRIGHT:     (c) 2017 STMicroelectronics
------------------------------------------------------------------------------
   Created by :
*****************************************************************************/

#ifndef ERROR_HANDLER_H
#define ERROR_HANDLER_H

/*****************************************************************************
   includes
*****************************************************************************/

/*****************************************************************************
   defines and macros
*****************************************************************************/

/*lint --emacro( {9074,923}, ERROR_ADD ) */
#define ERROR_ADD(error_code,n,p1,p2,p3,p4,p5,p6)  { tU32 b[8]; b[0] =error_code; b[1] =(tU32)((tU32)n+2U); b[2] =p1; b[3] =p2; b[4] =p3; b[5] =p4; b[6] =p5; b[7] =p6; error_handler_push( b, n);}

#define ERROR_ADD_0(error_code) ERROR_ADD(error_code, 0, 0, 0, 0,0,0,0)

#define ERROR_ADD_1(error_code, param1) ERROR_ADD(error_code, 1, param1, 0, 0, 0, 0, 0)

#define ERROR_ADD_2(error_code, param1, param2) ERROR_ADD(error_code, 2, param1, param2, 0, 0, 0, 0)

#define ERROR_ADD_3(error_code, param1, param2, param3) ERROR_ADD(error_code, 3, param1, param2, param3, 0, 0, 0)

#define ERROR_ADD_4(error_code, param1, param2, param3, param4) ERROR_ADD(error_code, 4, param1, param2, param3, param4, 0, 0)

#define ERROR_ADD_5(error_code, param1, param2, param3, param4, param5) ERROR_ADD(error_code, 5, param1, param2, param3, param4, param5, 0)

#define ERROR_ADD_6(error_code, param1, param2, param3, param4, param5, param6) ERROR_ADD(error_code, 6, param1, param2, param3, param4, param5, param6)

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gpOS_error_t error_handler_init( gpOS_partition_t *partition, tBool circ_buf);
extern tVoid error_handler_push(const tU32* error_array, tU32 nb_params);
extern tU32 error_handler_pop(tU32* error_array);

#endif /* ERROR_HANDLER_H */
