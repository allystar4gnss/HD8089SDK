/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : sm_sensor_api.h
Author :

sensors management typedef and exported API

Date        Modification                                    Initials
----        ------------                                    --------
************************************************************************/
/*!
 * @file    sm_sensor_api.h
 * @brief   sensor management typedef and exported API
 */
#ifndef SM_SENSORS_API_H
#define SM_SENSORS_API_H

/*****************************************************************************
   includes
*****************************************************************************/
#include "sm_gyro.h"
#include "sm_3Dgyro.h"
#include "sm_3Dacc.h"
#include "sm_pres.h"
#include "sm_combo_common.h"
#include "sm_sampling.h"
#include "sm_sensors.h"
#include "sm_lowlatency_sens.h"
#include "slld_api.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

/*****************************************************************************
   typedefs and structures
*****************************************************************************/
/*{{{ Typedefs*/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
/*{{{ Function Decls*/
/* INIT */
extern gnss_error_t sm_sensors_init                             ( const sm_sensors_config_t *);
extern gnss_error_t sm_sensors_init_p                           ( gpOS_partition_t *, const sm_sensors_config_t *);
extern gnss_error_t sm_can_init_p                               ( gpOS_partition_t *,  const sm_sensors_config_t *);
extern void         sm_sensors_suspend                          (void) ;
extern void         sm_sensors_resume                           (void) ;

/* GENERIC SAMPLE functions */
extern gnss_error_t sm_sensor_add_sample                        ( const sm_sensors_msg_t *, const boolean_t );
extern gnss_error_t sm_sensor_data_write                        ( const sm_sensors_msg_t *, const boolean_t );

/*CLASSIC GYRO/ODO/REV*/
extern gnss_error_t   sm_update_odo           ( const tUInt timestamp, const tUInt counter);
extern gnss_error_t   sm_update_rev           ( const tUInt timestamp, const boolean_t rev_status);
extern gnss_error_t   sm_update_odo_rev       ( const tUInt timestamp, const tUInt counter, const boolean_t status);
extern gnss_error_t   sm_update_gyro          ( const tUInt timestamp, const tU16 volts);
extern gnss_error_t   sm_update_gyro_odo_rev  ( const tUInt timestamp, const tU16 volts, const tUInt counter, const boolean_t status);

/* TEMPERATURE */
extern gnss_error_t   sm_update_temperature   ( const tUInt , const tInt , const boolean_t );

/* DWP TRAVELLED PATH */
extern gnss_error_t   sm_update_dwp_odo                 ( const tUInt, const tUInt, const tUInt);
extern gnss_error_t   sm_update_dwp_2w_front_wheels     ( const tUInt, const tUInt, const tUInt);
extern gnss_error_t   sm_update_dwp_2w_rear_wheels      ( const tUInt,  const tUInt, const tUInt);
extern gnss_error_t   sm_update_dwp_2w_rev_front_wheels ( const tUInt, const tUInt, const boolean_t,const tUInt, const boolean_t);
extern gnss_error_t   sm_update_dwp_2w_rev_rear_wheels  ( const tUInt, const tUInt, const boolean_t, const tUInt, const boolean_t);
extern gnss_error_t   sm_update_dwp_4w                  ( const tUInt, const tUInt, const tUInt, const tUInt, const tUInt);
extern gnss_error_t   sm_update_dwp_4w_rev              ( const tUInt, const tUInt, const boolean_t, const tUInt, const boolean_t, const tUInt, const boolean_t, const tUInt, const boolean_t);

/* DWP SPEED */
extern gnss_error_t   sm_update_dwp_odo_speed                 ( const tUInt, const tUInt, const tUInt);
extern gnss_error_t   sm_update_dwp_2w_front_wheels_speed     ( const tUInt, const tUInt, const tUInt);
extern gnss_error_t   sm_update_dwp_2w_rear_wheels_speed      ( const tUInt, const tUInt, const tUInt);
extern gnss_error_t   sm_update_dwp_2w_rev_front_wheels_speed ( const tUInt, const tUInt, const boolean_t,const tUInt, const boolean_t);
extern gnss_error_t   sm_update_dwp_2w_rev_rear_wheels_speed  ( const tUInt, const tUInt, const boolean_t, const tUInt, const boolean_t);
extern gnss_error_t   sm_update_dwp_4w_speed                  ( const tUInt, const tUInt, const tUInt, const tUInt, const tUInt);
extern gnss_error_t   sm_update_dwp_4w_rev_speed              ( const tUInt, const tUInt, const boolean_t, const tUInt, const boolean_t, const tUInt, const boolean_t, const tUInt, const boolean_t);

/* IGNITION */
extern gnss_error_t   sm_update_ignition            ( const tUInt timestamp, const tUInt status);

/* SPEED PID */
extern gnss_error_t   sm_update_speed               ( const tUInt timestamp, const tDouble speed);

/* MEMS */
extern gnss_error_t   sm_update_3axis_acc           ( const tUInt timestamp, const tInt xvolts, const tInt yvolts, const tInt zvolts);
extern gnss_error_t   sm_update_3axis_gyro          ( const tUInt timestamp, const tInt xvolts, const tInt yvolts, const tInt zvolts);
extern gnss_error_t   sm_update_installation_angles ( const tUInt timestamp, const  tInt phi, const  tInt theta, const  tInt psi);
extern gnss_error_t   sm_update_pres                ( const tUInt timestamp, const tU32 pressure);

/* API BLOCKING */
extern void         sm_set_api_blocking_mode    ( const boolean_t blocking_mode);
extern boolean_t    sm_get_api_blocking_mode    ( void);

/* ODO SOURCE */
extern tU8          sm_get_odometer_source_type ( tUInt);

/* OPERATING MODE*/
extern void         sm_set_operating_mode       ( const tU8 operating_mode);
extern tU8          sm_get_operating_mode       ( void);
extern tUInt        sm_get_can_operating_mode   ( tUInt operating_mode);

extern void         sm_set_raw_data_req         ( const sm_raw_sensors_config_t raw_sensors_config );
extern void         sm_get_raw_data_req         ( sm_raw_sensors_config_t* raw_sensors_config );

extern boolean_t    sm_get_sensors_init_status  (void);

/* LOGGING MASK */
extern void         sm_set_logging_mask         ( const tU8 logging_mask);
extern tU8          sm_get_logging_mask         ( void);

extern tUInt        sm_get_gyro_sensor_type     ( tUInt operating_mode);

extern void         sm_sensors_select                   ( tUInt );

/* ODO TICKS RESET */
extern gnss_error_t sm_reset_wheel_ticks_counter  ( const tUInt timestamp );
/*}}} */

#endif

