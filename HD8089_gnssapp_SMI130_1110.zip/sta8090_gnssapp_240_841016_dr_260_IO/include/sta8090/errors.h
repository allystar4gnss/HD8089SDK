/*****************************************************************************
   FILE:          errors.h
   PROJECT:       Emerald Kernel
   SW PACKAGE:    Common Header
------------------------------------------------------------------------------
   DESCRIPTION:   Definition of ERRORS Code with project scope.
------------------------------------------------------------------------------
   COPYRIGHT:     (c) 2005 STMicroelectronics, (S2S - SWD) Napoli (ITALY)
------------------------------------------------------------------------------
   Developers:
      CS:   Cosimo Stornaiuolo
------------------------------------------------------------------------------
   HISTORY:

   Date      | A.I. | Description
-------------+------+---------------------------------------------------------
 2005.08.09  |  CS  | Original version
*****************************************************************************/

#ifndef ERRORS_H
#define ERRORS_H

#ifdef __cplusplus
extern "C" {
#endif

/************************************************************************
| defines and macros (scope: module-local)
|-----------------------------------------------------------------------*/

/* Shift define to use when creating a new error code */
#define ERROR_CAT_SHIFT 16U
#define ERROR_CODE_MASK 0xFFFFU

#define ERROR_DEFINE(category,error_code) (((tUInt)category<<ERROR_CAT_SHIFT)+(error_code&ERROR_CODE_MASK))

/* List of categories */

/* Modules */
#define CAT_MOD_ANTENNA_SENS      0x0U
#define CAT_MOD_DATUM             0x1U
#define CAT_MOD_DEBUG             0x2U
#define CAT_MOD_DR_SENSORS        0x3U
#define CAT_MOD_GNSS_EVENTS       0x4U
#define CAT_MOD_GNSS_MSG          0x5U
#define CAT_MOD_GNSSAPP_PLUGINS   0x6U
#define CAT_MOD_IN_OUT            0x7U
#define CAT_MOD_LVD               0x8U
#define CAT_MOD_NMEA              0x9U
#define CAT_MOD_NMEA_EXT          0x10U
#define CAT_MOD_PGPS              0x11U
#define CAT_MOD_NVM               0x12U
#define CAT_MOD_RTC               0x13U
#define CAT_MOD_RTCM3_ENC         0x14U
#define CAT_MOD_SDLOG             0x15U
#define CAT_MOD_SHUTDN            0x16U
#define CAT_MOD_STBIN             0x17U
#define CAT_MOD_SW_CONFIG         0x18U
#define CAT_MOD_XTAL              0x19U

/* GNSS */
#define CAT_GNSS_COMMON           0x100U
#define CAT_GNSS_COMPASS          0x101U
#define CAT_GNSS_DGPS             0x102U
#define CAT_GNSS_DR               0x103U
#define CAT_GNSS_GALILEO          0x104U
#define CAT_GNSS_NAVIGATE         0x105U
#define CAT_GNSS_RXN_SECURITY     0x106U
#define CAT_GNSS_ST_AGPS          0x107U
#define CAT_GNSS_TRACKER          0x108U
#define CAT_GNSS_WAAS             0x109U

/* OS */
#define CAT_OS_OS20               0x200U
#define CAT_OS_FREERTOS           0x201U

/* SERVICES */
#define CAT_SVC_ADC               0x300U
#define CAT_SVC_CAN               0x301U
#define CAT_SVC_FSMC              0x302U
#define CAT_SVC_FSW               0x303U
#define CAT_SVC_GPIO              0x304U
#define CAT_SVC_I2C               0x305U
#define CAT_SVC_MCU               0x306U
#define CAT_SVC_MSP               0x307U
#define CAT_SVC_MTU               0x308U
#define CAT_SVC_PWR               0x309U
#define CAT_SVC_SDI               0x310U
#define CAT_SVC_SQI               0x311U
#define CAT_SVC_SSP               0x312U
#define CAT_SVC_UART              0x313U
#define CAT_SVC_USB               0x314U

/* APPLICATION */
#define CAT_APP_INIT              0x400U
#define CAT_APP_BSP               0x401U
#define CAT_APP_FRONTEND          0x402U
#define CAT_APP_PLATFORM          0x403U
#define CAT_APP_MAIN              0x404U




/* Error code definitions */

/* Error code is a 32 bit word split as indicated below:
   bit 31 ... bit 16 = error category
   bit 15 ... bit 0 = error code
*/

/* Rules to define error code:
Use ERROR_DEFINE() macro:
#define ERROR_CODE_X ERROR_DEFINE(error category, errorvalue);
Each new error value for a given category is incremented (+1) compared to the previous one.
In comment, explain the meaning of the error.
example:
#define ERROR_xxx_INIT ERROR_DEFINE(CAT_APP_INIT,1)    - wrong init of abc peripheral
#define ERROR_yyy_INIT ERROR_DEFINE(CAT_APP_INIT,2)    - timeout during init of xyz
*/

#define ERROR_RTC_TEST                        ERROR_DEFINE(CAT_MOD_RTC,1U)

#define ERROR_NVM_ERASE_BLOCK                 ERROR_DEFINE(CAT_MOD_NVM,1U)
#define ERROR_NVM_ERASE_WRONG_ADDRESS         ERROR_DEFINE(CAT_MOD_NVM,2U)
#define ERROR_NVM_WRITE_AREA                  ERROR_DEFINE(CAT_MOD_NVM,3U)
#define ERROR_NVM_WRITE_AREA_WRONG_ADDRESS    ERROR_DEFINE(CAT_MOD_NVM,4U)
#define ERROR_NVM_WRITE_WORD                  ERROR_DEFINE(CAT_MOD_NVM,5U)
#define ERROR_NVM_WRITE_WORD_WRONG_ADDRESS    ERROR_DEFINE(CAT_MOD_NVM,6U)
#define ERROR_NVM_OPEN                        ERROR_DEFINE(CAT_MOD_NVM,7U)
#define ERROR_NVM_OPEN_REC_CHECK_FAIL         ERROR_DEFINE(CAT_MOD_NVM,8U)
#define ERROR_NVM_OPEN_BANKS_CHECK_FAIL       ERROR_DEFINE(CAT_MOD_NVM,9U)

/************************************************************************
| typedefs and structures (scope: module-local)
|-----------------------------------------------------------------------*/




#ifdef __cplusplus
}
#endif

#endif  /* ERRORS_H */

/* End of file */
