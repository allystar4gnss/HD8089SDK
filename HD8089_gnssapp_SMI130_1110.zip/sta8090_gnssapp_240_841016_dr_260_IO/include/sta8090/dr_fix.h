/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : dr_fix.h
Author :

DR fix data typedef and exported API

Date        Modification                                    Initials
----        ------------                                    --------
************************************************************************/
/*!
 * @file    dr_fix.h
 * @brief   DR fix data typedef and exported API
 */
#ifndef DR_FIX_H
#define DR_FIX_H

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
   includes
*****************************************************************************/
#include "dr_defs.h"
#include "gnss_defs.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef enum dr_fix_status_tag
{
  DR_NO_FIX = 0,
  DR_FIX    = 6
}dr_fix_status_t;

typedef struct dr_fix_tag
{
  dr_state_t      dr_state;
  boolean_t       dr_fix_extrapolated;
  dr_fix_status_t dr_fix_status;
  gnss_time_t     dr_fix_time;
  gpOS_clock_t    cpu_time;
} dr_fix_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern void         dr_fix_data_init          ( dr_fix_t *fix_data );
extern gnss_error_t dr_fix_init               ( void );
extern void         dr_fix_write_data         ( dr_state_t *, dr_gps_sample_t *, dr_fix_status_t, boolean_t );
extern void         dr_fix_copy_read_claim    ( void );
extern void         dr_fix_read_data          ( dr_fix_t * );
extern void         dr_fix_copy_read_release  ( void );

#ifdef __cplusplus
}
#endif
#endif /* DR_FIX_H */
