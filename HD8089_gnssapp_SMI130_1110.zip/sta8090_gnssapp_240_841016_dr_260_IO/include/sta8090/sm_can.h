/*!
 * sm_can.h
 * Defines the interface for CAN messages.
 * \author Andrea Di Girolamo
 * \date 14/07/2011
 */
#ifndef SM_CAN_H
#define SM_CAN_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "sm_sensors.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#ifdef __STA8088__
#define SM_CAN_PERIPHERAL_ID            0
#endif
#ifdef __STA2064__
#define SM_CAN_PERIPHERAL_ID            0
#endif
#ifdef __generic__
#define SM_CAN_PERIPHERAL_ID            0
#endif
#ifdef NAVIREPLAY
#define NUM_SM_CAN_MSGS                 500
#else
#define NUM_SM_CAN_MSGS                 120
#endif
#define SM_CAN_MSG_PAYLOAD              8
#define SM_CAN_RX_INT_PRIORITY          10

#define SM_CAN_MODE_NONE                0x0
#define SM_CAN_MODE_DWP_2W              0x1
#define SM_CAN_MODE_DWP_2W_REV          0x2
#define SM_CAN_MODE_DWP_4W              0x3
#define SM_CAN_MODE_DWP_4W_REV          0x4
#define SM_CAN_MODE_DWP_2W_SPEED        0xA
#define SM_CAN_MODE_DWP_2W_REV_SPEED    0xB
#define SM_CAN_MODE_DWP_4W_SPEED        0xC
#define SM_CAN_MODE_DWP_4W_REV_SPEED    0xD
#define SM_CAN_MODE_GYRO_SPEED          0x5
#define SM_CAN_MODE_GYRO_ODO            0x6
#define SM_CAN_MODE_GYRO_ODO_SPEED      0xF
#define SM_CAN_MODE_SPD_PID             0x7
#define SM_CAN_MODE_SPD_PID_RX_ONLY     0x8
#define SM_CAN_MODE_ODO                 0x9
#define SM_CAN_MODE_ODO_SPEED           0xE
#define SM_CAN_MODE_DWS                 0x10

#define SM_CAN_DWP_SCALING_FACTOR       (1)
#define SM_CAN_DWP_OFFSET               (1.47)

#define SM_CAN_SPD_PID_OBJ_ID                 (32)
#define SM_CAN_SPD_PID_MSG_ID                 (0x7DF)
#define SM_CAN_SPD_PID_DATA                   ((tU64)(0x55555555550D0102LL))
#define SM_CAN_SPD_PID_VALIDITY_CHECK_BYTE    (1)
#define SM_CAN_SPD_PID_VALIDITY_CHECK_VALUE   (0x41)

/* number of messages in can os queue */
#define SM_CAN_NUM_OF_MSGS 1

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct sm_can_msg_tag
{
  gpOS_clock_t  can_cpu_time;
  tInt          car_maker_id;
  tInt          can_obj_id;
  tU8           can_msg[SM_CAN_MSG_PAYLOAD];
} sm_can_msg_t;


typedef enum
{
  SM_CAN_SUSPENDED,
  SM_CAN_RUNNING
} sm_can_state_t;


/*{{{  sm_can_msg_type_t*/
/* type of msg in the can process os queue*/
typedef enum sm_can_msg_type_e
{
  SM_CAN_RUN_CMD,
  SM_CAN_SUSPENDED_CMD
} sm_can_msg_type_t;

/*{{{  sm_can_message_t*/
typedef struct sm_can_message_s
{
  sm_can_msg_type_t type;
} sm_can_message_t;

/* {{{ Typedefs */
typedef struct sm_can_manager_tag
{
  gpOS_task_t *           sm_can_task;
  gpOS_semaphore_t *      suspend_sem;
  sm_can_config_t         sm_can_config;
  tUInt                   sm_can_operating_mode;
  tU16                    sm_can_dwp_odo_left;
  tU16                    sm_can_dwp_odo_right;
  gpOS_clock_t            sm_can_msg_timestamp;
  tUInt                   sm_can_dwp_odo_count;
  tUInt                   sm_can_spd_pid_veh_speed;
  gpOS_clock_t            sm_can_spd_pid_veh_sampling_time;
  tUInt                   sm_can_spd_pid_odo_count;
  tDouble                 sm_can_spd_pid_dist_traveled;
  tU16                    sm_can_spd_pid_downsampling_factor;
  tU16                    sm_can_spd_pid_downsampling_counter;
  tDouble                 sm_can_dwp_yaw;
  tDouble                 sm_can_dwp_mm_per_tick;
  tDouble                 sm_can_gyro_volts;
  tInt                    sm_can_gyro_sample;
  tInt                    sm_can_gyro_sample_accum;
  tUInt                   sm_can_gyro_sample_counter;
  tUInt                   sm_can_port;
  boolean_t               sm_can_suspended;
  boolean_t               sm_can_reverse_gear;
  boolean_t               sm_can_en_log;
} sm_can_manager_t;
/*}}} */

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t sm_can_init                   ( gpOS_partition_t *part, const tUInt operating_mode,  const sm_can_config_t *sm_can_config, const tUInt sm_can_port, const boolean_t sm_can_en_log);
extern gpOS_error_t sm_can_receive_message        ( sm_can_msg_t *msg);
extern void         sm_can_enable_solution        ( boolean_t onoff);
extern tUInt        sm_can_dwp_odo_get_sample     ( boolean_t *rev);
extern tUInt        sm_can_spd_pid_odo_get_sample ( boolean_t *rev);
extern gpOS_error_t sm_can_transmit_message       ( void);
extern void         sm_can_suspend                ( void);
extern void         sm_can_resume                 ( void);

#ifdef __cplusplus
}
#endif

#endif /* SM_CAN_H */
