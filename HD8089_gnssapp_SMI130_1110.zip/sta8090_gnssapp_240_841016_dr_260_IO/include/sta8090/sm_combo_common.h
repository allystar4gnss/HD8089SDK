/*!
 * sm_combo_common.h
 * Defines special types for combo sensor.
 */
#ifndef SM_COMBO_COMMON_H
#define SM_COMBO_COMMON_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#if defined(__STA8088__) || defined(__STA8090__)
#include "svc_ssp.h"
#include "svc_i2c.h"
#endif
#include "slld_api.h"
/*****************************************************************************
   defines and macros
*****************************************************************************/


/*****************************************************************************
   typedefs and structures
*****************************************************************************/
typedef struct  sm_raw_sensors_config_s{
  tUInt   raw_data_type_req       :  4;
  tUInt   sm_sensors_id           :  4;
  tUInt   odr_fifo_acc            :  8;
  tUInt   odr_fifo_gyro           :  8;
  tUInt   spare                   :  6;
  tUInt   Speed_odo_RealTime      :  1;
  tUInt   Mems_RealTime           :  1;
 } sm_raw_sensors_config_t;


typedef enum sm_raw_sensors_data_req_type_e
{
  NO_RAW_SENSORS_DATA_REQ = 0U,
  SM_3DACC_RAW_SENSOR_DATA_REQ,
  SM_3DGYRO_RAW_SENSOR_DATA_REQ,
  SM_6XCOMBO_RAW_SENSOR_DATA
}sm_raw_sensors_data_req_type_t;


/*****************************************************************************
   exported variables
*****************************************************************************/

extern slld_fifo_info_t           sm_fifo_info;

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern void         sm_combo_set_raw_data_req   ( const sm_raw_sensors_config_t);

#ifdef __cplusplus
}
#endif

#endif /* SM_COMBO_COMMON_H */
