//!
//!   \file     logger.h
//!   \brief    <i><b> GNSS data logging feature</b></i>
//!   \author   Andrea Di Girolamo
//!   \version  1.0
//!   \date     2016.12.16
//!   \bug      Unknown
//!   \warning  None
//!


#ifndef LOGGER_H
#define LOGGER_H

/*****************************************************************************
   includes
*****************************************************************************/

// OS related
#include "gpOS.h"

// GPS library
#include "gnss_defs.h"
#include "gnss_api.h"
#include "nmea_support.h"
#include "nmea.h"

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/

#define LOGGER_CONFIG_PARAMS_N      4

/*****************************************************************************
   typedefs and structures (scope: module-local)
*****************************************************************************/

typedef struct rec_data_tag
{
  tUInt timestamp;
  tUInt rec_type;
  position_t pos;
  tDouble speed;
  tUInt odometer;
  tUInt fix_status;
  tUInt geo_status;
  tUInt qual_status;
  tUInt qual_idx;
  tUInt sat_id;
  tUInt sat_cn0;
  tUInt sat_perr;
  tUInt sat_used;
}rec_data_t;

typedef struct logger_input_data_tag
{
  gnss_time_t     utc_time;
  time_validity_t time_validity;
  position_t      pos;
  velocity_t      vel;
  tUInt           odometer;
  fix_status_t    fix_status;
  tUInt           geo_status;
  tUInt           quality_status;
}logger_input_data_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gpOS_error_t logger_init(gpOS_partition_t *part, const tUInt *config);
extern tVoid logger_write_data(logger_input_data_t *in_data);
extern tVoid logger_write_sat_data(const gnss_time_t *utc_time, time_validity_t time_validity,fix_status_t fix_status, const raw_measure_list_t *raw_meas);
extern gpOS_error_t logger_read_data_next(rec_data_t *data, tUInt *last_entry);
extern tVoid logger_read_data_start(tVoid);
extern gpOS_error_t logger_nmea_outmsg_transmit( void *param);
extern tInt logger_nmea_cmdif_parse(const tChar *input_cmd_msg, tUInt cmd_size, tChar *cmd_par);

#endif  // _LVD_MGMT_H_

// End of file
