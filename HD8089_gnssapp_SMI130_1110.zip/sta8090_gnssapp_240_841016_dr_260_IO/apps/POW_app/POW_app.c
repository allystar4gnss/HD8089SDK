/*********************************************************************************************
   FILE:          POW_app.c
----------------------------------------------------------------------------------------------
   DESCRIPTION: Every 15 seconds, application print out its activity
                Every 10 seconds, GNSS activity perform a fix
----------------------------------------------------------------------------------------------
   COPYRIGHT:     (c) 2016 STMicroelectronics
**********************************************************************************************/



/*****************************************************************************
   includes
*****************************************************************************/
#include "macros.h"       /* to use BACKUP area           */
#include "gnss_api.h"     /* to use GNSS api              */
#include "gnss_debug.h"   /* to send data to debug port   */
#include "svc_pwr.h"      /* to use power services        */
#include "gpOS_wakelock.h"/* to use wakelock services     */
#include "gnssapp.h"      /* to configure power services  */
#include "clibs.h"        /* to use clibs memory services */
#include "lld_rtc.h"      /* to use RTC                   */

/* define DEMO_USE_FREERTOS_API into make file to use FreeRTOS API instead of gpOS API */

#if !defined (DEMO_USE_FREERTOS_API)
#include "gpOS.h"         /* to use OS related functions  */
#endif

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/
#define POW_APP_TASK_STACK_SIZE   1000     /* size of the sample application task stack */
#define POW_APPLICATION_ACTIVITY_PERIOD 10 /* Application wakeup period 10 seconds      */
#define POW_GNSS_ACTIVITY_PERIOD        25 /* GNSS        wakeup period 25 seconds      */
#define POW_RTC_TICKS_PER_SECOND   0x8000  /* RTC frac resolution */

/*****************************************************************************
   global variable definitions
*****************************************************************************/
tInt pow_app_task_priority = 0;   /* task priority value (value set arbitrary here)*/
#if defined (DEMO_USE_FREERTOS_API)
static TaskHandle_t xFrPOWAppProcess;
#endif

typedef struct pow_manager_t
{
  gpOS_wakelockid_t          wakelock_id;
  boolean_t             standby_wakeup;

}pow_manager_t;

/* Backup area declaration */
#if defined(__STA8090__)
#pragma arm section zidata = "SRAM_STDBY_DATA"
#endif
SRAM_STDBY_DATA gpOS_clock_t pow_next_timer_activity;     /* Next activity time */
SRAM_STDBY_DATA tUInt        pow_application_activity;    /* Activity counter   */
#if defined(__STA8090__)
#pragma arm section zidata
#endif


static pow_manager_t       pow_manager;

/*****************************************************************************
   function prototypes (scope: module-local)
*****************************************************************************/
/* Function which is called by "POW_app_task" */
#if defined (DEMO_USE_FREERTOS_API)
static void pow_app_process( void *pvParameters );
#else
static gpOS_task_exit_status_t pow_app_process( void *p );
#endif
static void pow_print_activity(tUInt round);
static gpOS_clock_t pow_compute_next_activity(void);

/*****************************************************************************
   function implementations
*****************************************************************************/

/* Creation of "POW_app_task" */
void pow_app_init(gpOS_partition_t *part)
{

  // Register on service power
  gpOS_wakelock_register( &pow_manager.wakelock_id );

  // Prevent standby entry by acquiring wakelock
  gpOS_wakelock_acquire(pow_manager.wakelock_id);

  /* COLD startup, activate low power mode */
  if( svc_pwr_StartupMode() == SVC_PWR_STARTUP_POWER_ON )
  {
    gnss_low_power_periodic_mode_t  periodic;
    gnss_low_power_cyclic_mode_t  cyclic;
    gnss_app_lowpow_standby_type_t Standby;

    /* Will illustrate the number of wakeup for Application activity */
    pow_application_activity = 0;

    /* Plan activity in POW_APPLICATION_ACTIVITY_PERIOD seconds */
    pow_next_timer_activity = gpOS_time_now();

#ifdef OPTION_POW_STANDBY
    GPS_DEBUG_MSG( ( "[POW_app] COLD STARTUP, setup periodic mode with standby \r\n"));
#else
    GPS_DEBUG_MSG( ( "[POW_app] COLD STARTUP, setup periodic mode \r\n"));
#endif

    /* set periodic mode at period of 10 seconds */
    periodic.periodic_mode = TRUE;                  /* < Activate periodic mode           */
    periodic.RTC_refresh = 0;                       /* < No RTC refresh                   */
    periodic.EPH_refresh = 1;                       /* < Ephemeris refresh                */
    periodic.NoFixOffTime = 60;                     /* < wait fix during 60 seconds       */
    periodic.NoFixTimeout = 60;                     /* < if no fix retry after 60 seconds */
    periodic.fix_on_time = 1;                       /* < wait 1 fix                       */
    periodic.fix_period = POW_GNSS_ACTIVITY_PERIOD; /* < provide a fix every 25 seconds   */

    GPS_DEBUG_MSG( ( "[POW_app] Provide %d fix every %d seconds \r\n",periodic.fix_on_time,periodic.fix_period));
#ifdef OPTION_POW_SYNC
    GPS_DEBUG_MSG( ( "[POW_app] Application activity synchronized with GNSS \r\n"));
#else
    GPS_DEBUG_MSG( ( "[POW_app] Application activity plan every  %d seconds \r\n",POW_APPLICATION_ACTIVITY_PERIOD));
#endif

    /* activate standby */
#ifdef OPTION_POW_STANDBY
    Standby = GNSSAPP_LOW_POWER_STANDBY_ENABLE;
#else
    Standby = GNSSAPP_LOW_POWER_STANDBY_DISABLE;
#endif

    /* disable cyclic mode */;
    _clibs_memset(&cyclic,0,sizeof(gnss_low_power_cyclic_mode_t));

    /* Activate GNSS periodic mode for a standby period of 10 seconds */
    gnssapp_low_power_setup_update( Standby , &cyclic, & periodic );               /* periodic setup */

  }
  /* Come back from standby state */
  /* STARTUP_WAKEUP_PIN or STARTUP_WAKEUP_RTC */
  else
  {
    gpOS_clock_t StandbyDuration_rtcbase;
    gpOS_clock_t VirtualPreviousOsTime;
    gpOS_clock_t TimeNow = gpOS_time_now();

    // Update previous timer value from backup ram
    svc_pwr_get_timer_adjustment( &StandbyDuration_rtcbase, &VirtualPreviousOsTime );

    GPS_DEBUG_MSG( ( "\r\n[POW_app] STARTUP - LEAVE STANDBY after %d second(s)-\r\n",StandbyDuration_rtcbase/gpOS_timer_ticks_per_sec()));

#ifndef OPTION_POW_SYNC
    // Compute next activity timer according to previous timer reference & previous activity timer reference
    if( gpOS_time_after( pow_next_timer_activity, VirtualPreviousOsTime ) != 0 )
    {
      GPS_DEBUG_MSG( ( "[POW_app] Task activity plan in %.2f second(s)\r\n",(double)gpOS_time_minus(pow_next_timer_activity , VirtualPreviousOsTime)/(double)gpOS_timer_ticks_per_sec()));
      pow_next_timer_activity = gpOS_time_plus( TimeNow , gpOS_time_minus(pow_next_timer_activity , VirtualPreviousOsTime));
    }
    else
    {
      // Process activity NOW
      pow_next_timer_activity = TimeNow;
    }

    // Verify that next activity timer is not elapsed
    if( gpOS_time_after( pow_next_timer_activity, TimeNow ) == 0)
    {
      // Process activity NOW
      pow_next_timer_activity = TimeNow;
    }
#endif
  }


#if defined (DEMO_USE_FREERTOS_API)
  xTaskCreate( pow_app_process, "POW_app_task", POW_APP_TASK_STACK_SIZE, NULL, pow_app_task_priority + 15, &xFrPOWAppProcess );
#else
  gpOS_task_create_p( part, pow_app_process, NULL, POW_APP_TASK_STACK_SIZE, pow_app_task_priority + 15, "POW_app_task", gpOS_TASK_FLAGS_ACTIVE );
#endif
}

/* Function which is called by "sample_app_task" */
#if defined (DEMO_USE_FREERTOS_API)
static void pow_app_process( void *pvParameters )
#else
static gpOS_task_exit_status_t pow_app_process( void *p )
#endif
{
  GPS_DEBUG_MSG( ( "[POW_app] Task is running\r\n"));

  while ( TRUE )
  {
#ifndef OPTION_POW_SYNC
    gpOS_clock_t SleepDuration;
    gpOS_clock_t SleepDurationMilliseconds;

    // Get time before next activity
    SleepDuration = pow_compute_next_activity();
    GPS_DEBUG_MSG( ( "[POW_app] Task delayed during %.2f second(s)\r\n",(double)SleepDuration/(double)gpOS_timer_ticks_per_sec()));

    // Task will delay activity
    if( SleepDuration != 0 )
    {
      // Convert duration in milliseconds
      SleepDurationMilliseconds = (int)((double)SleepDuration / (double)gpOS_timer_ticks_per_msec());

      // Allow enter in standby, and set the next activity time
      gpOS_wakelock_release(pow_manager.wakelock_id, &SleepDurationMilliseconds );

      gpOS_task_delay( SleepDuration );

      // Prevent standby entry by acquiring wakelock
      gpOS_wakelock_acquire(pow_manager.wakelock_id);
    }

    // Activity processing
    pow_print_activity(pow_application_activity ++);

    // Compute next activity time
    pow_next_timer_activity = gpOS_time_plus( pow_next_timer_activity , gpOS_timer_ticks_per_sec() * POW_APPLICATION_ACTIVITY_PERIOD );
#else
    // Activity processing
    pow_print_activity(pow_application_activity ++);

    // Wait for standby wake-up, generated by GNSS periodic mode
    gpOS_wakelock_release(pow_manager.wakelock_id, gpOS_TIMEOUT_INFINITY );

    // suspend activity with a delay superior to GNSS period.
    gpOS_task_delay( 2 * POW_GNSS_ACTIVITY_PERIOD * gpOS_timer_ticks_per_sec());

    // Prevent standby entry by acquiring wakelock
    gpOS_wakelock_acquire(pow_manager.wakelock_id);
#endif
  }
}
/* Function emulating the main application activity */
static void pow_print_activity(tUInt round)
{
  tU32 DRI,DRF;
  double ActivityTime;

  // Get RTC time
  LLD_RTC_Get_DRI_DRF_Registers(&DRI,&DRF);
  if(DRF > POW_RTC_TICKS_PER_SECOND)
  {
    DRF = POW_RTC_TICKS_PER_SECOND;
  }
  DRF = POW_RTC_TICKS_PER_SECOND - DRF;

  ActivityTime = ( DRI % 60 ) + (double)DRF/(double)POW_RTC_TICKS_PER_SECOND;

  GPS_DEBUG_MSG( ( "[POW_app] Task activity round %d Time : %.2f s\r\n",round, ActivityTime  ));

}

/* Function processing the duration before the next activity */
static gpOS_clock_t pow_compute_next_activity(void)
{
  gpOS_clock_t SleepDuration;
  gpOS_clock_t TimeNow;

  // Provide duration between NOW & next activity
  TimeNow = gpOS_time_now();

  if( gpOS_time_after( pow_next_timer_activity,  TimeNow ) != 0  )
  {
    SleepDuration = gpOS_time_minus( pow_next_timer_activity, TimeNow );
  }
  else
  {
    // Process activity NOW
    SleepDuration = 0;
  }

  return SleepDuration;
}

