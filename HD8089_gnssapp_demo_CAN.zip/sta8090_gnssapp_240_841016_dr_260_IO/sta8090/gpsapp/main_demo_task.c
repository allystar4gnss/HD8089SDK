// FreeRTOS task example

// general
#include "macros.h"
#include "fixpoint.h"

// freeRTOS related
#include "freeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"

// GPS library
#include "gnss_debug.h"

#define mainDELAY_LOOP_COUNT  10000

//static gpOS_partition_t *fast_partition;
//static TaskHandle_t xTask1Handle;
//static TaskHandle_t xTask2Handle;

void vTask1(void *pvParameters)
{
    char *pcText;
    volatile tU32 ul; /* volatile to ensure ul is not optimized away. */
    const TickType_t xDelay100ms = pdMS_TO_TICKS( 100 );

    pcText = (char *)pvParameters;

    /* As per most tasks, this task is implemented in an infinite loop. */
    for( ;; )
    {
       /* Print out the name of this task. */
       gnss_debug_msg("%s\r\n", pcText );

#if 0
       /* Delay for a period. */
       for( ul = 0; ul < mainDELAY_LOOP_COUNT; ul++ )
       {
         /* This loop is just a very crude delay implementation. There is
          nothing to do in here. Later examples will replace this crude
          loop with a proper delay/sleep function. */
       }
#endif
       /* Delay for a period. This time a call to vTaskDelay() is used which places
        the task into the Blocked state until the delay period has expired. The
        parameter takes a time specified in ��ticks��, and the pdMS_TO_TICKS() macro
        is used (where the xDelay100ms constant is declared) to convert 100
        milliseconds into an equivalent time in ticks. */
        vTaskDelay( xDelay100ms );
    }
}

void vTask2( void *pvParameters )
{
    char *pcText;
    volatile tU32 ul; /* volatile to ensure ul is not optimized away. */
    const TickType_t xDelay100ms = pdMS_TO_TICKS( 100 );
    TickType_t xLastWakeTime;

    pcText = (char *)pvParameters;

    /* The xLastWakeTime variable needs to be initialized with the current tick
     count. Note that this is the only time the variable is written to explicitly.
     After this xLastWakeTime is automatically updated within vTaskDelayUntil(). */
     xLastWakeTime = xTaskGetTickCount();

    /* As per most tasks, this task is implemented in an infinite loop. */
    for( ;; )
    {
       /* Print out the name of this task. */
       gnss_debug_msg("%s\r\n", pcText );

#if 0
       /* Delay for a period. */
       for( ul = 0; ul < mainDELAY_LOOP_COUNT; ul++ )
       {
         /* This loop is just a very crude delay implementation. There is
          nothing to do in here. Later examples will replace this crude
          loop with a proper delay/sleep function. */
       }
#endif
       /* Delay for a period. This time a call to vTaskDelay() is used which places
        the task into the Blocked state until the delay period has expired. The
        parameter takes a time specified in ��ticks��, and the pdMS_TO_TICKS() macro
        is used (where the xDelay100ms constant is declared) to convert 100
        milliseconds into an equivalent time in ticks. */
        //vTaskDelay( xDelay100ms );

       /* This task should execute every 100 milliseconds exactly. As per
        the vTaskDelay() function, time is measured in ticks,
        xLastWakeTime is automatically updated within vTaskDelayUntil(), so is not
        explicitly updated by the task. */
        vTaskDelayUntil(&xLastWakeTime, xDelay100ms);
   }
}

//int main(void)
//{
//  char *pcString = "main pass parameters";
//
//  /* Create one of the two tasks. Note that a real application should check
//   the return value of the xTaskCreate() call to ensure the task was created
//   successfully. */
//  xTaskCreate( vTask1, "Task 1", 1000, (void *)pcString, 1, &xTask1Handle );
//
//  /* Create the other task in exactly the same way and at the same priority. */
//  xTaskCreate( vTask2, "Task 2", 1000, (void *)pcString, 1, &xTask2Handle );
//
//  /* Start the scheduler so the tasks start executing. */
//  vTaskStartScheduler();
//
//  /* If all is well then main() will never reach here as the scheduler will
//   now be running the tasks. If main() does reach here then it is likely that
//   there was insufficient heap memory available for the idle task to be created.
//   Chapter 2 provides more information on heap memory management. */
//  for (;;);
//}
