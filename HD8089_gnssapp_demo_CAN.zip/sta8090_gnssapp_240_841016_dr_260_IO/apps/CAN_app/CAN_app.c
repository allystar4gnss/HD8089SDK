
/*****************************************************************************
   includes
*****************************************************************************/
#include <math.h>
#include "clibs.h"
#include "typedefs.h"
#include "NOC_app.h"
#include "gnss_debug.h"
#include "gnss_events.h"
#include "lld_gpio.h"
#include "svc_can.h"
#include "platform.h"
#include "sw_config.h"
#include "FreeRTOS.h"
#include "task.h"

/*****************************************************************************
   external declarations
*****************************************************************************/


/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/
#define CANTX_TASK_WORKSPACE            2048
#define CANRX_TASK_WORKSPACE            2048

#define CAN_RX_OBJECTS_NUM                10
#define LL_DEG_MASK                    0x7FU
#define LL_MIN_MASK                    0xFFU
#define SCALE_10                        10.0
#define MS_TO_KPH          (3600.0 / 1000.0)


/**********************************************
 * \brief can handler
 ***********************************************/
typedef struct can_handler_s
{
  gpOS_partition_t *  part;              /**< partition used for dynamic allocation */
  gpOS_semaphore_t *  RxAccess_sem;      /**< RxAccess semaphore */
  tU8  port;
} can_handler_t;


/*****************************************************************************
   global variable definitions  (scope: module-exported)
*****************************************************************************/

/*****************************************************************************
   global variable definitions (scope: module-local)
*****************************************************************************/
static can_handler_t *can_handler = NULL;
static TaskHandle_t xCANTxHandle;
static TaskHandle_t xCANRxHandle;

volatile static tU16 counter = 0;

/*****************************************************************************
   function prototypes (scope: module-local)
*****************************************************************************/
static void CAN_tx_process( void *);
static void CAN_rx_process( void *);


// CAN fail
static gpOS_error_t can_fail( void)
{
  gpOS_error_t error = gpOS_FAILURE;

  gpOS_memory_deallocate_p(can_handler->part, can_handler);

  return error;
}

// CAn send messages
static void  CAN_send_DWP( void)
{
   tU32 obj;
   tU32 msg_id, dlc;
   tU64 *payload;
   tU8 out_msg[2];


   msg_id  = 0x20;
   obj     = 1;
   dlc     = 8;

   out_msg[0] = counter & 0xff;
   out_msg[1] = (counter >> 8) & 0xf;
   payload = (tU64 *)&out_msg;

   if( svc_can_send( can_handler->port, &obj, &msg_id, payload, dlc, LLD_CAN_STD_ID) == gpOS_FAILURE)
   {
      GPS_DEBUG_MSG(("[CAN_APP] Can Send error!\r\n"));
   }

   GPS_DEBUG_MSG(("[CAN_APP] msg_id 0x%x DWP %d msg 0x%x%x\r\n",
       msg_id, counter++, out_msg[1], out_msg[0]));
}

// CAN task TX
static void CAN_tx_process(void *pvParameters)
//static gpOS_task_exit_status_t CAN_tx_process( void *p)
{
  boolean_t exit_flag = FALSE;

  GPS_DEBUG_MSG(("[CAN_APP] %s star\r\n", __func__));

  while( exit_flag == FALSE)
  {
    CAN_send_DWP();
    gpOS_task_delay( 2 * gpOS_timer_ticks_per_sec());
  }

  // should never reach this
  return;
}

// CAN task RX
static void CAN_rx_process( void *pvParameters)
{
  boolean_t exit_flag = FALSE;
  tU32 msg_id;
  tU32 obj_id;
  tU64 data;
  tInt cnt = 0;
  tU16 dwp;

  GPS_DEBUG_MSG(("[CAN_APP] %s star\r\n", __func__));

  while( exit_flag == FALSE)
  {
     gpOS_semaphore_wait( can_handler->RxAccess_sem);

     if( svc_can_receive( can_handler->port, &obj_id, &msg_id, &data, gpOS_TIMEOUT_INFINITY) == gpOS_FAILURE)
     {
        GPS_DEBUG_MSG(("CAN_APP Error Receive\r\n"));
     }

     dwp = ((tU8 *)&data)[0];
     dwp |= ((tU8 *)&data)[1] << 8;

     GPS_DEBUG_MSG(("\n[CAN_APP] [CanRx][%d][0x%x][%d] playload 0x%x%x\r\n",
         obj_id, msg_id, cnt++,
         ((tU8 *)&data)[1],
         ((tU8 *)&data)[0] ));

     GPS_DEBUG_MSG(("\n[CAN_APP][0x%x] DWP %d\r\n", msg_id, dwp));

     gpOS_semaphore_signal( can_handler->RxAccess_sem);
  }

  // should never reach this
  return;
}

// CAN main entrance
gpOS_error_t CAN_start( tU8 CAN_Com, gpOS_partition_t *part, tBool SOM)
{
  gpOS_error_t error = gpOS_SUCCESS;

   if( can_handler != NULL)
  {
      error = gpOS_SUCCESS;
  }
  else
  {
     can_handler = gpOS_memory_allocate_p( part, sizeof( can_handler_t));

     /**< Allocate space for can handler */
     if( can_handler == NULL)
     {
       GPS_DEBUG_MSG(("CAN_APP %s can_handle allocate fail\r\n", __func__));
       return gpOS_FAILURE;
     }

     can_handler->RxAccess_sem = NULL;
     can_handler->part   = part;
     can_handler->port   = CAN_Com;

     /* setup the filter in order to receive only the 0x20 msg_id (on Object 1) Mask 10 bits */
     svc_can_setup_rx_objects( can_handler->port, 1, 0x020, 0x3ff, SOM);

     can_handler->RxAccess_sem = gpOS_semaphore_create_p( SEM_FIFO, part, 1);

#if defined ( EXAMPLE_CAN_TX )
     xTaskCreate(CAN_tx_process, "CAN Tx Task", CANTX_TASK_WORKSPACE, NULL, tskIDLE_PRIORITY+5, &xCANTxHandle );
#endif
#if defined ( EXAMPLE_CAN_RX )
     xTaskCreate(CAN_rx_process, "CAN Rx Task", CANTX_TASK_WORKSPACE, NULL, tskIDLE_PRIORITY+5, &xCANRxHandle );
#endif

     if((can_handler->RxAccess_sem == NULL)) {
        error = can_fail();
     }
  }

  return error;
}
