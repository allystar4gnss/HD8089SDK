/*****************************************************************************
   FILE:          BTLE_app.c
   PROJECT:       STA8090 GPS application
   SW PACKAGE:    STA8090 GPS library and application
------------------------------------------------------------------------------
   DESCRIPTION:   Module to run and test Bluetooth Low Energy module
------------------------------------------------------------------------------
   COPYRIGHT:     (c) 2017 STMicroelectronics, Le Mans (FRANCE)
------------------------------------------------------------------------------
   Created by : Fabrice Pointeau
           on : 2017.04.20
*****************************************************************************/


// general
#include <string.h>
#include <stdlib.h>
#include "macros.h"
#include "fixpoint.h"
#include "gnss_debug.h"
#include "platform.h"
#include "svc_msp.h"
#include "clibs.h"

// LLD for STA8090
#include "lld_gpio.h"

// OS related
#include "gpOS.h"

// Bluetooth Low Energy related
#include "bluenrg_app.h"
#include "bluenrg_aci.h"
#include "bluenrg_gap.h"
#include "bluenrg_ssp.h"
#include "bluenrg_utils.h"
#include "bluenrg_updater_aci.h"
#include "bluenrg_gatt_aci.h"
#include "bluenrg_aci_const.h"
#include "hal.h"
#include "hal_types.h"
#include "hci.h"
#include "hci_le.h"
#include "hci_const.h"
#include "gatt_db.h"
#include "gp_timer.h"
#include "osal.h"
#include "sm.h"

/*****************************************************************************
   external declarations
*****************************************************************************/

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/

#define BLUENRG_TASK_WS_SIZE 2046
#define DELAY_TIME_TO_SEND 1000

#define SPI_IRQ_GPIO_PORT       GPIO0_REG_START_ADDR
#define SPI_IRQ_GPIO_PIN        LLD_GPIO_PIN11
#define SPI_IRQ_GPIO_AF         LLD_GPIO_ALTERNATE_MODE_A

#define SPI_IRQ_GPIO_PRIORITY   8

#define AXES_STEP   100
#define AXES_LIMIT  1000

#define ADV_INTERVAL_MIN_MS  1000
#define ADV_INTERVAL_MAX_MS  1200

#define BLTE_CHECK_MAX_TRY 5

#if defined (APPLY_BLUENRG_STACK_UPDATER)
// Bluetooth Low Energy FW upgrade
#include "bluenrg_7_2_c_Mode_2-32MHz-XO32K_4M.c"
#define BLUENRG_FW_REQUIRED_VERSION  0x720
#endif

/*****************************************************************************
   typedefs and structures (scope: module-local)
*****************************************************************************/

typedef struct bluenrg_handler_s
{
  gpOS_partition_t *     part;                  /**< partition used for dynamic allocation */

  gpOS_task_t *          task_process;          /**< task pointer */
  gpOS_task_t *          task_isr;              /**< task pointer */
  gpOS_semaphore_t *     bluenrg_done_sem;      /**< semaphore */
} bluenrg_handler_t;

/*****************************************************************************
   global variable definitions  (scope: module-exported)
*****************************************************************************/


/*****************************************************************************
   global variable definitions (scope: module-local)
*****************************************************************************/

uint16_t connection_handle = 0;   /* To avoid errors when building with BLUENRG_MS off */

volatile uint8_t set_connectable = TRUE;

tInt connected = FALSE;
tInt count = 0;

static bluenrg_handler_t *bluenrg_handler = NULL;

AxesRaw_t BTLE_data  = {0, 0, 0};
AxesRaw_t BTLE_delta = {AXES_STEP, AXES_STEP, AXES_STEP};

/*****************************************************************************
   function prototypes (scope: module-local)
*****************************************************************************/

/*****************************************************************************
   function implementations (scope: module-local)
*****************************************************************************/

/* Returns an integer in the range [0, n).
 *
 * Uses rand(), and so is affected-by/affects the same seed.
 */
int randint(int n) {
  if ((n - 1) == RAND_MAX) {
    return rand();
  } else {
    // Chop off all of the values that would cause skew...
    long end = RAND_MAX / n; // truncate skew
    int r;

    end *= n;

    // ... and ignore results from rand() that fall above that limit.
    // (Worst case the loop condition should succeed 50% of the time,
    // so we can expect to bail out of this loop pretty quickly.)
    while ((r = rand()) >= end);

    return r % n;
  }
}

void setConnectable(void)
{
 uint8_t ret;
 const char local_name[] = {AD_TYPE_COMPLETE_LOCAL_NAME,'B','l','u','e','N','R','G'};

 hci_le_set_scan_resp_data(0,NULL);

 ret = aci_gap_set_discoverable(ADV_IND, (ADV_INTERVAL_MIN_MS*1000)/625,(ADV_INTERVAL_MAX_MS*1000)/625, STATIC_RANDOM_ADDR, NO_WHITE_LIST_USE,
                                sizeof(local_name), local_name, 0, NULL, 0, 0);
 if(ret != 0) {
   GPS_DEBUG_MSG(("[bluenrg] Error during the General Discoverable Mode\r\n"));
 }
 else {
   GPS_DEBUG_MSG(("[bluenrg] General Discoverable Mode\r\n"));
 }
}

static LLD_ISR_GPIO void bluenrg_spi_irq_gpio_callback()
{
 tU32 irq_status = LLD_GPIO_GetInterruptStatus( (LLD_GPIO_idTy)GPIO0_REG_START_ADDR);

 if (irq_status & SPI_IRQ_GPIO_PIN)
 {
   LLD_GPIO_ClearInterrupt ( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN);
   gpOS_semaphore_signal(bluenrg_handler->bluenrg_done_sem);
 }
}

static gpOS_task_exit_status_t HCI_isr_process( gpOS_task_param_t p )
{
  while(1)
  {
    gpOS_semaphore_wait(bluenrg_handler->bluenrg_done_sem);
    HCI_Isr();
  }
}

static gpOS_task_exit_status_t bluenrg_process( gpOS_task_param_t p )
{
  uint8_t ret;
  int8_t i;
  uint8 bdaddr[6] = {0x12, 0x34, 0x00, 0xE1, 0x80, 0x02};
  tU16 service_handle, dev_name_char_handle, appearance_char_handle;
  gpOS_clock_t startTime = 0;
  gpOS_clock_t Test_startTime = 0;
  gpOS_clock_t Test_stopTime = 0;
  gpOS_clock_t ConnectionDuration = 0;
  uint8_t hw_ver = 0;
  uint16_t sw_ver = 0;
  boolean_t exit_flag = FALSE;
  boolean_t Test_started = FALSE;

  const char *name = "BlueNRG";

  ///* BlueNRG-MS SPI interface */
  BlueNRG_RST();
  GPS_DEBUG_MSG(("[bluenrg] BlueNRG reset done\r\n"));

  GPS_DEBUG_MSG(("[bluenrg] BD_ADDR: "));
  for(i = 5; i > 0; i--){
    GPS_DEBUG_MSG(("%02X-", bdaddr[i]));
  }
  GPS_DEBUG_MSG(("%02X\r\n", bdaddr[i]));

  i = 0;
  do {
    ret = aci_hal_write_config_data(CONFIG_DATA_PUBADDR_OFFSET, CONFIG_DATA_PUBADDR_LEN, bdaddr);
    if(ret)
    {
      GPS_DEBUG_MSG(("[bluenrg] Setting BD_ADDR failed with error 0x%x\r\n", ret));
    }
    if (i++ > BLTE_CHECK_MAX_TRY) break;
  } while (ret != 0);

  i = 0;
  do {
    getBlueNRGVersion(&hw_ver, &sw_ver);
    GPS_DEBUG_MSG(("[bluenrg] Current BlueNRG HW version = %x, SW version = %x\r\n", hw_ver, sw_ver));
    gpOS_task_delay(10*gpOS_timer_ticks_per_msec());
    if (i++ > BLTE_CHECK_MAX_TRY) break;
  } while ((hw_ver == 0) || (sw_ver == 0));


#if defined (APPLY_BLUENRG_STACK_UPDATER)
  if (sw_ver < BLUENRG_FW_REQUIRED_VERSION)
  {
    /* Update the BlueNRG/BlueNRG-MS stack image using the fw_image */
    i = 0;
    do {
      GPS_DEBUG_MSG(("[bluenrg] BlueNRG FW update started (Try %d)\r\n", i));
      ret = program_device(fw_image, sizeof(fw_image));
      if (ret != BLE_STATUS_SUCCESS) {
        GPS_DEBUG_MSG(("[bluenrg] BlueNRG FW update failed with error 0x%x\r\n", ret));
      }
      if (i++ > BLTE_CHECK_MAX_TRY)
      {
        GPS_DEBUG_MSG(("[bluenrg] ERROR : BlueNRG cannot be used !!!\r\n"));
        return -1;
      }
    } while (ret != BLE_STATUS_SUCCESS);

    do {
      getBlueNRGVersion(&hw_ver, &sw_ver);
      GPS_DEBUG_MSG(("[bluenrg] New BlueNRG HW version = %x, SW version = %x\r\n", hw_ver, sw_ver));
      gpOS_task_delay(10*gpOS_timer_ticks_per_msec());
    } while ((hw_ver == 0) || (sw_ver == 0));
  }
  else
  {
    GPS_DEBUG_MSG(("[bluenrg] No update needed\r\n"));
  }
#endif

  ret = aci_gatt_init();
  if(ret)
  {
    GPS_DEBUG_MSG(("[bluenrg] GATT_Init failed with error 0x%x\r\n", ret));
  }
  GPS_DEBUG_MSG(("[bluenrg] GATT_Init ok.\r\n"));
  ret = aci_gap_init(GAP_PERIPHERAL_ROLE, 0, 0x07, &service_handle, &dev_name_char_handle, &appearance_char_handle);
  if(ret)
  {
    GPS_DEBUG_MSG(("[bluenrg] GAP_Init failed with error 0x%x\r\n", ret));
  }
  GPS_DEBUG_MSG(("[bluenrg] GAP_Init ok.\r\n"));
  ret = aci_gatt_update_char_value(service_handle, dev_name_char_handle, 0, strlen(name), (uint8_t *)name);
  if(ret)
  {
    GPS_DEBUG_MSG(("[bluenrg] aci_gatt_update_char_value failed with error 0x%x\r\n", ret));
  }
  GPS_DEBUG_MSG(("[bluenrg] aci_gatt_update_char_value ok.\r\n"));
  ret = aci_gap_set_auth_requirement(MITM_PROTECTION_REQUIRED,
                                      OOB_AUTH_DATA_ABSENT,
                                      NULL,
                                      7,
                                      16,
                                      USE_FIXED_PIN_FOR_PAIRING,
                                      123456,
                                      BONDING);
  if(ret)
  {
    GPS_DEBUG_MSG(("[bluenrg] aci_gap_set_auth_requirement failed with error 0x%x\r\n", ret));
  }

  GPS_DEBUG_MSG(("[bluenrg] BLE Stack Initialized.\r\n"));

  /* Add Service and characteristics */
  ret = Add_Acc_Service();
  if(ret == BLE_STATUS_SUCCESS)
  {
    GPS_DEBUG_MSG(("[bluenrg] Acc service added successfully.\r\n"));
  }
  else
  {
    GPS_DEBUG_MSG(("[bluenrg] Error 0x%x while adding Acc service.\r\n", ret));
  }

  ret = Add_Environmental_Sensor_Service();
  if (ret == BLE_STATUS_SUCCESS)
  {
    GPS_DEBUG_MSG(("[bluenrg] Env Sensor service added successfully.\r\n"));
  }
  else
  {
    GPS_DEBUG_MSG(("[bluenrg] Error 0x%x while adding Env Sensor service.\r\n", ret));
  }

  /* -2 dBm output power */
  ret = aci_hal_set_tx_power_level(1,4);
  if(ret != 0)
  {
    GPS_DEBUG_MSG(("[bluenrg] Error while setting the tx power level.\r\n"));
  }

  startTime = Clock_Time();

  while ( exit_flag == FALSE )
  {
    HCI_Process();

    if(set_connectable == TRUE)
    {
       setConnectable();
       set_connectable = FALSE;
       BTLE_data.AXIS_X = 0;
       BTLE_data.AXIS_Y = 0;
       BTLE_data.AXIS_Z = 0;
    }

    if((Clock_Time() - startTime) >= DELAY_TIME_TO_SEND)
    {
      startTime = Clock_Time();
      if(connected == TRUE)
      {
        tInt axes_choice;

        if (Test_started == FALSE)
        {
          Test_started = TRUE;
          Test_startTime =  startTime;
          GPS_DEBUG_MSG(("[bluenrg] Test started\t(Start Time %d)\r\n", startTime));
        }
        axes_choice = randint(3);
        //GPS_DEBUG_MSG(("[bluenrg] AXES %d\r\n", axes_choice));

        if ( axes_choice == 0) {
          BTLE_data.AXIS_X = BTLE_data.AXIS_X + BTLE_delta.AXIS_X;
          if ( abs(BTLE_data.AXIS_X) > AXES_LIMIT) BTLE_delta.AXIS_X = (-BTLE_delta.AXIS_X);
        }
        if ( axes_choice == 1) {
          BTLE_data.AXIS_Y = BTLE_data.AXIS_Y + BTLE_delta.AXIS_Y;
          if ( abs(BTLE_data.AXIS_Y) > AXES_LIMIT) BTLE_delta.AXIS_Y = (-BTLE_delta.AXIS_Y);
        }
        if ( axes_choice == 2) {
          BTLE_data.AXIS_Z = BTLE_data.AXIS_Z + BTLE_delta.AXIS_Z;
          if ( abs(BTLE_data.AXIS_Z) > AXES_LIMIT) BTLE_delta.AXIS_Z = (-BTLE_delta.AXIS_Z);
        }

        Acc_Update(&BTLE_data);
      }
      else
      {
        if (Test_started == TRUE) {
          Test_stopTime = Clock_Time();
          ConnectionDuration = gpOS_time_minus(Test_stopTime, Test_startTime);
          GPS_DEBUG_MSG(("[bluenrg] Test Ended\t(Stop  Time %d) : duration = %.03f sec\r\n", Test_stopTime, (tDouble)ConnectionDuration/1000));
          Test_started = FALSE;
        }
      }
    }
    else
    {
      gpOS_task_delay( DELAY_TIME_TO_SEND * gpOS_timer_ticks_per_msec());
    }
  }
  // should never reach this
  return -1;
}

/********************************************//**
 * \brief   Start BLUENRG application
 *
 * \param   void
 * \return  OS_error_t
 *
 ***********************************************/
gpOS_error_t gnssapp_bluenrg_start( gpOS_partition_t *part)
{
 gpOS_error_t output = gpOS_SUCCESS;
 tInt bluenrg_isr_task_priority = 10;
 tInt bluenrg_task_priority = 9;

 GPS_DEBUG_MSG(("[bluenrg] Start BLUENRG\r\n"));

 /* Init MSP services */
 if( svc_msp_init( part, PLATFORM_BUSCLK_ID_MCLK) == gpOS_FAILURE)
 {
   GPS_DEBUG_MSG(("[bluenrg] BlueNRG MSP Init Failure\r\n"));
   return gpOS_FAILURE;
 }

 HCI_Init();

 /* Init SPI interface */
 BlueNRG_SpiInit();
 GPS_DEBUG_MSG(("[bluenrg] BlueNRG SPI Init done\r\n"));

 bluenrg_handler = gpOS_memory_allocate_p( part, sizeof( bluenrg_handler_t));

 bluenrg_handler->task_process = NULL;
 bluenrg_handler->task_isr = NULL;

 bluenrg_handler->part = part;

 bluenrg_handler->bluenrg_done_sem = gpOS_semaphore_create_p( SEM_FIFO, part, 0 );

 gpOS_interrupt_install( VIC_GPIO_0_LINE, SPI_IRQ_GPIO_PRIORITY, (gpOS_interrupt_callback_t)bluenrg_spi_irq_gpio_callback, NULL);
 gpOS_interrupt_enable( VIC_GPIO_0_LINE);
 LLD_GPIO_ClearInterrupt ( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN);
 gpOS_task_delay(gpOS_timer_ticks_per_sec());

 bluenrg_handler->task_isr = gpOS_task_create_p( part, HCI_isr_process, NULL, BLUENRG_TASK_WS_SIZE, bluenrg_isr_task_priority, "HCI_isr", gpOS_TASK_FLAGS_ACTIVE);
 bluenrg_handler->task_process = gpOS_task_create_p( part, bluenrg_process, NULL, BLUENRG_TASK_WS_SIZE, bluenrg_task_priority, "BLUENRG", gpOS_TASK_FLAGS_ACTIVE);

 if (( bluenrg_handler->bluenrg_done_sem == NULL ) || ( bluenrg_handler->task_process == NULL ) || ( bluenrg_handler->task_isr == NULL ))
 {
   gpOS_task_delete( bluenrg_handler->task_process );
   gpOS_task_delete( bluenrg_handler->task_isr );
   gpOS_semaphore_delete( bluenrg_handler->bluenrg_done_sem );
   ERROR_MSG( "[bluenrg][start] Error creating OS items.\r\n" );
   output = gpOS_FAILURE;
 }

 return output;
}

void GAP_ConnectionComplete_CB(uint8_t addr[6], uint16_t handle)
{
  tInt i;
  tChar addr_output[20];
  tUInt index = 0;
 
  connected = TRUE;
  connection_handle = handle;

  for(i = 5; i > 0; i--)
  {
     index += _clibs_sprintf(addr_output + index, "%02X-", addr[i]);
  }
  index += _clibs_sprintf(addr_output + index, "%02X\r\n", addr[0]);
 
  GPS_DEBUG_MSG(("[bluenrg] Connected to device: %s", addr_output));
}

void GAP_DisconnectionComplete_CB(void)
{
  connected = FALSE;
  GPS_DEBUG_MSG(("[bluenrg] Disconnected\r\n"));
  /* Make the device connectable again. */
  set_connectable = TRUE;
}

void HCI_Event_CB(void *pckt)
{
 hci_uart_pckt *hci_pckt = pckt;
 hci_event_pckt *event_pckt = (hci_event_pckt*)hci_pckt->data;
 
 if(hci_pckt->type != HCI_EVENT_PKT)
     return;

 switch(event_pckt->evt){

 case EVT_DISCONN_COMPLETE:
     {
         //evt_disconn_complete *evt = (void *)event_pckt->data;
         GAP_DisconnectionComplete_CB();
     }
     break;

 case EVT_LE_META_EVENT:
     {
         evt_le_meta_event *evt = (void *)event_pckt->data;

         switch(evt->subevent){

         case EVT_LE_CONN_COMPLETE:
             {
                 evt_le_connection_complete *cc = (void *)evt->data;
                 GAP_ConnectionComplete_CB(cc->peer_bdaddr,cc->handle);
             }
             break;
         }
     }
     break;

 case EVT_VENDOR:
     {
         evt_blue_aci *blue_evt = (void*)event_pckt->data;

         switch(blue_evt->ecode){

         case EVT_BLUE_GATT_READ_PERMIT_REQ:
             {
                 evt_gatt_read_permit_req *pr = (void*)blue_evt->data;
                 Read_Request_CB(pr->attr_handle);
             }
             break;

         case EVT_BLUE_GATT_ATTRIBUTE_MODIFIED:
             {
             }
             break;
         }
     }
     break;
 }
}

/* End of file */
