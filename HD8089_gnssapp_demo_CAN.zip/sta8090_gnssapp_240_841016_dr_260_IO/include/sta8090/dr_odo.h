/*!
 * dr_odo.h
 * Defines the interface to the DR ODO driver abstraction module.
 * \author Mark Griffiths
 * \date 29/7/2010
 */
#ifndef DR_ODO_H
#define DR_ODO_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gnss_defs.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#define DR_REV_LO     0
#define DR_REV_HI     1
#define ODO_RANGE     sizeof(tUInt)

#ifdef __STA2064__
#define REV_GPIO_PIN  GIO_PIN82
#define REV_PIN_MASK  (1 << 18)
#endif

#ifdef __STA8088__
#define ODO_EXT_INTERRUPT_LINE    5
#define ODO_GPIO_ID               (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define ODO_GPIO_PIN              LLD_GPIO_PIN17
#define REV_GPIO_ID               (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define REV_GPIO_PIN              LLD_GPIO_PIN16
#elif defined (__STA8090__)
#define ODO_EXT_INTERRUPT_LINE    5
#define ODO_GPIO_ID               (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define ODO_GPIO_PIN              LLD_GPIO_PIN17
#define REV_GPIO_ID               (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define REV_GPIO_PIN              LLD_GPIO_PIN16

#endif
#define REV_OFF_STATUS            0
#define ODO_REV_CONF_GPIO_MASK    0x3f
#define GPIO0_EXT_INTERRUPT_LINE  5
#define GPIO1_EXT_INTERRUPT_LINE  6
#define DR_ODO_NOT_CONFIG         ((tU32)0xffffffffU)

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

/* External function declarations */
extern gnss_error_t dr_odo_init ( tU8, tU8);
extern tInt         dr_odo_read ( tUInt*, tUInt*);

extern void         dr_odo_counter_update             (void);
extern tUInt        dr_odo_get_sample                 ( tU8 *);
extern void         dr_odo_set_rev_polarity_inversion ( boolean_t onoff);

#ifdef __cplusplus
}
#endif

#endif /* DR_ODO_H */
