/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : dr_kal.h
Author :           R Youngman

DR Kalman filter typedef and exported API

Date        Modification                                    Initials
----        ------------                                    --------
07/08/98    Created                                         RY
12/02/08    Teseo Porting & DR Cleanup                      MJS
06/03/09    Manufacturer mods & Cleanup                     MJS
20/04/11    C+ porting & algorithm revision                 NMP
************************************************************************/
/*!
 * @file    dr_kal.h
 * @brief   DR Kalman filter typedef and exported API
 */
#ifndef DR_KAL_H
#define DR_KAL_H

/*****************************************************************************
   includes
*****************************************************************************/
#include "mathfunc.h"
#include "dr_defs.h"
#include "dr_sensors.h"
#include "dr_fix.h"

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/

/*****************************************************************************
   typedefs and structures
*****************************************************************************/
/*{{{ dr_motion_status_t */
typedef enum dr_motion_status_e
{
  DR_STOPPED  = 0,
  DR_STRAIGHT,
  DR_TURNING,
  DR_UNKNOWN,
  DR_NOT_AVAILABLE,
} dr_motion_status_t;
/*}}} */

/*{{{ dr_kal_motion_status_t */
typedef struct dr_kal_motion_status_tag
{
  dr_motion_status_t  status;
  tInt                reverse_gear;
  tDouble             gnss_yaw_rate;
  tDouble             dr_yaw_rate;
  boolean_t           gnss_turning;
  tInt                stopped_timer;
  tInt                moving_timer;
  tInt                total_timer;
  tInt                straight_timer;
  boolean_t           large_post_turn_head_error;
  tDouble             acc_cross;
  tDouble             acc_along;
  tDouble             gnss_turning_total_yaw_angle;
} dr_kal_motion_status_t;
/*}}} */

/*{{{ dr_kal_yaw_rate_offset_t */
typedef struct dr_kal_yaw_rate_offset_tag
{
  boolean_t     calibrated;
  tDouble       error;
  tUInt         calibrated_time;
  boolean_t     static_calib;
  tDouble       yaw_rate_signal_std_dev;
  tDouble       last_stopped_value;
  tDouble       temperature_correction;
} dr_kal_yaw_rate_offset_t;
/*}}} */

/*{{{ dr_kal_tunnel_t */
typedef struct dr_kal_tunnel_tag
{
  boolean_t     exit;
  boolean_t     large_head_error;
  tU16          duration;
  tDouble       length;
  tDouble       head_error;
  tDouble       yaw_rate_error;
  tDouble       calib_error;
  tDouble       pos_error;
  tDouble       pos_error_perc;
  tDouble       noise_error;
} dr_kal_tunnel_t;
/*}}} */

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

#endif /* DR_KAL_H */
