//!
//!   \file     logger.h
//!   \brief    <i><b> GNSS data logging feature</b></i>
//!   \author   Andrea Di Girolamo
//!   \version  1.0
//!   \date     2016.12.16
//!   \bug      Unknown
//!   \warning  None
//!


#ifndef GEOFENCING_H
#define GEOFENCING_H

/*****************************************************************************
   includes
*****************************************************************************/

// OS related
#include "gpOS.h"

// GPS library
#include "gnss_defs.h"

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/

#define GEOFENCING_CONFIG_PARAMS_N  2U
#define GEOFENCING_CONFIG_POINTS_N  12U
#define GEO_MAX_CFG_POINTS          4U
#define GEO_MAX_CFG_POINT_PARAMS    3U

/*****************************************************************************
   typedefs and structures (scope: module-local)
*****************************************************************************/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gpOS_error_t geofencing_init(gpOS_partition_t *part, tUInt *config);
extern tChar geofencing_update_data(gnss_time_t *utc_time, position_t *pos, tDouble pos_std, fix_status_t fix_status);
extern gpOS_error_t geofencing_nmea_outmsg_transmit( void *param);
extern tInt geofencing_nmea_cmdif_parse( tChar *input_cmd_msg, tUInt cmd_size, tChar *cmd_par);
extern tVoid geofencing_set_point(tUInt id, tDouble lat, tDouble lon, tDouble radius);

#endif  // _LVD_MGMT_H_

// End of file
