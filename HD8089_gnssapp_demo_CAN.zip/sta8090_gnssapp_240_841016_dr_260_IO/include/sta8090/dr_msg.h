/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : dr_msg.h
Author :

DR debug messages typedef and exported API

Date        Modification                                    Initials
----        ------------                                    --------
************************************************************************/
/*!
 * @file    dr_msg.h
 * @brief   DR debug messages typedef and exported API
 */
#ifndef DR_MSG_H
#define DR_MSG_H

/*****************************************************************************
   includes
*****************************************************************************/
#include "dr_defs.h"
#include "dr_kal.h"
//#include "dr_kali.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define DR_MSG_SAMPLE_ID              1
#define DR_MSG_STATE_ID               2
#define DR_MSG_DEBUG_ID               3
#define DR_MSG_GPS_ID                 4
#define DR_MSG_NVM_WRITE_ID           5
#define DR_MSG_NVM_READ_ID            6
#define DR_MSG_KALMAN_INIT_ID         7
#define DR_MSG_SENSORS_ID             8
#define DR_MSG_COV_ID                 9
#define DR_MSG_UPDATE_ID              10
#define DR_MSG_STEP_ID                11
#define DR_MSG_TUNNEL_ID              12
#define DR_MSG_SENS_TYPE_ID           13
#define DR_MSG_CALIB_FLAGS_ID         14
#define DR_MSG_MOTION_STATUS_ID       15
#define DR_MSG_AHRS_ID                17
#define DR_MSG_MMFB_ID                18
#define DR_MSG_MMFBKF_ID              19
#define DR_MSG_GNSA_ID                20
#define DR_MSG_DBG_ID                 21
#define DR_MSG_DBG_READ_NVM_ID        22
#define DR_MSG_DBG_WRITE_NVM_ID       23
#define DR_MSG_DBG_INIT_ID            24
#define DR_MSG_IMUAA_ID               25

#define DR_MSG_DOUBLE_2_FP_FRACT24    (24)  /* Q */
#define DR_MSG_DOUBLE_2_FP_FRACT23    (23)  /* Q */
#define DR_MSG_DOUBLE_2_FP_FRACT18    (18)  /* Q */
#define DR_MSG_DOUBLE_2_FP_FRACT14    (14)  /* Q */
#define DR_MSG_DOUBLE_2_FP_FRACT08    (8)  /* Q */

#define DR_MSG_DBG_PAYLOAD_SIZE       4U
#define DR_MSG_DBG_STATE_OFFSET       0U
#define DR_MSG_DBG_UPD_OFFSET         1U
#define DR_MSG_DBG_ERR_COV_OFFSET     2U
#define DR_MSG_DBG_PROC_NOISE_OFFSET  3U
#define DR_MSG_DBG_MEAS_OFFSET        0U
#define DR_MSG_DBG_INNOV_OFFSET       1U
#define DR_MSG_DBG_EXCL_OFFSET        2U
#define DR_MSG_DBG_MEAS_NOISE_OFFSET  3U

#define DR_MSG_DBG_NVM_PAYLOAD_SIZE  12U

#define DR_MSG_IMUAA_N_AXES           6U

/*****************************************************************************
   typedefs and structures
*****************************************************************************/
typedef struct dr_msg_state_s
{
  gpOS_clock_t  cpu_time;
  tInt          lat;
  tInt          lon;
  tInt          gyro_gain;
  tInt          gyro_offset;
  tInt          odo_scale;
  tInt          heading;
  tInt          speed;
  tInt          gyro_ovst;
  tInt          acc_offset;
  tInt          height;
} dr_msg_state_t;

typedef struct dr_msg_kalman_stddev_tag
{
  tInt      lat;
  tInt      lon;
  tInt      heading;
  tInt      gyro_offset;
  tInt      gyro_gain;
  tInt      odo_scale;
  tInt      gyro_ovst;
  tInt      acc_offset;
  tInt      height;
} dr_msg_kalman_stddev_t;

typedef struct dr_msg_gps_sample_tag
{
  tDouble   lat;
  tDouble   lon;
  tInt      hdop;
  tInt      vdop;
  tInt      pdop;
  tInt      vn;
  tInt      ve;
  tInt      vv;
  tInt      rms_pos_residual;
  tInt      rms_vel_residual;
  tInt      height;
} dr_msg_gps_sample_t;

typedef struct dr_msg_tilt_angles_s
{
	tInt      pitch;
	tInt      roll;
	tInt      yaw;
} dr_msg_tilt_angles_t;

typedef struct dr_msg_status_backup_tag
{
  dr_msg_state_t          dr_state_copy;
  dr_msg_kalman_stddev_t  std_dev_copy;
  tU32                    temperature;
  dr_msg_tilt_angles_t    tilt_angles;
} dr_msg_status_backup_t;

typedef struct dr_msg_step_tag
{
  tInt          sample_count;
  tInt          tot_odo_step;
  boolean_t     valid_odo;
  tInt          yaw_rate_volts;
  tInt          gyro_noise;
  tInt          cpu_delta_time;
  tInt          initial_odo_count;
  tInt          final_odo_count;
  gpOS_clock_t  initial_cpu_time;
  gpOS_clock_t  final_cpu_time;
} dr_msg_step_t;

typedef struct dr_msg_kal_tunnel_tag
{
  boolean_t      exit;
  tU16           duration;
  tInt           length;
  tInt           head_error;
  tInt           yaw_rate_error;
  tInt           calib_error;
  tInt           pos_error;
  tInt           pos_error_perc;
  tInt           noise_error;
} dr_msg_kal_tunnel_t;

typedef struct dr_msg_calib_flags_tag
{
  boolean_t      odo_is_calib;
  boolean_t      gyro_gain_is_calib;
  boolean_t      gyro_offset_is_calib;
  boolean_t      pitch_calib;
  boolean_t      roll_calib;
  boolean_t      acc_axes_validity[3];
  boolean_t      gyro_axes_validity[3];
  boolean_t      gyro_integrity;
  boolean_t      acc_integrity;
} dr_msg_calib_flags_t;

typedef struct dr_msg_ahrs_tag
{
  dr_installation_angles_t  tilt_angles;
  tDouble                   slope;
  tDouble                   slope_accuracy;
  tDouble                   delta_height;
} dr_msg_ahrs_t;

typedef struct dr_msg_mmfb_tag
{
  tDouble   utc;
  tInt      validity;
  tDouble   lat;
  tDouble   lon;
  tInt      height;
  tInt      heading;
  tInt      lat_error;
  tInt      lon_error;
  tInt      height_error;
  tInt      heading_error;
} dr_msg_mmfb_t;


/* {{{ dr_mmfbkf_t*/
typedef struct dr_msg_mmfbkf_tag
{
  gpOS_clock_t  cpu_time;          /* cpu_time at which the MMFB request is received from host */
  gpOS_clock_t  elapsed_time;       /* cpu time difference between mmfb cpu time and the last gnss fix time */
  tInt          utc_delta_s;       /* delta utc time in second between the mmfb utc time and last fix utc */
  tInt          utc_delta_ms;      /* delta utc time in ms (if delta_s=0) between the mmfb utc time and last fix utc */
  tInt          pos_innov_lat;     /* difference between DR and MMFB position */
  tInt          pos_innov_lon;     /* difference between DR and MMFB position */
  tInt          pos_meas_noise_lat;      /* mmfb meas noise: either the error compared to gnss or the error reported by host */
  tInt          pos_meas_noise_lon;      /* mmfb meas noise: either the error compared to gnss or the error reported by host */
  tInt          pos_update_lat;    /* New position computed with mmfb */
  tInt          pos_update_lon;    /* New position computed with mmfb */
  tInt          hea_innov;         /* difference between DR heading and MMFB heading */
  tInt          hea_meas_noise;    /* heading error compared to gnss */
  tInt          hea_update;        /* New heading computed with mmfb */
  boolean_t     pos_accepted;
  boolean_t     hea_accepted;
}dr_msg_mmfbkf_t;
/*}}}  */

/* {{{ dr_msg_gnsa_t*/
typedef struct dr_msg_gnsa_tag
{
  boolean_t   accepted;
  boolean_t   valid_for_heading;
  boolean_t   valid_for_offset;
  boolean_t   valid_for_gain;
  tInt        lat_meas_noise;
  tInt        lon_meas_noise;
  tInt        height_meas_noise;
  tInt        hea_meas_noise;
  tInt        vel_v_meas_noise;
  tInt        pos_error;
  tInt        height_error;
  tInt        vel_error;
  tS16        signal_strength;
  boolean_t   valid_for_odo;
}dr_msg_drgnsa_t;
/*}}}  */

typedef struct dr_msg_dbg_tag
{
  tU8       mod_id;
  tU8       type_id;
  tU8       data_id;
  tDouble   data[DR_MSG_DBG_PAYLOAD_SIZE];
} dr_msg_dbg_t;

typedef struct dr_msg_dbg_nvm_tag
{
  tU8       mod_id;
  tDouble   data[DR_MSG_DBG_NVM_PAYLOAD_SIZE];
} dr_msg_dbg_nvm_t;

typedef struct dr_msg_imuaa_tag
{
  tU8       acc_est_status;
  tU8       gyro_est_status;
  tS8       imu_mask[DR_MSG_IMUAA_N_AXES];
} dr_msg_imuaa_t;

typedef union dr_debug_msg_data_u
{
  union
  {
    dr_sample_t               dr_sample;
    dr_msg_state_t            dr_state;
    dr_debug_t                dr_debug;
    dr_msg_gps_sample_t       gps_sample;
    sm_sensors_msg_t          dr_sensors_msg;
    dr_msg_kalman_stddev_t    dr_covariance;
    dr_msg_state_t            dr_update;
    dr_msg_step_t             dr_step;
    dr_msg_kal_tunnel_t       dr_tunnel;
    sm_sensor_type_t          dr_sensor_type;
    dr_msg_calib_flags_t      dr_calib;
    dr_kal_motion_status_t    dr_motion;
    dr_kal_yaw_rate_offset_t  dr_offset;
    dr_msg_ahrs_t             dr_ahrs;
    dr_msg_mmfb_t             dr_mmfb;
    dr_msg_mmfbkf_t           dr_mmfbkf;
    dr_msg_drgnsa_t           dr_gnsa;
    dr_msg_dbg_t              dr_dbg;
    dr_msg_dbg_nvm_t          dr_dbg_nvm;
    dr_msg_imuaa_t            dr_imuaa;
  } sample;
} dr_debug_msg_data_t;

typedef struct dr_msg_s
{
  tInt                type;
  dr_debug_msg_data_t data;
} dr_debug_msg_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
extern gnss_error_t dr_msg_init                   ( void );
extern boolean_t    dr_msg_read                   ( dr_debug_msg_t * );
extern void         dr_msg_write                  ( const dr_debug_msg_t *, const boolean_t );
extern void         dr_msg_write_gps_sample       ( const tInt id, const dr_gps_sample_t* data );
extern void         dr_msg_write_dr_sample        ( const tInt, const dr_sample_t* );
extern void         dr_msg_write_dr_state         ( const tInt, const dr_state_t* );
extern void         dr_msg_write_dr_debug         ( const tInt, const dr_debug_t* );
extern void         dr_msg_write_dr_nvm_debug     ( const tInt, const dr_status_backup_t* );
extern void         dr_msg_read_dr_nvm_debug      ( const tInt , const dr_status_backup_t* );
extern void         dr_msg_write_sensors_msg      ( const tInt id, const sm_sensors_msg_t* data );
extern void         dr_msg_write_dr_kalman_init   ( const tInt, const dr_state_t*, const dr_kalman_stddev_t*, const tDouble, const dr_installation_angles_t*);
extern void         dr_msg_enable_disable         ( boolean_t status );
extern void         dr_msg_write_dr_update        ( const tInt id, const dr_state_data_t* data );
extern void         dr_msg_write_dr_covariance    ( const tInt id, const dr_kalman_stddev_t* data );
extern void         dr_msg_write_dr_step          ( const tInt id, const dr_step_t* data );
extern void         dr_msg_write_dr_tunnel        ( const tInt id, const dr_kal_tunnel_t* data );
extern void         dr_msg_write_dr_sensor_type   ( const tInt id, const sm_sensor_type_t* data );
extern void         dr_msg_write_dr_calib_flags   ( const tInt id, const boolean_t *odo, const boolean_t *gain, const boolean_t *offset, const boolean_t *pitch, const boolean_t *roll, const boolean_t *acc_axes_validity, const boolean_t *gyro_axes_validity, const boolean_t *gyro_integrity, const boolean_t *acc_integrity);
extern void         dr_msg_write_dr_motion_status ( const tInt id, const dr_kal_motion_status_t* data );
extern void         dr_msg_write_dr_ahrs          ( const tInt id, const dr_installation_angles_t* angles, const tDouble slope, const tDouble slope_acc, const tDouble d_height );
extern void         dr_msg_write_dr_mmfb          ( const tInt id, const dr_mmfb_data_t* data );
extern void         dr_msg_write_dr_mmfbkf        ( const tInt id, const dr_measurements_data_t * meas_noise, const dr_mmfb_t* mmfbManager );
extern void         dr_msg_write_dr_gnsa          ( const tInt id, const dr_measurements_data_t * meas_noise, const kal_gnss_fix_analysis_t *gnss_fix_quality);
extern void         dr_msg_write_dr_dbg           ( const tInt id, const dr_msg_dbg_t* data );
extern void         dr_msg_write_dr_dbg_nvm       ( const tInt id, const dr_msg_dbg_nvm_t* data );
extern void         dr_msg_write_dr_imuaa         ( const tInt id, const dr_msg_imuaa_t* data );
#endif //DR_MSG_H
