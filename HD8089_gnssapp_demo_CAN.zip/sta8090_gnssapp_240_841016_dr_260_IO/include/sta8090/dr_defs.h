/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : dr_defs.h
Author :           R Youngman

DR structure definitions.

Date        Modification                                    Initials
----        ------------                                    --------
06/07/98    Created                                         RY
12/02/08    Teseo Porting & DR Cleanup                      MJS
************************************************************************/
/*!
 * @file    dr_defs.h
 * @brief   DR structure definitions
 */
#ifndef DR_DEFS_H
#define DR_DEFS_H

#define PITCH_ACC_1
//#define ACCAL2
//#define ACC2
/*****************************************************************************
   includes
*****************************************************************************/
#include "gnss_defs.h"
#include "sm_sensors.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
/*{{{  Defines */
#define SQUARE(a) ((a)*(a))
/*}}}  */

#define MM_PER_INCH     25.4
#define CM_PER_INCH     2.54
#define MM_PER_CM       10.0
#define CM_PER_M        100.0
#define MM_PER_M        1000.0
#define KMH_TO_MPS      0.2777777777
#define GRAVITY_MS2     9.80665 //[m/s2]
#define GRAVITY_G       1.0     //[g]

#define DR_DWP_MAX_LEFT_RIGHT_DIFF          30

#define DR_DUMMY_TIRE_CIRCUMF_M             2.061
#define DR_KAL_FILTER_PAR_RES               1E7
#define DR_OVST_PAR_RES                     1E4
#define DR_MEAS_WEIGHT_PAR_RES              1E2

#define DR_SENSORS_ODO_SCALE_INIT_VALUE             ( 0.0229  )     //[m/tick]

/*****************************************************************************
   typedefs and structures
*****************************************************************************/
typedef enum
{
  DR_FATAL,
  DR_WARNING,
  DR_MESSAGE
} dr_severity_t;

typedef struct dr_gyro_sample_s
{
  tDouble       volts;
  gpOS_clock_t  cpu_time;
} dr_gyro_sample_t;

typedef struct dr_sample_tag
{
  tU8           type;
  gpOS_clock_t  cpu_time;
  gpOS_clock_t  acc_cpu_time;
  tInt          odo_count;
  tU16          gyro_volts;
  tU8           reverse;
  tInt          acc_x;
  tInt          acc_y;
  tInt          acc_z;
  tU16          gyro_x;
  tU16          gyro_y;
  tU16          gyro_z;
} dr_sample_t;

typedef struct dr_step_tag
{
  tInt          sample_count;
  tInt          tot_odo_step;
  boolean_t     valid_odo;
  tDouble       ave_gyro_volts;
  tDouble       gyro_noise;
  tDouble       ave_heading;
  tDouble       ave_delta_heading;
  tDouble       cpu_delta_time;
  tDouble       delta_temperature;
  tInt          initial_odo_count;
  tInt          half_odo_count;
  tInt          final_odo_count;
  gpOS_clock_t  initial_cpu_time;
  gpOS_clock_t  half_cpu_time;
  gpOS_clock_t  final_cpu_time;
  tDouble       acc_x;
  tDouble       acc_y;
  tDouble       acc_z;
  tDouble       gyro_x;
  tDouble       gyro_y;
  tDouble       gyro_z;
  tDouble       roll_rate_volts;
  tDouble       pitch_rate_volts;
  tDouble       yaw_rate_volts;
} dr_step_t;

typedef struct dr_NEV_tag
{
  tDouble   N;
  tDouble   E;
  tDouble   V;
} dr_NEV_t;

typedef struct dr_gps_sample_tag
{
  gpOS_clock_t  cpu_time;
  gnss_time_t   fix_time;
  tInt          gps_fix_nbr;
  tDouble       lat;
  tDouble       lon;
  tDouble       height;
  tDouble       course;
  tDouble       speed;
  tDouble       hdop;
  tDouble       vdop;
  tDouble       pdop;
  tDouble       vn;
  tDouble       ve;
  tDouble       vv;
  tDouble       pitch;
  tInt          sat_num;
  tDouble       rms_pos_residual;
  tDouble       rms_vel_residual;
  tDouble       signal_strength;
  fix_status_t  fix_status;
  dr_NEV_t      std_dev_pos;
  dr_NEV_t      std_dev_vel;
} dr_gps_sample_t;


typedef struct dr_state_s
{
  gpOS_clock_t  cpu_time;
  tDouble       lat;
  tDouble       lon;
  tDouble       height;
  tDouble       gyro_gain;
  tDouble       gyro_offset;
  tDouble       odo_scale;
  tDouble       heading;
  tDouble       speed;
  tDouble       gyro_ovst;
  tDouble       acc_offset;
} dr_state_t;

typedef struct dr_state_data_s
{
  tDouble       lat;
  tDouble       lon;
  tDouble       hea;
  tDouble       gain;
  tDouble       offs;
  tDouble       scale;
  tDouble       ovst;
  tDouble       height;
  tDouble       acc_offs;
} dr_state_data_t;

typedef struct dr_kalman_stddev_tag
{
  tDouble       lat;
  tDouble       lon;
  tDouble       heading;
  tDouble       gyro_offset;
  tDouble       gyro_gain;
  tDouble       odo_scale;
  tDouble       gyro_ovst;
  tDouble       height;
  tDouble       acc_offs;
} dr_kalman_stddev_t;

typedef struct dr_debug_s
{
  gpOS_clock_t  cpu_time;
  tDouble       lat_error;
  tDouble       lon_error;
  tDouble       heading_error;
  tDouble       speed_error;
  tDouble       height_error;
  tDouble       vel_v_error;
} dr_debug_t;

typedef struct dr_position_tag
{
  tDouble       latitude;
  tDouble       longitude;
  tDouble       height;
} dr_position_t;

typedef struct dr_velocity_tag
{
  tDouble       speed;
  tDouble       heading;
} dr_velocity_t;

typedef enum dr_frame_ref_type_e
{
	BODY            = 0,
	NAV             = 1
} dr_frame_ref_type_t;

typedef enum dr_speed_unit_e
{
  M_PER_SECOND    = 0,
  KM_PER_HOUR     = 1,
  REV_PER_MINUTE  = 2
} dr_speed_unit_t;

typedef enum dr_sensor_axes_type_e
{
  X_AXIS          = 1,
  Y_AXIS          = 2,
  Z_AXIS          = 3
}  dr_sensor_axes_type_t;

typedef struct installation_angles_s
{
	tDouble       pitch;
	tDouble       roll;
	tDouble       yaw;
	boolean_t     pitch_calib;
	boolean_t     roll_calib;
} dr_installation_angles_t;

typedef struct dr_mmfb_data_tag
{
  gpOS_clock_t  cpu_time;     /* cpu_time at which the MMFB request is received from host */
  gpOS_clock_t  elapsed_time; /* cpu time difference between mmfb cpu time and the last gnss fix time */
  tDouble       utc;          /* UTC time stamp for the map matched position data */
  boolean_t     lat_valid;
  boolean_t     lon_valid;
  boolean_t     height_valid;
  boolean_t     heading_valid;
  tDouble       lat;
  tDouble       lon;
  tDouble       height;
  tDouble       heading;
  tDouble       lat_error;
  tDouble       lon_error;
  tDouble       height_error;
  tDouble       heading_error;
} dr_mmfb_data_t;

typedef struct dr_calib_status_tag
{
  boolean_t     odo_scale_calib;
  boolean_t     gyro_offset_calib;
  boolean_t     gyro_gain_calib;
} dr_calib_status_t;

typedef struct dr_imu_axes_tag
{
  tS8           acc_axes_map[3];
  boolean_t     acc_axes_validity[3];
  tS8           gyro_axes_map[3];
  boolean_t     gyro_axes_validity[3];
} dr_imu_axes_t;


typedef struct dr_imu_sensor_tag
{
  tDouble       offset[3];
} dr_imu_sensor_t;

typedef struct dr_imu_sensors_tag
{
  dr_imu_sensor_t           acc;
} dr_imu_sensors_t;

typedef struct dr_status_backup_tag
{
  dr_state_t                dr_state_copy;
  dr_kalman_stddev_t        std_dev_copy;
  sm_sensor_type_t          sensor_type;
  tDouble                   temperature;
  dr_installation_angles_t  tilt_angles;
  dr_calib_status_t         dr_calib_status;
  dr_imu_axes_t             dr_imu_axes;
  dr_imu_sensors_t          dr_imu_sensors;
} dr_status_backup_t;

/* {{{ dr_measurements_data_t */
typedef struct dr_measurements_data_s
{
  tDouble   lat;
  tDouble   lon;
  tDouble   hea;
  tDouble   pitch;
  tDouble   height;
  tDouble   vel_v;
  tDouble   lat_mmfb;       /* mmfb meas noise: either the error compared to gnss or the error reported by host */
  tDouble   lon_mmfb;
  tDouble   hea_mmfb;       /* heading error compared to gnss */
} dr_measurements_data_t;
/*}}}  */

/* {{{ dr_mmfb_t*/
typedef struct dr_mmfb_tag
{
  tDouble           lat;
  tDouble           lon;
  tDouble           hea;
  tDouble           height;
  tDouble           lat_host_err;      /* Lat error indication from map matching host */
  tDouble           lon_host_err;      /* Lon error indication from map matching host */
  tDouble           hea_host_err;      /* Heading error indication from map matching host */
  tDouble           height_host_err;   /* Height error indication from map matching host */
  dr_state_data_t   dX;
  tDouble           pos_innov_lat;     /* difference between DR and MMFB position */
  tDouble           pos_innov_lon;     /* difference between DR and MMFB position */
  tDouble           hea_innov;         /* difference between DR heading and MMFB heading */
  gpOS_clock_t      cpu_time;          /* cpu_time at which the MMFB request is received from host */
  gpOS_clock_t      elapsed_time;      /* cpu time difference between mmfb cpu time and the last gnss fix time */
  tInt              utc_delta_s;       /* delta utc time in second between the mmfb utc time and last fix utc */
  tInt              utc_delta_ms;      /* delta utc time in ms (if delta_s=0) between the mmfb utc time and last fix utc */
  boolean_t         allow_pos_update;
  boolean_t         allow_hea_update;
} dr_mmfb_t;
/*}}}  */

/*{{{ kal_gnss_fix_analysis_t */
typedef struct kal_gnss_fix_analysis_tag
{
  boolean_t   accepted;
  boolean_t   valid_for_heading;
  boolean_t   valid_for_offset;
  boolean_t   valid_for_gain;
  boolean_t   valid_for_odo;
  tDouble     signal_strength;
  tDouble     position_error;
  tDouble     height_error;
  tDouble     velocity_error;
  tShort      delta_signal_strength;
  tDouble     position_confidence;
  tDouble     speed_error;
} kal_gnss_fix_analysis_t;
/*}}} */

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

#endif  //DR_DEFS_H


