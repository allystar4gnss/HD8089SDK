/*!
 * sm_3dgyro.h
 * Defines the interface for SM 3Dgyro sampling.
 * \author Andrea Di Girolamo
 * \date 14/07/2011
 */
#ifndef SM_3DGYRO_H
#define SM_3DGYRO_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "sm_odo.h"
#include "slld_api.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

/*****************************************************************************
   typedefs and structures
*****************************************************************************/
typedef struct sm_3Dgyro_msg_tag
{
  slld_3Dgyro_sample_t slld_3Dgyro_sample;
  sm_odo_sample_t    odo_sample;
} sm_3Dgyro_sample_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gpOS_error_t sm_3Dgyro_receive_sample    ( sm_3Dgyro_sample_t *);
extern void         sm_3Dgyro_enable_solution   ( boolean_t );
extern void         sm_3Dgyro_enable_log        ( boolean_t );
extern void         sm_3Dgyro_capture_sample    ( void);
extern void         sm_3Dgyro_set_gyro_polarity_inversion(boolean_t );
extern void         sm_3Dgyro_set_odo_type      (tU8 );

#ifdef __cplusplus
}
#endif

#endif /* SM_3DGYRO_H */
