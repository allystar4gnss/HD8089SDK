/*!
 * sm_3dacc.h
 * Defines the interface for DR 3Dgyro sampling.
 * \author Andrea Di Girolamo
 * \date 14/07/2011
 */
#ifndef SM_3DACC_H
#define SM_3DACC_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "slld_api.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

/*****************************************************************************
   typedefs and structures
*****************************************************************************/


/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
extern gpOS_error_t   sm_3Dacc_receive_sample ( slld_3Dacc_sample_t *msg);
extern void           sm_3Dacc_enable_log     ( boolean_t onoff);
extern void           sm_3Dacc_capture_sample ( void);

#ifdef __cplusplus
}
#endif

#endif /* SM_3DACC_H */
