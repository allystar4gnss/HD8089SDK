/*!
 * dr_can.h
 * Defines the interface for DR CAN message.
 * \author Andrea Di Girolamo
 * \date 14/07/2011
 */
#ifndef DR_CAN_H
#define DR_CAN_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_bsp_defs.h"
#include "gnss_defs.h"
//#include "lld_can.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#ifdef __STA8088__
#define DR_CAN_PERIPHERAL_ID            0
#endif
#ifdef __STA2064__
#define DR_CAN_PERIPHERAL_ID            0
#endif
#ifdef __generic__
#define DR_CAN_PERIPHERAL_ID            0
#endif
#ifdef NAVIREPLAY
#define NUM_DR_CAN_MSGS                 500
#else
#define NUM_DR_CAN_MSGS                 120
#endif
#define DR_CAN_MSG_PAYLOAD              8
#define DR_CAN_RX_INT_PRIORITY          10
#define DR_CAN_MAX_INPUT_MSG            10

#define DR_CAN_MODE_NONE                0x0
#define DR_CAN_MODE_DWP_2W              0x1
#define DR_CAN_MODE_DWP_2W_REV          0x2
#define DR_CAN_MODE_DWP_4W              0x3
#define DR_CAN_MODE_DWP_4W_REV          0x4
#define DR_CAN_MODE_DWP_2W_SPEED        0xA
#define DR_CAN_MODE_DWP_2W_REV_SPEED    0xB
#define DR_CAN_MODE_DWP_4W_SPEED        0xC
#define DR_CAN_MODE_DWP_4W_REV_SPEED    0xD
#define DR_CAN_MODE_GYRO_SPEED          0x5
#define DR_CAN_MODE_GYRO_ODO            0x6
#define DR_CAN_MODE_GYRO_ODO_SPEED      0xF
#define DR_CAN_MODE_SPD_PID             0x7
#define DR_CAN_MODE_SPD_PID_RX_ONLY     0x8
#define DR_CAN_MODE_ODO                 0x9
#define DR_CAN_MODE_ODO_SPEED           0xE
#define DR_CAN_MODE_DWS                 0x10

#define DR_CAN_DWP_SCALING_FACTOR       (1)
#define DR_CAN_DWP_OFFSET               (1.47)

#define DR_CAN_SPD_PID_OBJ_ID                 (32)
#define DR_CAN_SPD_PID_MSG_ID                 (0x7DF)
#define DR_CAN_SPD_PID_DATA                   ((tU64)(0x55555555550D0102LL))
#define DR_CAN_SPD_PID_VALIDITY_CHECK_BYTE    (1)
#define DR_CAN_SPD_PID_VALIDITY_CHECK_VALUE   (0x41)

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct dr_can_msg_tag
{
  gpOS_clock_t  can_cpu_time;
  tInt          car_maker_id;
  tInt          can_obj_id;
  tU8           can_msg[DR_CAN_MSG_PAYLOAD];
} dr_can_msg_t;

typedef struct dr_can_msg_parms_tag
{
  tUInt msg_obj;
  tUInt msg_id;
  tUInt msg_mask;
}dr_can_msg_parms_t;

typedef struct dr_can_msg_config_tag
{
  tInt                n_messages;
  dr_can_msg_parms_t  msg_params[DR_CAN_MAX_INPUT_MSG];
}dr_can_msg_config_t;

typedef struct dr_can_gyro_setting_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 4;
  tUInt msbyte     : 4;
  tUInt bitmask    : 16;
}dr_can_gyro_setting_t;

typedef struct dr_can_dwp_odo_setting_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 4;
  tUInt msbyte     : 4;
  tUInt bitmask    : 16;
}dr_can_dwp_odo_setting_t;

typedef struct dr_can_dwp_odo_validity_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 8;
  tUInt bitmask    : 8;
  tUInt logic      : 8;
}dr_can_dwp_odo_validity_t;

typedef struct dr_can_dwp_params_tag
{
  tUInt dwp_counter_max_value      : 16;
  tUInt dwp_speed_resolution       : 14;
  tUInt dwp_speed_unit             : 2;
} dr_can_dwp_params_t;

typedef struct dr_can_dwp_rev_setting_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 8;
  tUInt bitmask    : 8;
  tUInt logic      : 8;
}dr_can_dwp_rev_setting_t;

typedef struct dr_can_dwp_rev_validity_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 8;
  tUInt bitmask    : 8;
  tUInt logic      : 8;
}dr_can_dwp_rev_validity_t;

typedef struct dr_can_spd_pid_setting_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 8;
  tUInt bitmask    : 8;
  tUInt spare      : 8;
}dr_can_spd_pid_setting_t;

typedef struct dr_can_filtering_setting_tag
{
  dr_can_dwp_odo_setting_t      dwp_odo_front_left;
  dr_can_dwp_odo_validity_t     dwp_odo_front_left_val;
  dr_can_dwp_odo_setting_t      dwp_odo_front_right;
  dr_can_dwp_odo_validity_t     dwp_odo_front_right_val;
  dr_can_dwp_odo_setting_t      dwp_odo_rear_left;
  dr_can_dwp_odo_validity_t     dwp_odo_rear_left_val;
  dr_can_dwp_odo_setting_t      dwp_odo_rear_right;
  dr_can_dwp_odo_validity_t     dwp_odo_rear_right_val;
  dr_can_dwp_rev_setting_t      dwp_front_left_rev;
  dr_can_dwp_rev_validity_t     dwp_front_left_rev_val;
  dr_can_dwp_rev_setting_t      dwp_front_right_rev;
  dr_can_dwp_rev_validity_t     dwp_front_right_rev_val;
  dr_can_dwp_rev_setting_t      dwp_rear_left_rev;
  dr_can_dwp_rev_validity_t     dwp_rear_left_rev_val;
  dr_can_dwp_rev_setting_t      dwp_rear_right_rev;
  dr_can_dwp_rev_validity_t     dwp_rear_right_rev_val;
  dr_can_dwp_params_t			      dwp;
  dr_can_gyro_setting_t         gyro;
  dr_can_spd_pid_setting_t      spd_pid;
}dr_can_filtering_setting_t;

typedef struct dr_can_car_parameters_tag
{
  tUInt tire_circ_mm  : 12;
  tUInt track_mm      : 12;
  tUInt ticks_per_rev : 8;
}dr_can_car_parameters_t;

typedef struct dr_can_gyro_parameters_tag
{
  tUInt gyro_msg_rate   : 8;
  tUInt gyro_adc_res    : 4;
  tUInt gyro_sign_bit   : 4;
  tUInt gyro_raw_offset : 16;
}dr_can_gyro_parameters_t;

typedef struct dr_can_config_tag
{
  tUInt                       car_maker_id;
  tUInt                       can_baudrate;
  dr_can_msg_config_t         msg_config;
  dr_can_filtering_setting_t  can_filtering;
  dr_can_car_parameters_t     car_params;
  dr_can_gyro_parameters_t    gyro_params;
} dr_can_config_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t dr_can_init                   ( gpOS_partition_t *part, const tUInt operating_mode,  const dr_can_config_t *dr_can_config, const tUInt dr_can_port, const boolean_t dr_can_en_log);
extern gpOS_error_t dr_can_receive_message        ( dr_can_msg_t *msg);
extern void         dr_can_enable_solution        ( boolean_t onoff);
extern tUInt        dr_can_dwp_odo_get_sample     ( boolean_t *rev);
extern tUInt        dr_can_spd_pid_odo_get_sample ( boolean_t *rev);
extern gpOS_error_t dr_can_transmit_message       ( void);

#ifdef __cplusplus
}
#endif

#endif /* DR_CAN_H */
