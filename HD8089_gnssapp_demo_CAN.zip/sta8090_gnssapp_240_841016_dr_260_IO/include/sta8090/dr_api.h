/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : dr_api.h
Author :

DR core library exported API

Date        Modification                                    Initials
----        ------------                                    --------
************************************************************************/
/*!
 * @file    dr_api.h
 * @brief   DR core library exported API
 */
#ifndef DR_API_H
#define DR_API_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/
#include "mathfunc.h"
#include "dr_defs.h"
#include "dr_fix.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define PARAM_NOT_AVAIL -10000000.0

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef enum dr_processing_status_e
{
  DR_PROCESSING_SUSPENDED,
  DR_PROCESSING_SUSPEND_REQUEST,
  DR_PROCESSING_RUNNING
}dr_processing_status_t;

/*****************************************************************************
   exported variables
*****************************************************************************/


/*****************************************************************************
   exported function prototypes
*****************************************************************************/
/* Basic DR Output */
extern dr_position_t    dr_fix_get_pos( void );
extern dr_velocity_t    dr_fix_get_vel( void );
extern dr_velocity_t    dr_fix_get_speed_heading( void );
extern dr_fix_status_t  dr_fix_get_fix_status( void );

/*SW rel # retrievement*/
extern const tChar *    dr_version( void );

/*DR Startup */
extern gnss_error_t     dr_init( void );
extern gnss_error_t     dr_init_config( const sm_sensors_config_t * );
extern gnss_error_t     dr_start( void );
extern gnss_error_t     dr_restart( void );
extern gnss_error_t     dr_suspend( void );
extern boolean_t        dr_suspended( void );
extern void             dr_sensors_init_default_sensors_parameters  ( const sm_sensors_config_t *dr_config_block_ptr);

/*Fix Management*/
extern void             dr_fix_store( void );
extern void             dr_fix_read_release( void );
extern void             dr_fix_read_claim( void );

extern void             dr_set_operating_mode( tUInt );
extern tUInt            dr_get_operating_mode( void );

extern void             dr_set_dwp_counter_max_value( tUInt dwp_counter_max_value );
extern tUInt            dr_get_dwp_counter_max_value( void );

extern void             dr_set_dwp_speed_parameters( dr_speed_unit_t , tDouble );

extern void             dr_set_sensor_type( sm_sensor_type_t sensor );
extern sm_sensor_type_t dr_get_sensor_type( void );

extern void             dr_set_odometer_source_type( tU8 odo_source_type );
extern tU8              dr_get_odometer_source_type( void );

/*Set Sensors Calibration */
extern void             dr_set_yaw_rate_gain( const tDouble );
extern void             dr_set_yaw_rate_offset( const tDouble );
extern void             dr_set_odo_scale( const tDouble );

/*Set sensors sensitivity */
extern void             dr_set_pres_sensitivity( const tUInt );

extern void             dr_set_calibration( const tDouble, const tDouble, const tDouble );
extern void             dr_set_calibration_from_vehicle_parameters( const tDouble, const tDouble, const tDouble );

extern void             dr_set_custom_init_mode( void );
extern void             dr_set_nvm_init_mode( void );
extern void             dr_set_wait_gnss_fix_init_mode( void );

extern void             dr_enable_output_messages( boolean_t on_off );
extern void             dr_set_sensors_msg_queue_timeout( gpOS_clock_t timeout );


/* Set\Get kalman filter parameters */
extern void             dr_lock_offset( const boolean_t );
extern void             dr_lock_gain( const boolean_t );
extern void             dr_lock_scale( const boolean_t );
extern boolean_t        dr_get_gyro_integrity( void );
extern math_ellipse_t   dr_get_error_ellipse( void );


extern void             dr_set_q_offs( const tDouble );
extern void             dr_set_q_gain( const tDouble );
extern void             dr_set_q_scale( const tDouble );

extern void             dr_set_p_offs( const tDouble );
extern void             dr_set_p_gain( const tDouble );
extern void             dr_set_p_scale( const tDouble );

extern tDouble          dr_get_q_offs( void );
extern tDouble          dr_get_q_gain( void );
extern tDouble          dr_get_q_scale( void );

extern tDouble          dr_get_p_offs( void );
extern tDouble          dr_get_p_gain( void );
extern tDouble          dr_get_p_scale( void );

extern void             dr_set_max_r_position_cn0( tDouble );
extern tDouble          dr_get_max_r_position_cn0( void );

extern void             dr_set_gnss_cn0_thr( const tU8 );
extern tU8              dr_get_gnss_cn0_thr( void );

extern void             dr_set_static_calib ( const boolean_t);
extern boolean_t        dr_get_static_calib ( void );

extern void             dr_set_installation_angles( dr_installation_angles_t );
extern dr_installation_angles_t  dr_get_installation_angles( void );

extern void             dr_set_gyro_axes_mask(const tS8, const tS8, const tS8);
extern void             dr_get_gyro_axes_mask(tS8 * , tS8 *, tS8 * );

extern void             dr_set_auto_tilt_compensation( boolean_t );
extern boolean_t        dr_get_auto_tilt_compensation( void );

extern gnss_error_t     dr_calc_gyro_axes_mask(const tS8 * , const tS8 * , tS8 * ) ;

extern void             dr_set_acc_axes_mask(const tS8, const tS8, const tS8);
extern void             dr_get_acc_axes_mask(tS8 * , tS8 *, tS8 * );

extern void             dr_set_reference_gyro_axes_mask(const tS8, const tS8, const tS8);
extern void             dr_get_reference_gyro_axes_mask(tS8 * , tS8 *, tS8 * );

extern void             dr_set_ovst( const tDouble );
extern tDouble          dr_get_ovst( void );

extern void             dr_set_auto_ovst_determination( boolean_t );
extern boolean_t        dr_get_auto_ovst_determination( void );

extern void             dr_set_fix_rate( const tU8 );
extern tU8              dr_get_fix_rate( void );

extern void             dr_set_mmfb_data(dr_mmfb_data_t * mmfb);
extern void             dr_get_mmfb_data(dr_mmfb_data_t * mmfb);
extern void             dr_set_mmfb_onoff(const boolean_t val);
extern boolean_t        dr_get_mmfb_onoff( void );

extern gpOS_clock_t     dr_fix_get_time( void );
extern boolean_t        dr_fix_is_extrapolated( void );

extern void             dr_get_pitch(tDouble *, tDouble *);
extern gnss_error_t     dr_get_status_backup( dr_status_backup_t * dr_status_backup);

extern void             dr_set_gyro_only_tilt_calc( const boolean_t );
extern boolean_t        dr_get_gyro_only_tilt_calc( void );

extern void             dr_set_nvmsave_cmd_request(const boolean_t);
extern boolean_t        dr_get_nvmsave_cmd_request( void );

extern void             dr_initialize_Callbacks(void);

extern void             dr_set_acc_resolution( const tUInt );
extern tUInt            dr_get_acc_resolution( void );

extern void             dr_set_3d_onoff(const boolean_t);
extern boolean_t        dr_get_3d_onoff( void );

extern void             dr_set_gyro_sensitivity_range( const tDouble, const tDouble );
extern void             dr_get_gyro_sensitivity_range( tDouble*, tDouble* );

extern void             dr_set_gyro_int_stop(const boolean_t);
extern boolean_t        dr_get_gyro_int_stop( void );

extern void             dr_set_DrNvmSave_stop(const boolean_t);
extern boolean_t        dr_get_DrNvmSave_stop( void );

extern void             dr_set_gyro_cal_for_fix(const boolean_t val);
extern boolean_t        dr_get_gyro_cal_for_fix( void );

extern void             dr_set_meas_weight(CONST dr_meas_weight_cfg_t *);
extern void             dr_get_meas_weight(dr_meas_weight_cfg_t *);

#ifdef __cplusplus
}
#endif

#endif /* DR_API_H */
