/*!
 * dr_pres.h
 * Defines the interface for Pressure sensor.  Introduce for STA8090EXG
 */
#ifndef DR_PRES_H
#define DR_PRES_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_bsp_defs.h"
#include "gnss_defs.h"
#include "lld_gpio.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#define DR_PRES_SPI_ID                  0U
#define DR_PRES_SPI_INT_PRIORITY        10

#define DR_ST_MEMS_PRES_LPS25H_TYPE     0xBD

#define DR_PRES_SPI_GPIO_ADDR           (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define DR_PRES_SPI_CS_PIN              LLD_GPIO_PIN15
#define DR_PRES_SPI_CS_PIN_MODE         LLD_GPIO_MODE_ALTA
#define DR_PRES_SPI_BUS_FREQUENCY       1000000

#define DR_PRES_CONF_GPIO_MASK          0x3fU
#define DR_PRES_GPIO0_LAST_CH           (32)
#define DR_PRES_GPIO1_LAST_CH           LLD_GPIOCHUNDEF
#define DR_PRES_NOT_CONFIG              ((tU32)0xffffffffU)

#define DR_PRES_RES_CONF_REG            0x10U
#define DR_PRES_STATUS_REG              0x27U
#define DR_PRES_CTRL_REG1               0x20U
#define DR_PRES_CTRL_REG2               0x21U
#define DR_PRES_ACTIVE_MODE_ENABLE      0x80U
#define DR_PRES_OUTPUT_RATE_RESET       0x8FU
#define DR_PRES_OUTPUT_DATA_RATE        0x20U
#define DR_PRES_OUT_XL_ADDRESS          0x28U

#define DR_PRES_WHO_AM_I                0x0FU

#define DR_PRES_READ_OPERATION          0x80U
#define DR_PRES_INCREMENT_ADDRESS       0x40U
#define DR_PRES_SPI_READ_COMMAND_BYTE   (tU8)(DR_PRES_OUT_XL_ADDRESS | DR_PRES_READ_OPERATION | DR_PRES_INCREMENT_ADDRESS)

#define DR_PRES_SLAVE_ADDR              0x5CU
#define DR_PRES_I2C_AUTO_INC_MASK       0x80U  /* Register address in automatically incremented to allow multiple data r/w */

#define DR_PRES_BDU                     0x04U
#define DR_PRES_RESET_AZ                0x02U
#define DR_PRES_SW_RESET                0x04U
#define DR_PRES_BOOT                    0x80U
#define DR_PRES_AUTO_ZERO               0x02U

#define DR_PRES_DATA_MASK               0x00ffffffU
#define DR_PRES_DEFAULT_RESOLUTION      4096U

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct dr_Pres_msg_tag
{
  gpOS_clock_t  pres_cpu_time;
  tU32          pres_data;
} dr_Pres_sample_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t   dr_Pres_init            ( tU8 , tU8  ) ;
extern gnss_error_t   dr_Pres_CS_init         ( tU8 , tU8 , tU8 );
extern gpOS_error_t   dr_pres_receive_sample  ( dr_Pres_sample_t *);
extern void           dr_Pres_capture_sample  ( void);

#ifdef __cplusplus
}
#endif

#endif /* DR_PRES_H */
