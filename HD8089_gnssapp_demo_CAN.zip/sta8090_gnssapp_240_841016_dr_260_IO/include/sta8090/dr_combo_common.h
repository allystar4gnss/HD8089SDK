/*!
 * dr_combo_common.h
 * Defines special types for combo sensor.
 */
#ifndef DR_COMBO_COMMON_H
#define DR_COMBO_COMMON_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "dr_sensors_api.h"
#if defined(__STA8088__) || defined(__STA8090__)
#include "svc_ssp.h"
#include "svc_i2c.h"
#endif

/*****************************************************************************
   defines and macros
*****************************************************************************/

// ASM330LXH
#define DR_COMBO_ASM330LXH_ODR_100Hz              0x60U   /*(3<<5)*/
#define DR_COMBO_ASM330LXH_ODR_50Hz               0x40U   /*(1<<6)*/
#define DR_COMBO_ASM330LXH_ODR_MASK               0xE0U   /*(7<<5)*/
#define DR_COMBO_ASM330LXH_BW_SCAL_ODR_0          0x04U   /*(1<<2)*/
#define DR_COMBO_ASM330LXH_FIFO_CTRL              0x1AU
#define DR_COMBO_ASM330LXH_FIFO_MODE_MASK         0x07U
#define DR_COMBO_ASM330LXH_FIFO_MODE              0x20U   /*(1<<5)*/
#define DR_COMBO_ASM330LXH_FIFO_EN                0x02U   /*(1<<1)*/
#define DR_COMBO_ASM330LXH_FIFO_STOP_ON_FTH       0x01U
#define DR_COMBO_ASM330LXH_FIFO_TEMP_EN           0x10U   /*(1<<4)*/
#define DR_COMBO_ASM330LXH_REG00                  0x00U
#define DR_COMBO_ASM330LXH_REG45                  0x45U
#define DR_COMBO_ASM330LXH_REG46                  0x46U
#define DR_COMBO_ASM330LXH_REG47                  0x47U

//LSM6DS3
#define DR_COMBO_LSM6DS3_ODR_52Hz                 0x30U   // ODR set to 52Hz FS_XL:00 BW_XL:00
#define DR_COMBO_LSM6DS3_ODR_104Hz                0x40U   /*(1<<6)*/
#define DR_COMBO_LSM6DS3_ODR_MASK                 0xF0U   /*(0x0F<<4)*/
#define DR_COMBO_LSM6DS3_ODR_BW_SCAL_ODR          0x80U   /*(1<<7)*/    // ODR set to 52Hz FS_XL:00 BW_XL:00
#define DR_LSM6DS3_MASTER_CONFIG                  0x1AU
#define DR_LSM6DS3_DATA_VALID_SEL_FIFO            0x40U
#define DR_LSM6DS3_PATH_THROUGH_MODE              0x04U
#define DR_LSM6DS3_START_CONFIG                   0x10U
#define DR_LSM6DS3_PULL_UP_EN                     0x08U
#define DR_COMBO_LSM6DS3_FIFO_CTRL1               0x06U
#define DR_COMBO_LSM6DS3_FIFO_CTRL2               0x07U
#define DR_COMBO_LSM6DS3_FIFO_CTRL3               0x08U
#define DR_COMBO_LSM6DS3_FIFO_CTRL4               0x09U
#define DR_COMBO_LSM6DS3_FIFO_CTRL5               0x0AU
#define DR_COMBO_LSM6DS3_BYPASS_MODE_MASK         0x07U
#define DR_COMBO_LSM6DS3_FIFO_CONT_MODE           0x06U
#define DR_COMBO_LSM6DS3_FIFO_FULL_MODE           0x01U
#define DR_COMBO_LSM6DS3_FIFO_STATUS1             0x3AU
#define DR_COMBO_LSM6DS3_FIFO_OVERRUN_MASK        0x40U
#define DR_COMBO_LSM6DS3_FIFO_FULL_MASK           0x20U
#define DR_COMBO_LSM6DS3_FIFO_EMPTY_MASK          0x10U
#define DR_COMBO_LSM6DS3_FIFO_FTH_MASK            0x80U
#define DR_COMBO_LSM6DS3_FIFO_DATA_OUT_L          0x3EU
#define DR_LSM6DS3_ODR_STEP                       0x0DU   // 13Hz: Min ODR for LSM6DS3

// Common ASM330LXH; LSM6DS3
#define DR_6DACC_CTRL1_XL                         0x10U
#define DR_3D6DACC_OUT_X_L_ADDRESS                0x28U
#define DR_COMBO_CTRL3_C                          0x12U
#define DR_COMBO_CTRL4_C                          0x13U
#define DR_COMBO_IF_ADD_INC                       0x04U   /*(1<<2)*/
#define DR_COMBO_BDU_MASK                         0x40U
#define DR_6DACC_CTRL9_XL                         0x18U
#define DR_6DACC_ACC_XYZ_ENABLED                  0x38U   /*(7<<3)*/
#define DR_6DACC_CTRL8_XL                         0x17U
#define DR_COMBO_STOP_ON_FTH                      0x01U   // in CTRL4_C register; used for FIFO mode


// ASM330LXH Constants for Gyro
#define DR_6DGYRO_ASM330LXH_FS_125                0x04U   /*(1<<2)*/
#define DR_6DGYRO_ASM330LXH_FS_MASK               0x1CU   /*(7<<2)*/
#define DR_COMBO_ASM330LXH_INT2_CTRL              0x0EU
#define DR_COMBO_ASM330LXH_INT2_DISABLED          0x03U

//LSM6DS3 Constants for Gyro
#define DR_6DGYRO_LSM6DS3_FS_125                  0x02U   /*(1<<1)*/
#define DR_6DGYRO_LSM6DS3_FS_MASK                 0x0FU

// Common ASM330LXH; LSM6DS3/LSM6DSM Constants for Gyro
#define DR_6DGYRO_OUT_TEMP_ADDRESS                0x20U
#define DR_6DGYRO_OUT_X_G_ADDRESS                 0x22U
#define DR_6DGYRO_CTRL2_G                         0x11U
#define DR_6DGYRO_CTRL10_C                        0x19U
#define DR_6DGYRO_G_XYZ_ENABLED                   0x38U   /*(7<<3)*/

#define DR_6DGYRO_TEMP_SENSOR_SENSITIVITY         0x10U   // ASM330LXH-LSM6DS3 Temperature sensitivity = 16 LSB/�C
#define DR_6DGYRO_TEMP_SENSOR_SENS_256            256U    // ASM330LXH-LSM6DS3 Temperature sensitivity = 16 LSB/�C


// BMI160
#define DR_COMBO_CHIPID_REGISTER                  0x00U   // BMI160
#define DR_COMBO_ID_BMI160                        0xD1U   // BMI160

#define DR_COMBO_BMI160_ACC_CONF                  0x40U   // ACC_CONF register address
#define DR_COMBO_BMI160_ACC_US_NORMAL             0x00U   // acc_us =0b0  undersampling disable in normal mode
#define DR_COMBO_BMI160_ACC_BWP_NORMAL            0x20U   // acc_bwp =0b10
#define DR_COMBO_BMI160_ACC_ODR_50Hz              0x07U   // acc_odr =0b0111

#define DR_COMBO_BMI160_ACC_RANGE                 0x41U   // ACC_RANGE register address
#define DR_COMBO_BMI160_ACC_RANGE_RESET           0xF0U   // acc_range reset value
#define DR_COMBO_BMI160_ACC_RANGE_FS_2G           0x03U   // acc_odr =0b011

#define DR_COMBO_BMI160_GYR_CONF                  0x42U   // GYR_CONF register address
#define DR_COMBO_BMI160_GYR_BWP_NORMAL            0x20U   // gyr_bwp =0b10
#define DR_COMBO_BMI160_GYR_ODR_50Hz              0x07U   // gyr_odr =0b0111
#define DR_COMBO_BMI160_GYR_CONF_RES              0xC0U   // reserved
#define DR_COMBO_BMI160_GYR_RANGE_FS_125          0x04U   // gyr_odr =0b100
#define DR_COMBO_BMI160_GYR_RANGE_RES             0xF8U   // reserved

#define DR_COMBO_BMI160_FIFO_CONFIG1              0x47U   // FIFO_CONFIG1 register address
#define DR_COMBO_BMI160_NO_FIFO                   0x10U   // fifo_gyr_en =0; fifo_acc_en=0; fifo_mag_en=0; fifo_header_en=1
#define DR_COMBO_BMI160_FIFO1_RES                 0x01U   // reserved value

#define DR_COMBO_BMI160_ACC_OUT_X_L_ADDRESS       0x12U   // ACC_X register address

#define DR_COMBO_BMI160_GYR_OUT_X_L_ADDRESS       0x0CU   // ACC_X register address

#define DR_COMBO_BMI160_TEMP_ADDRESS              0x20U   // Temperature register address
#define DR_COMBO_BMI160_TEMP_SENSOR_SENSITIVITY   512U    //  =2^9 BMI160 Temperature sensitivity = 1/2^9 K/LSB
#define DR_COMBO_TEMP_CONST                       23U     // Value 0 -> 23�c

#define DR_COMBO_BMI160_CMD_REGISTER              0x7EU   // CMD Register
#define DR_COMBO_BMI160_ACC_SET_PMU_NORMAL_MODE   0x11U   // acc_pmu_status=0b01 normal mode
#define DR_COMBO_BMI160_GYR_SET_PMU_NORMAL_MODE   0x15U   // gyr_pmu_status=0b01 normal mode

#define DR_COMBO_BMI160_ERR_REG                   0x02U   // ERR Register address

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef enum dr_raw_sensors_data_req_type_e
{
  NO_RAW_SENSORS_DATA_REQ = 0U,
  DR_3DACC_RAW_SENSOR_DATA_REQ,
  DR_3DGYRO_RAW_SENSOR_DATA_REQ,
  DR_6XCOMBO_RAW_SENSOR_DATA
}dr_raw_sensors_data_req_type_t;

typedef enum dr_sensors_type_e
{
  DR_6XCOMBO_LSM6DS3 = 0U,
  DR_6XCOMBO_ASM330_LXH,
  DR_6XCOMBO_LSM6DSM,
  DR_UNKNOWN_SENSOR_TYPE
}dr_sensors_id_t;

typedef enum dr_sensors_odr_fifo_value_LSM6DS3_e
{
  DR_LSM6DS3_ODR_13Hz = 1U,
  DR_LSM6DS3_ODR_26Hz,
  DR_LSM6DS3_ODR_52Hz,
  DR_LSM6DS3_ODR_104Hz,
  DR_LSM6DS3_ODR_208Hz,
  DR_LSM6DS3_ODR_416Hz,
  DR_LSM6DS3_ODR_833Hz,
  DR_LSM6DS3_ODR_1660Hz,
  DR_LSM6DS3_ODR_3330Hz,
  DR_LSM6DS3_ODR_6660Hz
}dr_sensors_odr_fifo_value_LSM6DS3_t;

typedef enum dr_sensors_odr_fifo_value_ASM330LXH_e
{
  DR_ASM330LXH_ODR_12_5Hz = 1U,
  DR_ASM330LXH_ODR_50Hz,
  DR_ASM330LXH_ODR_100Hz,
  DR_ASM330LXH_ODR_200Hz,
  DR_ASM330LXH_ODR_400Hz,
  DR_ASM330LXH_ODR_800Hz
 }dr_sensors_odr_fifo_value_ASM330LXH_t;


/*{{{  dr_sensors_odr_fifo_value_t*/
typedef union
{
  dr_sensors_odr_fifo_value_LSM6DS3_t      odr_fifo_LSM6DS3;
  dr_sensors_odr_fifo_value_ASM330LXH_t    odr_fifo_ASM330LXH;
} dr_sensors_odr_fifo_value_t;

typedef struct dr_fifo_info_tag
{
  tUShort                     odr_freq;
  tUShort                     number_elements_in_Fifo;
  tUInt                       dr_sampling;
  dr_sensors_odr_fifo_value_t odr_val;
  dr_sensors_id_t             combo_id_req;
  boolean_t                   dr_3Dacc_FiFoModeEn;
  boolean_t                   dr_3DGyro_FiFoModeEn;
  tU8                         Decimation_Fifo_Acc;
  tU8                         Decimation_Fifo_Gyro;
} dr_fifo_info_t;


/*****************************************************************************
   exported variables
*****************************************************************************/

extern dr_fifo_info_t           dr_fifo_info;
#if defined(__STA8088__) || defined(__STA8090__)
extern svc_ssp_com_handler_t *  dr_3D6Dacc_spi_com_hnd;
extern svc_i2c_com_handler_t *  dr_3D6Dacc_i2c_com_hnd;
#endif

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t dr_combo_read_CtrlReg       ( void);
extern void         dr_combo_reset_dr_info_fifo ( void);
extern void         dr_combo_set_raw_data_req   ( const dr_raw_sensors_config_t);

#ifdef __cplusplus
}
#endif

#endif /* DR_COMBO_COMMON_H */
