//!
//!   \file     logger.h
//!   \brief    <i><b> GNSS data logging feature</b></i>
//!   \author   Andrea Di Girolamo
//!   \version  1.0
//!   \date     2016.12.16
//!   \bug      Unknown
//!   \warning  None
//!


#ifndef ODOMETER_H
#define ODOMETER_H

/*****************************************************************************
   includes
*****************************************************************************/

// OS related
#include "gpOS.h"

// GPS library
#include "gnss_defs.h"

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/

#define ODOMETER_CONFIG_PARAMS_N  2U

#define ODOMETER_A      0x1U
#define ODOMETER_B      0x2U
#define ODOMETER_TOTAL  0x4U

/*****************************************************************************
   typedefs and structures (scope: module-local)
*****************************************************************************/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gpOS_error_t odometer_init(gpOS_partition_t *part, tUInt *config);
extern tVoid odometer_update_data(gnss_time_t *utc_time,position_t *pos, velocity_t *vel, fix_status_t fix_status);
extern tVoid odometer_reset_data(tUInt type);
extern gnss_error_t odometer_get_data(tUInt type, tUInt *timestamp, tUInt *odometer);
extern gpOS_error_t odometer_nmea_outmsg_transmit( void *param);
extern tInt odometer_nmea_cmdif_parse( tChar *input_cmd_msg, tUInt cmd_size, tChar *cmd_par);

#endif  // _LVD_MGMT_H_

// End of file
