/*******************************************************************************
 *                            (C) 2009 STMicroelectronics
 *    Reproduction and Communication of this document is strictly prohibited
 *      unless specifically authorized in writing by STMicroelectronics.
 *-----------------------------------------------------------------------------
 *                                  APG / CRM / SA&PD
 *                   Software Development Group - SW platform & HW Specific
 *-----------------------------------------------------------------------------
 * Header file for specific operative system header
 *
 ******************************************************************************/

#ifndef GNSS_OS_H
#define GNSS_OS_H

#include "gpOS.h"

#endif /* GNSS_OS_H */


