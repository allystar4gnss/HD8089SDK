#ifndef SW_CONFIG
#define SW_CONFIG

/*****************************************************************************
   includes
*****************************************************************************/

#include "typedefs.h"

#include "gnss_defs.h"

#ifdef SW_CONFIG_PRIVATE_BLOCK
  #include "sw_config_private.h"
#endif

/*****************************************************************************
   defines and macros
*****************************************************************************/

/* First APP ON/OFF parameter */
#define NMEA_PORT_TMODE_SWITCH                0x1U
#define GPS_2D_FIX_SWITCH                     0x2U
#define WAAS_ON_OFF_SWITCH                    0x4U
#define WAAS_SAT_ON_GSV                       0x8U
#define STAGPS_ON_OFF_SWITCH                  0x10U
#define ACQ_2_5_PPM_TCXO_SWITCH               0x20U
#define NMEA_301_FORMAT_SWITCH                0x40U
#define QZSS_SLOW_ACQUISITION_MODE_SWITCH     0x80U
#define POSITION_STATIC_FILTER_SWITCH         0x100U    /*not used on sta2062/sta2064*/
#define CONFIG_TEXT_AS_HEADER_SWITCH          0x200U
#define ST_HEADERS_SWITCH                     0x400U
#define RTCM_ON_OFF_SWITCH                    0x800U
#define GPS_FDE_SWITCH                        0x1000U
#define GPS_ADS_SWITCH                        0x2000U
#define GPS_WALKING_MODE_SWITCH               0x4000U
#define GPS_STOP_DETECTION_SWITCH             0x8000U
#define GPS_ON_OFF_SWITCH                     0x10000U
#define GLONASS_ON_OFF_SWITCH                 0x20000U
#define QZSS_ON_OFF_SWITCH                    0x40000U
#define NMEA_GNGSV_ENABLE                     0x80000U
#define NMEA_GNGSA_ENABLE                     0x100000U
#define GLONASS_USE_ON_OFF_SWITCH             0x200000U
#define GPS_USE_ON_OFF_SWITCH                 0x400000U
#define QZSS_USE_ON_OFF_SWITCH                0x800000U
#define PPS_ON_OFF_SWITCH                     0x1000000U
#define PPS_INVERTED_POLARITY_ON_OFF_SWITCH   0x2000000U
#define POSITION_HOLD_ON_OFF_SWITCH           0x4000000U
#define TIMING_TRAIM_ON_OFF_SWITCH            0x8000000U
#define WAAS_AUTOSEARCH_ON_OFF_SWITCH         0x10000000U
#define HIGH_DYNAMICS_ON_OFF_SWITCH           0x20000000U
#define NMEA_RAW_ON_OFF_SWITCH                0x40000000U
#define LOW_POWER_ON_OFF_SWITCH               0x80000000U

/* Second APP ON/OFF parameter */
#define NMEA_CMDIF_ECO_ON_OFF_SWITCH          0x1U
#define NMEA_TTFF_MSG_ON_OFF_SWITCH           0x2U
#define FEW_SATS_POS_EST_ON_OFF_SWITCH        0x4U
#define STBIN_ON_OFF_SWITCH                   0x8U
#define SMART_XTAL_SUPPORT_ON_OFF_SWITCH      0x10U
#define NMEA_IN_OUT_INTERFACE_SWITCH          0x20U
#define GALILEO_ON_OFF_SWITCH                 0x40U
#define GALILEO_USE_ON_OFF_SWITCH             0x80U
#define COMPASS_ON_OFF_SWITCH                 0x100U
#define COMPASS_USE_ON_OFF_SWITCH             0x200U
#define LVD_MONITOR_ON_OFF_SWITCH             0x400U
#define RTC_USAGE_DISABLING_ON_OFF_SWITCH     0x800U
#define GNSS_FAST_CN0_MODE_ON_OFF_SWITCH      0x1000U
#define NMEA_MESSAGE_TIMESTAMP_SWITCH         0x2000U
#define SAT_EXCL_PRESENT_GSA_GGA              0x4000U
#define WLS_ALGO_RUNTIME_ON_OFF_SWITCH        0x8000U
#define RTCM3_ENC_ON_OFF_SWITCH               0x20000U
#define RTCM_VERSION_SWITCH                   0x40000U
#define L2C_ON_OFF_SWITCH                     0x80000U
#define L2C_USE_ON_OFF_SWITCH                 0x100000U
#define EXT_RTC_OSCI_ON_OFF_SWITCH            0x200000U
#define MFREQ_GPS_ON_OFF_SWITCH               0x400000U
#define MFREQ_GLONASS_ON_OFF_SWITCH           0x800000U
#define MFREQ_GALILEO_ON_OFF_SWITCH           0x1000000U
#define MFREQ_COMPASS_ON_OFF_SWITCH           0x2000000U
#define RTC_CALIBRATION_ON_OFF_SWITCH         0x4000000U

#define SW_CONFIG_TEXT_LENGTH           72

#define SW_CONFIG_KEY                   0xaef5321aU,0xb0134ac0U,0x3f855aa0U,0xdef0a534U
#define SW_CONFIG_CHECKSUM              0

/**
 * @brief   Software config package tag IDs.
 */
#define SWCFG_PKG_ITMS_SEC1             0
#define SWCFG_PKG_ITMS_SEC2             1
#define SWCFG_PKG_ITMS_SEC3             2
#define SWCFG_PKG_ITMS_SEC4             3
#define SWCFG_PKG_ITMS_SEC5             4
#define SWCFG_PKG_ITMS_PRVT_MAX_PAR     5
#define SWCFG_PKG_ITMS_7                6
#define SWCFG_PKG_ITMS_PLAT_ID          7

/**
 * @brief   Software configuration section version mask and offsets.
 */
#define SWCFG_SEC_1_VERSION_MASK        0x03U
#define SWCFG_SEC_1_VERSION_OFF         0U
#define SWCFG_SEC_2_VERSION_MASK        0x3FU
#define SWCFG_SEC_2_VERSION_OFF         2U
#define SWCFG_SEC_3_VERSION_MASK        0x0FU
#define SWCFG_SEC_3_VERSION_OFF         8U
#define SWCFG_SEC_4_VERSION_MASK        0x03U
#define SWCFG_SEC_4_VERSION_OFF         12U
#define SWCFG_SEC_5_VERSION_MASK        0x03U
#define SWCFG_SEC_5_VERSION_OFF         14U
#define SWCFG_SEC_6_VERSION_MASK        0x3FU
#define SWCFG_SEC_6_VERSION_OFF         16U
#define SWCFG_HEADER_MASK               0xFFU
#define SWCFG_HEADER_OFF                24U

/**
 * @name    Software configuration version
 * @{
 */
/**
 * @brief   Platform identifier.
 */
#if defined( __STA8090__)
#define SWCFG_PLATFORM_ID               0x81
#else
#define SWCFG_PLATFORM_ID               0x80
#endif

/**
 * @brief   Software configuration section 1 version.
 * @notes   Must be incremented by one on each modification on this section.
 */
#define SWCFG_SEC_1_VERSION             1U

/**
 * @brief   Software configuration section 2 version.
 * @notes   Must be incremented by one on each modification on this section.
 */
#define SWCFG_SEC_2_VERSION             5U

/**
 * @brief   Software configuration section 3 version.
 * @notes   Must be incremented by one on each modification on this section.
 */
#define SWCFG_SEC_3_VERSION             3U

/**
 * @brief   Software configuration section 4 version.
 * @notes   Must be incremented by one on each modification on this section.
 */
#define SWCFG_SEC_4_VERSION             1U

/**
 * @brief   Software configuration section 5 version.
 * @notes   Must be incremented by one on each modification on this section.
 */
#define SWCFG_SEC_5_VERSION             1U

/**
 * @brief   Software configuration section 6 version.
 * @notes   Must be incremented by one on each modification on this section.
 */
#define SWCFG_SEC_6_VERSION             4U
/** @} */

/**
 * @name    Software configuration sections
 * @{
 */
/**
 * @brief   Sections identifiers.
 */
#define SW_CONFIG_SEC_1                 1U
#define SW_CONFIG_SEC_2                 2U
#define SW_CONFIG_SEC_3                 3U
#define SW_CONFIG_SEC_4                 4U
#define SW_CONFIG_SEC_5                 5U

/**
 * @brief   Sections number of items.
 */
#define SW_CONFIG_SEC_1_ITEMS           104U
#define SW_CONFIG_SEC_2_ITEMS           72U
#define SW_CONFIG_SEC_3_ITEMS           26U
#define SW_CONFIG_SEC_4_ITEMS           4U
#define SW_CONFIG_SEC_5_ITEMS           1U

/**
 * @brief   Sections offsets.
 */
#define SW_CONFIG_SEC_1_OFFSET          (0x0)
#define SW_CONFIG_SEC_2_OFFSET          (SW_CONFIG_SEC_1_OFFSET + (SW_CONFIG_SEC_1_ITEMS * sizeof(tU8)))
#define SW_CONFIG_SEC_3_OFFSET          (SW_CONFIG_SEC_2_OFFSET + (SW_CONFIG_SEC_2_ITEMS * sizeof(tInt)))
#define SW_CONFIG_SEC_4_OFFSET          (SW_CONFIG_SEC_3_OFFSET + (SW_CONFIG_SEC_3_ITEMS * sizeof(tDouble)))
#define SW_CONFIG_SEC_5_OFFSET          (SW_CONFIG_SEC_4_OFFSET + (SW_CONFIG_SEC_4_ITEMS * sizeof(sw_config_dops_t)))
#define SW_CONFIG_SEC_6_OFFSET          (SW_CONFIG_SEC_5_OFFSET + SW_CONFIG_TEXT_LENGTH)
/** @} */

#define SW_CONFIG_BAUDRATE_300_BPS      (tU8)0x0
#define SW_CONFIG_BAUDRATE_600_BPS      (tU8)0x1
#define SW_CONFIG_BAUDRATE_1200_BPS     (tU8)0x2
#define SW_CONFIG_BAUDRATE_2400_BPS     (tU8)0x3
#define SW_CONFIG_BAUDRATE_4800_BPS     (tU8)0x4
#define SW_CONFIG_BAUDRATE_9600_BPS     (tU8)0x5
#define SW_CONFIG_BAUDRATE_14400_BPS    (tU8)0x6
#define SW_CONFIG_BAUDRATE_19200_BPS    (tU8)0x7
#define SW_CONFIG_BAUDRATE_38400_BPS    (tU8)0x8
#define SW_CONFIG_BAUDRATE_57600_BPS    (tU8)0x9
#define SW_CONFIG_BAUDRATE_115200_BPS   (tU8)0xA
#define SW_CONFIG_BAUDRATE_230400_BPS   (tU8)0xB
#define SW_CONFIG_BAUDRATE_460800_BPS   (tU8)0xC
#define SW_CONFIG_BAUDRATE_921600_BPS   (tU8)0xD
#define SW_CONFIG_BAUDRATE_INVALID      (tU8)0xE

#define SWCFG_OUTPUT_CFG_DEBUG_MASK     0x0FU
#define SWCFG_OUTPUT_CFG_DEBUG_UART     ((tU32)1 << 0U)
#define SWCFG_OUTPUT_CFG_DEBUG_USB      ((tU32)1 << 1U)
#define SWCFG_OUTPUT_CFG_DEBUG_FILE     ((tU32)1 << 2U)
#define SWCFG_OUTPUT_CFG_DEBUG_SOCK     ((tU32)1 << 3U)
#define SWCFG_OUTPUT_CFG_DEBUG_SERIAL   ((tU32)1 << 3U)
#define SWCFG_OUTPUT_CFG_NMEA_MASK      0xF0U
#define SWCFG_OUTPUT_CFG_NMEA_UART      ((tU32)1 << 4U)
#define SWCFG_OUTPUT_CFG_NMEA_USB       ((tU32)1 << 5U)
#define SWCFG_OUTPUT_CFG_NMEA_FILE      ((tU32)1 << 6U)
#define SWCFG_OUTPUT_CFG_NMEA_SOCK      ((tU32)1 << 7U)
#define SWCFG_OUTPUT_CFG_NMEA_SERIAL    ((tU32)1 << 7U)

#define NOTCH_FILTER_DISABLED               0x0U
#define NOTCH_FILTER_ENABLED_GPS            0x1U
#define NOTCH_FILTER_ENABLED_GLONASS        0x2U
#define NOTCH_FILTER_ENABLED_AUTO_GPS       0x4U
#define NOTCH_FILTER_ENABLED_AUTO_GLONASS   0x8U
#define HW_SOC_CFG                          0x0U
#define HW_SAL_CFG                          0x1U

#define GLONASS_OUTPUT_FORMAT_FREQ          0x0U
#define GLONASS_OUTPUT_FORMAT_SLOT          0x1U

#define DELAY_TO_NEXT_FIX_50                (gpOS_clock_t)(50.0 * (tDouble)(NAV_CPU_TICKS_PER_SECOND/1000))
#define DELAY_TO_NEXT_FIX_500               (gpOS_clock_t)(500.0 * (tDouble)(NAV_CPU_TICKS_PER_SECOND/1000))

#define SWCFG_DEBUG_MSG_ON_OFF                ((tU32)1 << 0U)
#define SWCFG_NMEA_INPUT_ON_DEBUG             ((tU32)1 << 4U)
#define SWCFG_NMEA_OUTPUT_ON_DEBUG_ENABLE     ((tU32)1 << 5U)
#define SWCFG_NMEA_OUTPUT_ENABLE              ((tU32)1 << 6U)
#define SWCFG_DUAL_NMEA_PORT_ENABLE           ((tU32)1 << 7U)

/**
 * @brief I2C configurations
 */
#define SWCFG_I2C_NMEA_MASK                 0x00000001U
#define SWCFG_I2C_NMEA_OFF                  0
#define SWCFG_I2C_SLAVE_MASK                0x0000FFC0U
#define SWCFG_I2C_SLAVE_OFF                 6
#define SWCFG_I2C_MODE_MASK                 0x00020000U
#define SWCFG_I2C_MODE_OFF                  16

/**
 * @brief CPU clock speed
 */
#define SWCFG_CLK_SRC_MASK                  0x03U
#define SWCFG_CLK_SRC_OFF                   0U
#define SWCFG_CLK_SRC_192F0                 0x00U
#define SWCFG_CLK_SRC_TCXO                  0x01U
#define SWCFG_CLK_SRC_RTC                   0x02U
#define SWCFG_CLK_SRC_RING                  0x03U
#define SWCFG_CLK_DIV_MASK                  0x70U
#define SWCFG_CLK_DIV_OFF                   4U
#define SWCFG_CLK_DIV_1                     0x00U
#define SWCFG_CLK_DIV_2                     0x10U
#define SWCFG_CLK_DIV_3                     0x20U
#define SWCFG_CLK_DIV_4                     0x30U

/**
 * @brief Antenna sensing ADC channel reading
 */
#define SWCFG_ANTSENS_ADC_CH_ON             0x00000001U
#define SWCFG_ANTSENS_ADC_CH_MASK           0x000001FEU
#define SWCFG_ANTSENS_ADC_CH_MASK_OFF       1U
#define SWCFG_ANTSENS_ADC_CLK_DIV_MASK      0x0001FE00U
#define SWCFG_ANTSENS_ADC_CLK_DIV_OFF       9U

/**
 * @brief Antenna sensing parameters
 */
#define SWCFG_ANTSENS_TYPE_MASK             0x00000003U
#define SWCFG_ANTSENS_TYPE_OFF              0x00000000U
#define SWCFG_ANTSENS_TYPE_RF               0x00000001U
#define SWCFG_ANTSENS_TYPE_ADC              0x00000002U
#define SWCFG_ANTSENS_TYPE_GPIO             0x00000003U
#define SWCFG_ANTSENS_PERIODIC_MSG          0x00000004U
#define SWCFG_ANTSENS_SWITCH_CAP            0x00000008U
#define SWCFG_ANTSENS_CLK_DIV_MASK          0x00000FF0U
#define SWCFG_ANTSENS_CLK_DIV_OFF           4U
#define SWCFG_ANTSENS_MIN_THR_MASK          0x003FF000U
#define SWCFG_ANTSENS_MIN_THR_OFF           16U
#define SWCFG_ANTSENS_MAX_THR_MASK          0xFFC00000U
#define SWCFG_ANTSENS_MAX_THR_OFF           22U

/**
 * @brief Antenna sensing GPIO setting 1
 */
#define SWCFG_ANTSENS_DIGON_ID_MASK         0x000000FFU
#define SWCFG_ANTSENS_DIGON_ID_OFF          0U
#define SWCFG_ANTSENS_SWCTRL_ID_MASK        0x0000FF00U
#define SWCFG_ANTSENS_SWCTRL_ID_OFF         8U
#define SWCFG_ANTSENS_DIGSHORT_ID_MASK      0x00FF0000U
#define SWCFG_ANTSENS_DIGSHORT_ID_OFF       16U
#define SWCFG_ANTSENS_DIGOPEN_ID_MASK       0xFF000000U
#define SWCFG_ANTSENS_DIGOPEN_ID_OFF        24U

/**
 * @brief Antenna sensing GPIO setting 2
 */
#define SWCFG_ANTSENS_MODE_MASK             0x3U
#define SWCFG_ANTSENS_MODE_DEF              0x0U
#define SWCFG_ANTSENS_MODE_ALT_A            0x1U
#define SWCFG_ANTSENS_MODE_ALT_B            0x2U
#define SWCFG_ANTSENS_MODE_ALT_C            0x3U
#define SWCFG_ANTSENS_DIGON_MODE_OFF        0U
#define SWCFG_ANTSENS_SWCTRL_MODE_OFF       8U
#define SWCFG_ANTSENS_DIGSHORT_MODE_OFF     16U
#define SWCFG_ANTSENS_DIGOPEN_MODE_OFF      24U

/**
 * @brief Antenna sensing GPIO setting 3
 */
#define SWCFG_ANTSENS_GPIO_ACTIVE_LOW       0x0
#define SWCFG_ANTSENS_GPIO_ACTIVE_HIGH      0x1
#define SWCFG_ANTSENS_DIGON_LEVEL_OFF       0
#define SWCFG_ANTSENS_SWCTRL_LEVEL_OFF      8
#define SWCFG_ANTSENS_DIGSHORT_LEVEL_OFF    16
#define SWCFG_ANTSENS_DIGOPEN_LEVEL_OFF     24

/**
 * @brief Set parameter modalities
 */
#define SWCFG_MODE_REPLACE                  0
#define SWCFG_MODE_MASK_ONES                1
#define SWCFG_MODE_MASK_ZEROS               2

/**
 * @brief Maximum number of configurable SBAS satellites
 */
#define SBAS_MAX_NUM_OF_SAT                 2

/**
 * @brief SBAS satellite decoding timeouts
 */
#define SWCFG_SBAS_DEC_TIMOUT_MASK          0x0000FFFFU
#define SWCFG_SBAS_DEC_TIMOUT_OFF           0U
#define SWCFG_SBAS_DIFF_TIMOUT_MASK         0x00030000U
#define SWCFG_SBAS_DIFF_TIMOUT_OFF          16U

/**
 * @brief SBAS satellite search timeouts
 */
#define SWCFG_SBAS_NEXTSAT_TIMOUT_MASK      0x0000FFFFU
#define SWCFG_SBAS_NEXTSAT_TIMOUT_OFF       0U
#define SWCFG_SBAS_NEXTSES_TIMOUT_MASK      0x00030000U
#define SWCFG_SBAS_NEXTSES_TIMOUT_OFF       16U

/**
 * @brief SBAS satellite parameters
 */
#define SWCFG_SBAS_PNR_ID_MASK              0x3FU
#define SWCFG_SBAS_PNR_ID_OFF               0
#define SWCFG_SBAS_PNR_ID_MIN               120
#define SWCFG_SBAS_PNR_ID_MAX               138
#define SWCFG_SBAS_LONGITUDE_MASK           0xFF
#define SWCFG_SBAS_LONGITUDE_OFF            8
#define SWCFG_SBAS_LONGITUDE_MAX            180
#define SWCFG_SBAS_LONG_SENS_MASK           0x01
#define SWCFG_SBAS_LONG_SENS_EAST           0x00
#define SWCFG_SBAS_LONG_SENS_WEST           0x01
#define SWCFG_SBAS_LONG_SENS_OFF            16
#define SWCFG_SBAS_SERV_MASK                0x03
#define SWCFG_SBAS_SERV_WAAS                0x00
#define SWCFG_SBAS_SERV_EGNOS               0x01
#define SWCFG_SBAS_SERV_MSAS                0x02
#define SWCFG_SBAS_SERV_GAGAN               0x03
#define SWCFG_SBAS_SERV_OFF                 17

/**
 * @brief Maximum number of compensations
 */
#define SAT_COMP_MAX_NUM_OF_COMP            2

/**
 * @brief PPS Operating Mode setting 1 parameters
 */
#define SWCFG_PPS_GEN_MODE_MASK             0x0000000FU
#define SWCFG_PPS_GEN_MODE_OFF              0
#define SWCFG_PPS_GEN_MODE_EVERY            0x00000000U
#define SWCFG_PPS_GEN_MODE_EVEN             0x00000001U
#define SWCFG_PPS_GEN_MODE_ODD              0x00000002U
#define SWCFG_PPS_REF_MASK                  0x000000F0U
#define SWCFG_PPS_REF_OFF                   4
#define SWCFG_PPS_REF_UTC                   0x00000000U
#define SWCFG_PPS_REF_GPS                   0x00000010U
#define SWCFG_PPS_REF_GLONASS               0x00000020U
#define SWCFG_PPS_REF_UTC_SU                0x00000040U
#define SWCFG_PPS_REF_GPS_GLONASS           0x00000080U
#define SWCFG_PPS_GNSS_MASK                 0x00000F00U
#define SWCFG_PPS_GNSS_OFF                  8
#define SWCFG_PPS_GNSS_NO_FIX               0x00000100U
#define SWCFG_PPS_GNSS_2D_FIX               0x00000200U
#define SWCFG_PPS_GNSS_3D_FIX               0x00000400U
#define SWCFG_PPS_NSAT_MASK                 0x00FF0000U
#define SWCFG_PPS_NSAT_OFF                  16
#define SWCFG_PPS_SAT_ELEV_MASK             0xFF000000U
#define SWCFG_PPS_SAT_ELEV_OFF              24

/**
 * @brief PPS Operating Mode setting 2 parameters
 */
#define SWCFG_PPS_MIX_MASK                  0x000000FFU
#define SWCFG_PPS_MIX_OFF                   0
#define SWCFG_PPS_MIX_DISABLED              0x00000000U
#define SWCFG_PPS_MIX_GPS                   0x00000001U
#define SWCFG_PPS_MIX_GLONASS               0x00000002U

/**
 * @brief Adaptive algorithm parameters
 */
#define SWCFG_ADAPT_ALG_MASK                0x0000000FU
#define SWCFG_ADAPT_ALG_OFF                 0
#define SWCFG_ADAPT_MULTI_EN                0x00000001U
#define SWCFG_ADAPT_DUTY_CYCLE_EN           0x00000002U
#define SWCFG_ADAPT_EPHE_MASK               0x00000FF0U
#define SWCFG_ADAPT_EPHE_OFF                4
#define SWCFG_ADAPT_SAT_MASK                0x000FF000U
#define SWCFG_ADAPT_SAT_OFF                 12
#define SWCFG_ADAPT_SAT_MAX                 32
#define SWCFG_ADAPT_DUTY_MASK               0xFFF00000U
#define SWCFG_ADAPT_DUTY_OFF                20
#define SWCFG_ADAPT_DUTY_MIN                100
#define SWCFG_ADAPT_DUTY_MAX                740

/**
 * @brief Periodic Operating Mode setting 1 parameters
 */
#define SWCFG_PER_OP_MODE_EN_MASK           0x00000003U
#define SWCFG_PER_OP_MODE_EN_OFF            0
#define SWCFG_PER_OP_MODE_EN_DIS            0x00000000U
#define SWCFG_PER_OP_MODE_EN_ACT            0x00000001U
#define SWCFG_PER_OP_MODE_EN_STB            0x00000002U
#define SWCFG_PER_OP_MODE_FEAT_PM_OFF       0x00000000U
#define SWCFG_PER_OP_MODE_FEAT_ACTIVE       0x00000001U
#define SWCFG_PER_OP_MODE_FEAT_STANDBY      0x00000003U
#define SWCFG_PER_OP_MODE_FIX_PER_MASK      0x01FFFF00U
#define SWCFG_PER_OP_MODE_FIX_PER_OFF       8
#define SWCFG_PER_OP_MODE_FIX_PER_MAX       86400
#define SWCFG_PER_OP_MODE_FIX_ON_MASK       0xFE000000U
#define SWCFG_PER_OP_MODE_FIX_ON_OFF        25

/**
 * @brief Periodic Operating Mode setting 2 parameters
 */
#define SWCFG_PER_OP_MODE_NFCNT_MASK        0x000000FFU
#define SWCFG_PER_OP_MODE_NFCNT_OFF         0
#define SWCFG_PER_OP_MODE_NFOFF_MASK        0x000FFF00U
#define SWCFG_PER_OP_MODE_NFOFF_OFF         8
#define SWCFG_PER_OP_MODE_NFCNT2_MASK       0x1FF00000U
#define SWCFG_PER_OP_MODE_NFCNT2_OFF        20

/**
 * @brief Low Power Mode HW Setting parameters
 */
#define SWCFG_LP_MODE_HW_BKLDO_HF_MASK      0x00000003U
#define SWCFG_LP_MODE_HW_BKLDO_HF_OFF       0
#define SWCFG_LP_MODE_HW_BKLDO_HF_DIS       0x00000000U
#define SWCFG_LP_MODE_HW_BKLDO_HF_EN        0x00000001U

#define SWCFG_LP_MODE_HW_BKLDO_LF_MASK      0x0000000CU
#define SWCFG_LP_MODE_HW_BKLDO_LF_DIS       0x00000000U
#define SWCFG_LP_MODE_HW_BKLDO_LF_EN        0x00000004U
#define SWCFG_LP_MODE_HW_BKLDO_LF_OFF       2

#define SWCFG_LP_MODE_HW_LDO1_HF_MASK       0x00000030U
#define SWCFG_LP_MODE_HW_LDO1_HF_OFF        4
#define SWCFG_LP_MODE_HW_LDO1_HF_VOFF       0x00000000U
#define SWCFG_LP_MODE_HW_LDO1_HF_V1P0       0x00000010U
#define SWCFG_LP_MODE_HW_LDO1_HF_V1P1       0x00000020U
#define SWCFG_LP_MODE_HW_LDO1_HF_V1P2       0x00000030U

#define SWCFG_LP_MODE_HW_LDO1_LF_MASK       0x000000C0U
#define SWCFG_LP_MODE_HW_LDO1_LF_OFF        6
#define SWCFG_LP_MODE_HW_LDO1_LF_VOFF       0x00000000U
#define SWCFG_LP_MODE_HW_LDO1_LF_V1P0       0x00000040U
#define SWCFG_LP_MODE_HW_LDO1_LF_V1P1       0x00000080U
#define SWCFG_LP_MODE_HW_LDO1_LF_V1P2       0x000000C0U

#define SWCFG_LP_MODE_HW_LDO2_HF_MASK       0x00000300U
#define SWCFG_LP_MODE_HW_LDO2_HF_OFF        8
#define SWCFG_LP_MODE_HW_LDO2_HF_VOFF       0x00000000U
#define SWCFG_LP_MODE_HW_LDO2_HF_V1P0       0x00000100U
#define SWCFG_LP_MODE_HW_LDO2_HF_V1P1       0x00000200U
#define SWCFG_LP_MODE_HW_LDO2_HF_V1P2       0x00000300U

#define SWCFG_LP_MODE_HW_LDO2_LF_MASK       0x00000C00U
#define SWCFG_LP_MODE_HW_LDO2_LF_OFF        10
#define SWCFG_LP_MODE_HW_LDO2_LF_VOFF       0x00000000U
#define SWCFG_LP_MODE_HW_LDO2_LF_V1P0       0x00000400U
#define SWCFG_LP_MODE_HW_LDO2_LF_V1P1       0x00000800U
#define SWCFG_LP_MODE_HW_LDO2_LF_V1P2       0x00000C00U

#define SWCFG_LP_MODE_HW_SMPS_HF_MASK       0x00003000U
#define SWCFG_LP_MODE_HW_SMPS_HF_OFF        12
#define SWCFG_LP_MODE_HW_SMPS_HF_VOFF       0x00000000U
#define SWCFG_LP_MODE_HW_SMPS_HF_V1P0       0x00001000U
#define SWCFG_LP_MODE_HW_SMPS_HF_V1P1       0x00002000U
#define SWCFG_LP_MODE_HW_SMPS_HF_V1P2       0x00003000U

#define SWCFG_LP_MODE_HW_SMPS_LF_MASK       0x0000C000U
#define SWCFG_LP_MODE_HW_SMPS_LF_OFF        14
#define SWCFG_LP_MODE_HW_SMPS_LF_VOFF       0x00000000U
#define SWCFG_LP_MODE_HW_SMPS_LF_V1P0       0x00004000U
#define SWCFG_LP_MODE_HW_SMPS_LF_V1P1       0x00008000U
#define SWCFG_LP_MODE_HW_SMPS_LF_V1P2       0x0000C000U

/**
 * @brief Low Power max number of configurable pairs
 */
#define SWCFG_LP_MAX_PAIRS                  8

/**
 * @brief Odometer configurations
 */
#define SWCFG_ODO_EN_MASK                   0x00000001U
#define SWCFG_ODO_EN_OFF                    0
#define SWCFG_ODO_ENMSG_MASK                0x0000FFFEU
#define SWCFG_ODO_ENMSG_OFF                 1
#define SWCFG_ODO_ALARM_MASK                0xFFFF0000U
#define SWCFG_ODO_ALARM_OFF                 16

/**
 * @brief Logger configurations
 */
#define SWCFG_LOGGER_EN_MASK                0x00000001U
#define SWCFG_LOGGER_EN_OFF                 0 
#define SWCFG_LOGGER_CIRCULAR_MASK          0x00000002U
#define SWCFG_LOGGER_CIRCULAR_OFF           1 
#define SWCFG_LOGGER_RECTYPE_MASK           0x0000001CU
#define SWCFG_LOGGER_RECTYPE_OFF            2
#define SWCFG_LOGGER_ONESHOT_MASK           0x00000020U
#define SWCFG_LOGGER_ONESHOT_OFF            5
#define SWCFG_LOGGER_MINRATE_MASK           0x0000FF00U
#define SWCFG_LOGGER_MINRATE_OFF            8
#define SWCFG_LOGGER_MINSPEED_MASK          0x00FF0000U
#define SWCFG_LOGGER_MINSPEED_OFF           16
#define SWCFG_LOGGER_MINDIST_MASK           0x0000FFFFU
#define SWCFG_LOGGER_MINDIST_OFF            0

/**
 * @brief Geo fencing configurations
 */
#define SWCFG_GEOFENCE_EN_MASK              0x00000001U
#define SWCFG_GEOFENCE_EN_OFF               0
#define SWCFG_GEOFENCE_TOL_MASK             0x00000006U
#define SWCFG_GEOFENCE_TOL_OFF              1
#define SWCFG_GEOFENCE_EN0_MASK             0x00000F00U
#define SWCFG_GEOFENCE_EN0_OFF              8
#define SWCFG_GEOFENCE_EN1_MASK             0x00000200U
#define SWCFG_GEOFENCE_EN1_OFF              9
#define SWCFG_GEOFENCE_EN2_MASK             0x00000400U
#define SWCFG_GEOFENCE_EN2_OFF              10
#define SWCFG_GEOFENCE_EN3_MASK             0x00000800U
#define SWCFG_GEOFENCE_EN3_OFF              11

/**
 * @brief Geo fencing max number of circles
 */
#define SWCFG_GEOFENCE_MAX_CIRCLES          4

/*SW config section 1*/
#define DEBUG_PORT_NUMBER_ID                  100
#define NMEA_PORT_NUMBER_ID                   101
#define NMEA_PORT_BAUDRATE_ID                 102
#define GPS_DEBUG_MODE_ID                     103
#define GPS_MASK_ANGLE_ID                     104
#define GPS_TRACKING_TH_ID                    105
#define DEBUG_PORT_BAUDRATE_ID                106
#define GPS_NAVIGATE_PPS_TASK_PRIORITY_ID     107
#define GPS_DSP_TRK_TASK_PRIORITY_ID          108
#define GPS_TRACKER_TASK_PRIORITY_ID          109
#define GPS_DSP_ACQ_TASK_PRIORITY_ID          110
#define GPS_GPS_FLASH_ERASE_PRIORITY_ID       111
#define WAAS_TASK_PRIORITY_ID                 112
#define WAAS_BACK_END_TASK_PRIORITY_ID        113
#define ST_AGPS_EPHMGR_TASK_PRIORITY_ID       114
#define NMEA_MSG_TASK_PRIORITY_ID             115
#define GPS_NAVIGATE_TASK_PRIORITY_ID         116
#define ST_AGPS_TASK_PRIORITY_ID              117
#define BACKUP_TASK_PRIORITY_ID               118
#define C2C_IST_TASK_PRIORITY_ID              119
#define COLD_START_TYPE_ID                    120
#define NMEA_SPEED_DIGIT_ID                   121
#define GPS_RTC_WRITE_TASK_PRIORITY_ID        122
#define STREAM_TASK_PRIORITY_ID               123
#define OUTPUT_CFG_ID                         124
#define NOTCH_FILTER_CFG_ID                   125
#define HARDWARE_CONFIGURATION_ID             126
#define NMEA_POSITION_DIGIT                   127
#define DIFFERENTIAL_SOURCE                   128
#define GLONASS_OUTPUT_FORMAT_ID              129
#define CPU_CLOCK_SPEED                       130
#define NMEA_TALKER_ID                        131
#define GNSS_POSITIONING_THRESHOLD_ID         132
#define CONFIG_STATUS_ID                      133
#define CONFIG_VER_ID                         134
#define SBAS_PRN_ID                           135
#define T_SHORT_ID                            136
#define T_LONG_ID                             137
#define RTCM_PORT_NUMBER_ID                   138
#define RTCM_PORT_BAUDRATE_ID                 139
#define FE_A0_ID                              140
#define FE_D0_ID                              141
#define FE_A1_ID                              142
#define FE_D1_ID                              143
#define FE_A2_ID                              144
#define FE_D2_ID                              145
#define FE_A3_ID                              146
#define FE_D3_ID                              147
#define FE_A4_ID                              148
#define FE_D4_ID                              149
#define FE_A5_ID                              150
#define FE_D5_ID                              151
#define FE_A6_ID                              152
#define FE_D6_ID                              153
#define FE_A7_ID                              154
#define FE_D7_ID                              155
#define FE_A8_ID                              156
#define FE_D8_ID                              157
#define FE_A9_ID                              158
#define FE_D9_ID                              159
#define FE_A10_ID                             160
#define FE_D10_ID                             161
#define FE_A11_ID                             162
#define FE_D11_ID                             163
#define FE_A12_ID                             164
#define FE_D12_ID                             165
#define FE_A13_ID                             166
#define FE_D13_ID                             167
#define FE_A14_ID                             168
#define FE_D14_ID                             169
#define FE_A15_ID                             170
#define FE_D15_ID                             171
#define FE_A16_ID                             172
#define FE_D16_ID                             173
#define FE_A17_ID                             174
#define FE_D17_ID                             175
#define FE_A18_ID                             176
#define FE_D18_ID                             177
#define FE_A19_ID                             178
#define FE_D19_ID                             179
#define FE_A20_ID                             180
#define FE_D20_ID                             181
#define FE_A21_ID                             182
#define FE_D21_ID                             183
#define FE_A22_ID                             184
#define FE_D22_ID                             185
#define FE_A23_ID                             186
#define FE_D23_ID                             187
#define FE_A24_ID                             188
#define FE_D24_ID                             189
#define DEFAULT_MSGLIST_SCALING_ID            190
#define DEFAULT_MSGLIST_SCALING1_ID           191
#define DEFAULT_MSGLIST_SCALING2_ID           192
#define USB_DET_CONFIGURATION_ID              193
#define USB_DET_PIN_ID                        194
#define USB_DTE_CONFIGURATION_ID              195
#define NMEA_MSG_TASK_PRIORITY_2_ID           196
#define PPS_CLOCK_SETTING_ID                  197
#define GPS_MASK_ANGLE_POSITIONING_ID         198
#define DATUM_ID                              199


/*SW config section 2*/
#define APP_ON_OFF_ID                         200
#define NMEA_PORT_MSGLIST_L_ID                201
#define NCO_RANGE_MAX_ID                      202
#define NCO_RANGE_MIN_ID                      203
#define NCO_CENTER_ID                         204
#define DELAY_TO_NEXT_FIX_ID                  205
#define GPIO_PORT0_CFG0_ID                    206
#define GPIO_PORT0_CFG1_ID                    207
#define GPIO_PORT1_CFG0_ID                    208
#define GPIO_PORT1_CFG1_ID                    209
#define NMEA_PORT_MSGLIST1_L_ID               210
#define NMEA_PORT_MSGLIST2_L_ID               211
#define SBAS_SATELLITES_ENABLE_MASK_ID        212
#define PPS_OPERATING_MODE_SETTING_1_ID       213
#define PPS_OPERATING_MODE_SETTING_2_ID       214
#define PPS_AUTO_SURVEY_SAMPLES_ID            215
#define SBAS_AUTO_SEARCH_TIMEOUT_1_ID         216
#define SBAS_AUTO_SEARCH_TIMEOUT_2_ID         217
#define SBAS_SATELLITE_PARAM_1_ID             218
#define SBAS_SATELLITE_PARAM_2_ID             219
#define LOW_POWER_CFG_PARAMS_1_ID             220
#define LOW_POWER_CFG_PARAMS_2_ID             221
#define LMS_ALGO_CFG_PARAMS_1_ID              222
#define LMS_ALGO_CFG_PARAMS_2_ID              223
#define LOW_POWER_CFG_PARAMS_3_ID             224
#define ADC_CHAN_READ_CFG_PARAMS_ID           225
#define ADC_ANTENNA_SENSING_CFG_PARAMS_ID     226
#define APP_ON_OFF_2_ID                       227
#define NMEA_PORT_MSGLIST_H_ID                228
#define NMEA_PORT_MSGLIST_1_H_ID              229
#define NMEA_PORT_MSGLIST_2_H_ID              230
#define NMEA_ON_DEBUG_PORT_MSGLIST_L_ID       231
#define NMEA_ON_DEBUG_PORT_MSGLIST_H_ID       232
#define NMEA_ON_DEBUG_PORT_MSGLIST_1_L_ID     233
#define NMEA_ON_DEBUG_PORT_MSGLIST_1_H_ID     234
#define NMEA_ON_DEBUG_PORT_MSGLIST_2_L_ID     235
#define NMEA_ON_DEBUG_PORT_MSGLIST_2_H_ID     236
#define GPS_MIN_MAX_WEEK_NUMBER_ID            237
#define GPS_UTC_DEFAULT_SETTING_ID            238
#define SMART_XTAL_SETTING_1_ID               239
#define STBIN_MSGLIST_L_ID                    240
#define STBIN_MSGLIST_H_ID                    241
#define ANTENNA_SENSING_CFG_GPIO_PIN_ID       242
#define ANTENNA_SENSING_CFG_GPIO_MODE_ID      243
#define ANTENNA_SENSING_CFG_ACTIVE_LEVELS_ID  244
#define TCXO_CONFIG_SELECTOR_ID               245
#define NMEA_EXT_OPTIONS_ID                   246
#define DSP_CONFIG_OPTIONS_ID                 248
#define SPM_ID                                249
#define SPM_CONFIGURATION_ID                  250
#define SMART_XTAL_SETTING_2_ID               251
#define ANTENNA_SENSING_CFG_ADC_IN_ID         252
#define GPIO_PORT0_MODE_AFSLA_ID              253
#define GPIO_PORT0_MODE_AFSLB_ID              254
#define GPIO_PORT1_MODE_AFSLA_ID              255
#define GPIO_PORT1_MODE_AFSLB_ID              256
#define LOW_POWER_CFG_PARAMS_4_ID             257
#define LOW_POWER_CFG_PARAMS_5_ID             258
#define LOW_POWER_CFG_PARAMS_6_ID             259
#define WLS_CFG_PARAMS_1_ID                   260
#define DYNAMIC_MODE_CFG_PARAMS_ID            261
#define SHUTDN_CTRL_CFG_ID                    262
#define NMEA_OVER_SERIAL_ID                   263
#define LOGGER_CFG0_ID                        264
#define LOGGER_CFG1_ID                        265
#define LOGGER_CFG2_ID                        266
#define LOGGER_CFG3_ID                        267
#define GEOFENCING_CFG0_ID                    268
#define GEOFENCING_CFG1_ID                    269
#define ODOMETER_CFG0_ID                      270
#define SPARE_271                             271

/*SW config section 3*/
#define NMEA_PORT_SLEEP_TIME_ID               300
#define PPS_PULSE_DURATION_ID                 301
#define RF_TIME_CORRECTION_ID                 302
#define GPS_FIX_RATE_ID                       303
#define POSITION_HOLD_LAT_ID                  304
#define POSITION_HOLD_LON_ID                  305
#define POSITION_HOLD_HEIGHT_ID               306
#define GPS_RF_TIME_CORRECTION_ID             307
#define GLONASS_RF_TIME_CORRECTION_ID         308
#define TIMING_TRAIM_ALARM_ID                 309
#define COMPASS_RF_TIME_CORRECTION_ID         310
#define GALILEO_RF_TIME_CORRECTION_ID         311
#define RESERVED_312                          312
#define RESERVED_313                          313
#define GEOFENCING_P0_LAT_ID                  314
#define GEOFENCING_P0_LON_ID                  315
#define GEOFENCING_P0_RAD_ID                  316
#define GEOFENCING_P1_LAT_ID                  317
#define GEOFENCING_P1_LON_ID                  318
#define GEOFENCING_P1_RAD_ID                  319
#define GEOFENCING_P2_LAT_ID                  320
#define GEOFENCING_P2_LON_ID                  321
#define GEOFENCING_P2_RAD_ID                  322
#define GEOFENCING_P3_LAT_ID                  323
#define GEOFENCING_P3_LON_ID                  324
#define GEOFENCING_P3_RAD_ID                  325


/*SW config section 4*/
#define DEFAULT_2D_DOPS_ID                    400
#define DEFAULT_3D_DOPS_ID                    401
#define STARTUP_2D_DOPS_ID                    402
#define STARTUP_3D_DOPS_ID                    403

#define TEXT_MESSAGE_ID                       500

#define DEFAULT_CONFIG                  0
#define SAVED_CONFIG                    1
#define MODIFIED_CONFIG                 2

#define CURRENT_CONFIG_DATA             1
#define DEFAULT_CONFIG_DATA             2
#define SAVED_CONFIG_DATA               3

#define DEFAULT_NOT_USED_FE_REGISTER    0xFF
#define DEFAULT_RF_REG_ADD              (0x80 | 0x06)
#define DEFAULT_RF_REG_VAL              0x3F

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct sw_config_dops_tag
{
  tU8   pdop;
  tU8   vdop;
  tU8   hdop;
  tU8   gdop;
}sw_config_dops_t;

typedef struct sw_config_tag
{
  tU8   debug_port_number;                      /*100*/
  tU8   nmea_port_number;                       /*101*/
  tU8   nmea_port_baudrate;                     /*102*/
  tU8   gnss_debug_mode;                        /*103*/
  tU8   gnss_mask_angle;                        /*104*/
  tU8   gnss_tracking_th;                       /*105*/
  tU8   debug_port_baudrate;                    /*106*/
  tU8   gnss_navigate_pps_task_priority;        /*107*/
  tU8   gnss_dsp_trk_task_priority;             /*108*/
  tU8   gnss_tracker_task_priority;             /*109*/
  tU8   gnss_dsp_acq_task_priority;             /*110*/
  tU8   gnss_flash_erase_priority;              /*111*/
  tU8   waas_task_priority;                     /*112*/
  tU8   waas_back_end_task_priority;            /*113*/
  tU8   st_agps_ephmgr_task_priority;           /*114*/
  tU8   nmea_cmdif_task_priority;               /*115*/
  tU8   gnss_navigate_task_priority;            /*116*/
  tU8   st_agps_task_priority;                  /*117*/
  tU8   backup_task_priority;                   /*118*/
  tU8   c2c_ist_task_priority;                  /*119*/
  tU8   cold_start_type;                        /*120*/
  tU8   nmea_speed_digit;                       /*121*/
  tU8   gnss_rtc_write_task_priority;           /*122*/
  tU8   stream_task_priority;                   /*123*/
  tU8   output_cfg;                             /*124*/
  tU8   notch_filter_cfg;                       /*125*/
  tU8   hardware_configuration;                 /*126*/
  tU8   nmea_position_digit;                    /*127*/
  tU8   differential_source;                    /*128*/
  tU8   glonass_output_format;                  /*129*/
  tU8   cpu_clock_speed;                        /*130*/
  tU8   nmea_talker_id;                         /*131*/
  tU8   gnss_positioning_th;                    /*132*/
  tU8   config_status;                          /*133*/
  tU8   config_ver;                             /*134*/
  tU8   sbas_prn;                               /*135*/
  tU8   T_SHORT_val;                            /*136*/
  tU8   T_LONG_val;                             /*137*/
  tU8   rtcm_port_number;                       /*138*/
  tU8   rtcm_port_baudrate;                     /*139*/
  tU8   fe_A0;                                  /*140*/
  tU8   fe_D0;                                  /*141*/
  tU8   fe_A1;                                  /*142*/
  tU8   fe_D1;                                  /*143*/
  tU8   fe_A2;                                  /*144*/
  tU8   fe_D2;                                  /*145*/
  tU8   fe_A3;                                  /*146*/
  tU8   fe_D3;                                  /*147*/
  tU8   fe_A4;                                  /*148*/
  tU8   fe_D4;                                  /*149*/
  tU8   fe_A5;                                  /*150*/
  tU8   fe_D5;                                  /*151*/
  tU8   fe_A6;                                  /*152*/
  tU8   fe_D6;                                  /*153*/
  tU8   fe_A7;                                  /*154*/
  tU8   fe_D7;                                  /*155*/
  tU8   fe_A8;                                  /*156*/
  tU8   fe_D8;                                  /*157*/
  tU8   fe_A9;                                  /*158*/
  tU8   fe_D9;                                  /*159*/
  tU8   fe_A10;                                 /*160*/
  tU8   fe_D10;                                 /*161*/
  tU8   fe_A11;                                 /*162*/
  tU8   fe_D11;                                 /*163*/
  tU8   fe_A12;                                 /*164*/
  tU8   fe_D12;                                 /*165*/
  tU8   fe_A13;                                 /*166*/
  tU8   fe_D13;                                 /*167*/
  tU8   fe_A14;                                 /*168*/
  tU8   fe_D14;                                 /*169*/
  tU8   fe_A15;                                 /*170*/
  tU8   fe_D15;                                 /*171*/
  tU8   fe_A16;                                 /*172*/
  tU8   fe_D16;                                 /*173*/
  tU8   fe_A17;                                 /*174*/
  tU8   fe_D17;                                 /*175*/
  tU8   fe_A18;                                 /*176*/
  tU8   fe_D18;                                 /*177*/
  tU8   fe_A19;                                 /*178*/
  tU8   fe_D19;                                 /*179*/
  tU8   fe_A20;                                 /*180*/
  tU8   fe_D20;                                 /*181*/
  tU8   fe_A21;                                 /*182*/
  tU8   fe_D21;                                 /*183*/
  tU8   fe_A22;                                 /*184*/
  tU8   fe_D22;                                 /*185*/
  tU8   fe_A23;                                 /*186*/
  tU8   fe_D23;                                 /*187*/
  tU8   fe_A24;                                 /*188*/
  tU8   fe_D24;                                 /*189*/
  tU8   msglist_scaling;                        /*190*/
  tU8   msglist_scaling_1;                      /*191*/
  tU8   msglist_scaling_2;                      /*192*/
  tU8   usb_det_configuration;                  /*193*/
  tU8   usb_det_pin;                            /*194*/
  tU8   usb_dte_configuration;                  /*195*/
  tU8   nmea_outmsg2_task_priority;             /*196*/
  tU8   pps_clock_setting;                      /*197*/
  tU8   gnss_mask_angle_positioning;            /*198*/
  tU8   datum_select;                           /*199*/
  tU8   spare_byte4;                            /*1100*/
  tU8   spare_byte5;                            /*1101*/
  tU8   spare_byte6;                            /*1102*/
  tU8   spare_byte7;                            /*1103*/

  tUInt app_on_off;                             /*200*/
  tUInt nmea_port_msglist_l;                    /*201*/
  tInt  nco_range_max;                          /*202*/
  tInt  nco_range_min;                          /*203*/
  tInt  nco_center;                             /*204*/
  tInt  delay_to_next_fix;                      /*205*/
  tUInt gpio_port0_cfg0;                        /*206*/
  tUInt gpio_port0_cfg1;                        /*207*/
  tUInt gpio_port1_cfg0;                        /*208*/
  tUInt gpio_port1_cfg1;                        /*209*/
  tUInt nmea_port_msglist_1_l;                  /*210*/
  tUInt nmea_port_msglist_2_l;                  /*211*/
  tUInt sbas_satellites_enable_mask;            /*212*/
  tUInt pps_operating_mode_setting_1;           /*213*/
  tUInt pps_operating_mode_setting_2;           /*214*/
  tUInt pps_autosurvey_samples;                 /*215*/
  tUInt sbas_autosearch_timeout_1;              /*216*/
  tUInt sbas_autosearch_timeout_2;              /*217*/
  tUInt sbas_satellite_parameter_1;             /*218*/
  tUInt sbas_satellite_parameter_2;             /*219*/
  tUInt low_power_cfg_params_1;                 /*220*/
  tUInt low_power_cfg_params_2;                 /*221*/
  tUInt lms_algo_cfg_params_1;                  /*222*/
  tUInt lms_algo_cfg_params_2;                  /*223*/
  tUInt low_power_cfg_params_3;                 /*224*/
  tUInt adc_chan_read_cfg_params;               /*225*/
  tUInt adc_antenna_sensing_cfg_params;         /*226*/
  tUInt app_on_off_2;                           /*227*/
  tUInt nmea_port_msglist_h;                    /*228*/
  tUInt nmea_port_msglist_1_h;                  /*229*/
  tUInt nmea_port_msglist_2_h;                  /*230*/
  tUInt nmea_on_debug_port_msglist_l;           /*231*/
  tUInt nmea_on_debug_port_msglist_h;           /*232*/
  tUInt nmea_on_debug_port_msglist_1_l;         /*233*/
  tUInt nmea_on_debug_port_msglist_1_h;         /*234*/
  tUInt nmea_on_debug_port_msglist_2_l;         /*235*/
  tUInt nmea_on_debug_port_msglist_2_h;         /*236*/
  tUInt gps_min_max_week_number;                /*237*/
  tUInt gps_utc_default_setting;                /*238*/
  tUInt smart_xtal_setting_1;                   /*239*/
  tUInt stbin_msglist_l;                        /*240*/
  tUInt stbin_msglist_h;                        /*241*/
  tUInt antenna_sensing_cfg_gpio_pin;           /*242*/
  tUInt antenna_sensing_cfg_gpio_mode;          /*243*/
  tUInt antenna_sensing_cfg_active_levels;      /*244*/
  tUInt tcxo_config_selector;                   /*245*/
  tUInt nmea_ext_options;                       /*246*/
  tUInt reserved_247;                           /*247*/
  tUInt dsp_config_options;                     /*248*/
  tUInt spm;                                    /*249*/
  tUInt spm_configuration;                      /*250*/
  tUInt smart_xtal_setting_2;                   /*251*/
  tUInt antenna_sensing_cfg_adc_in;             /*252*/
  tUInt gpio_port0_mode_AFSLA;                  /*253*/
  tUInt gpio_port0_mode_AFSLB;                  /*254*/
  tUInt gpio_port1_mode_AFSLA;                  /*255*/
  tUInt gpio_port1_mode_AFSLB;                  /*256*/
  tUInt low_power_cfg_params_4;                 /*257*/
  tUInt low_power_cfg_params_5;                 /*258*/
  tUInt low_power_cfg_params_6;                 /*259*/
  tUInt wls_cfg_params_1;                       /*260*/
  tUInt dynamic_mode_cfg_params;                /*261*/
  tUInt shutdn_ctrl_cfg;                        /*262*/
  tUInt nmea_over_serial_cfg_par;               /*263*/
  tUInt logger_cfg0;                            /*264*/
  tUInt logger_cfg1;                            /*265*/
  tUInt logger_cfg2;                            /*266*/
  tUInt logger_cfg3;                            /*267*/
  tUInt geofencing_cfg0;                        /*268*/
  tUInt geofencing_cfg1;                        /*269*/
  tUInt odometer_cfg0;                          /*270*/
  tUInt spare_word_271;                         /*271*/
  tDouble nmea_port_sleep_time;                 /*300*/
  tDouble pps_pulse_duration;                   /*301*/
  tDouble rf_time_correction;                   /*302*/
  tDouble gps_fix_rate;                         /*303*/
  tDouble position_hold_lat;                    /*304*/
  tDouble position_hold_lon;                    /*305*/
  tDouble position_hold_height;                 /*306*/
  tDouble gps_rf_time_correction;               /*307*/
  tDouble glonass_rf_time_correction;           /*308*/
  tDouble timing_traim_alarm;                   /*309*/
  tDouble compass_rf_time_correction;           /*310*/
  tDouble galileo_rf_time_correction;           /*311*/
  tDouble reserved_312;                         /*312*/
  tDouble reserved_313;                         /*313*/
  tDouble geofencing_p0_lat;                    /*314*/
  tDouble geofencing_p0_lon;                    /*315*/
  tDouble geofencing_p0_rad;                    /*316*/
  tDouble geofencing_p1_lat;                    /*317*/
  tDouble geofencing_p1_lon;                    /*318*/
  tDouble geofencing_p1_rad;                    /*319*/
  tDouble geofencing_p2_lat;                    /*320*/
  tDouble geofencing_p2_lon;                    /*321*/
  tDouble geofencing_p2_rad;                    /*322*/
  tDouble geofencing_p3_lat;                    /*323*/
  tDouble geofencing_p3_lon;                    /*324*/
  tDouble geofencing_p3_rad;                    /*325*/
  sw_config_dops_t  dops_default_2D;            /*400*/
  sw_config_dops_t  dops_default_3D;            /*401*/
  sw_config_dops_t  dops_startup_2D;            /*402*/
  sw_config_dops_t  dops_startup_3D;            /*403*/

  tChar   text_message[SW_CONFIG_TEXT_LENGTH];  /*500*/
#ifdef SW_CONFIG_PRIVATE_BLOCK
  sw_config_private_block_t private_config_block;
#endif
}sw_config_t;


typedef struct sw_config_key_tag
{
  tUInt   code[4];
} sw_config_key_t;

typedef struct sw_config_package_tag
{
  tU8               items[8];
  sw_config_key_t   key;
  sw_config_t       config;
  tUInt sw_config_checksum;
} sw_config_package_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
/**
 * @brief Configuration group ID.
 */
typedef enum
{
  SW_CONFIG_GPR_ID_PORT_UART = 0,
  SW_CONFIG_GPR_ID_PORT_USB =  1,
  SW_CONFIG_GPR_ID_PORT_SPI =  2,
  SW_CONFIG_GPR_ID_PORT_I2C =  3,
  SW_CONFIG_GPR_ID_AS_OFF =    4,
  SW_CONFIG_GPR_ID_AS_RF =     5,
  SW_CONFIG_GPR_ID_AS_ADC =    6,
  SW_CONFIG_GPR_ID_AS_GPIO =   7,
  SW_CONFIG_GPR_ID_CLOCK =     8,
  SW_CONFIG_GPR_ID_MESS_LIST = 9,
  SW_CONFIG_GPR_ID_GNSS_ALG =  10,
  SW_CONFIG_GPR_ID_SBAS =      11,
  SW_CONFIG_GPR_ID_PPSGEN =    12,
  SW_CONFIG_GPR_ID_PPSPUL =    13,
  SW_CONFIG_GPR_ID_PPSSAT =    14,
  SW_CONFIG_GPR_ID_POSHOLD =   15,
  SW_CONFIG_GPR_ID_TRAIM =     16,
  SW_CONFIG_GPR_ID_SATCOMP =   17,
  SW_CONFIG_GPR_ID_LPA =       18,
  SW_CONFIG_GPR_ID_LPS =       19,
  SW_CONFIG_GPR_ID_AGPS =      20,
  SW_CONFIG_GPR_ID_RAW =       21,
  SW_CONFIG_GPR_ID_ANTIJAM =           22,
  SW_CONFIG_GPR_ID_ODO =               23,
  SW_CONFIG_GPR_ID_LOG =               24,
  SW_CONFIG_GPR_ID_GEOFENCE =          25,
  SW_CONFIG_GPR_ID_GEOFENCECIRCLES =   26,  
} sw_config_grp_id_t;

/**
 * @brief Port Configuration, protocol type.
 */
typedef enum
{
  SW_CONFIG_PROTOCOL_NMEA =  0,
  SW_CONFIG_PROTOCOL_STBIN = 1,
  SW_CONFIG_PROTOCOL_DEBUG = 2,
  SW_CONFIG_PROTOCOL_RCTM =  3
} sw_config_protocol_t;

/**
 * @brief Port Configuration, port type.
 */
typedef enum
{
  SW_CONFIG_PORT_UART =  0,
  SW_CONFIG_PORT_I2C = 1,
  SW_CONFIG_PORT_SPI = 2,
  SW_CONFIG_PORT_USB =  3
} sw_config_port_t;

/**
 * @brief Configuration for protocol over UART.
 */
typedef struct
{
  /**
   * @brief Port protocol type.
   */
  sw_config_protocol_t prot;
  /**
   * @brief UART baudrate.
   */
  tU8 port_baudrate;
  /**
   * @brief UART port number.
   */
  tU8 port_id;
} sw_config_uart_t;

/**
 * @brief Configuration for protocol over USB.
 */
typedef struct
{
  /**
   * @brief Port protocol type.
   */
  sw_config_protocol_t prot;
  /**
   * @brief DTE feature
   */
  tU8 dte_switch;
  /**
   * @brief Detection feature
   */
  tU8 det_switch;
  /**
   * @brief Detection port number.
   */
  tU8 det_port_id;
  /**
   * @brief Detection port configuration.
   */
  tU8 det_port_cfg;
} sw_config_usb_t;

/**
 * @brief I2C modes.
 */
typedef enum
{
  SW_CONFIG_I2C_MODE_STD =  0,
  SW_CONFIG_I2C_MODE_FAST = 1,
  SW_CONFIG_I2C_MODE_HS = 2
} sw_config_i2c_mode_t;

/**
 * @brief Configuration for protocol over I2C.
 */
typedef struct
{
  /**
   * @brief Port protocol type.
   */
  sw_config_protocol_t prot;
  /**
   * @brief I2C mode
   */
  sw_config_i2c_mode_t mode;
  /**
   * @brief I2C slave address.
   */
  tU16 slave;
} sw_config_i2c_t;

/**
 * @brief Configuration when antenna sensing is off.
 */
typedef struct
{
  /**
   * @brief Antenna sensing periodic messages.
   */
  tU8 periodicmsg;
  /**
   * @brief Antenna sensing switching capability.
   */
  tU8 switchcap;
  /**
   * @brief Antenna sensing switching port number.
   */
  tU8 switch_port_id;
  /**
   * @brief Antenna sensing switching port configuration.
   */
  tU8 switch_port_cfg;
} sw_config_antsens_off_t;

/**
 * @brief Configuration for RF antenna sensing.
 */
typedef sw_config_antsens_off_t sw_config_antsens_rf_t;

/**
 * @brief Configuration for ADC antenna sensing.
 */
typedef struct
{
  /**
   * @brief Antenna sensing periodic messages.
   */
  tU8 periodicmsg;
  /**
   * @brief Antenna sensing switching capability.
   */
  tU8 switchcap;
  /**
   * @brief Antenna sensing switching port number.
   */
  tU8 switch_port_id;
  /**
   * @brief Antenna sensing switching port configuration.
   */
  tU8 switch_port_cfg;
  /**
   * @brief ADC channel input mask.
   */
  tUInt chid;
  /**
   * @brief ADC clock divider.
   */
  tUInt clkdiv;
  /**
   * @brief ADC min threshold.
   */
  tUInt minthr;
  /**
   * @brief ADC max threshold.
   */
  tUInt maxthr;
} sw_config_antsens_adc_t;

/**
 * @brief Configuration for GPIO antenna sensing.
 */
typedef struct
{
  /**
   * @brief Antenna sensing periodic messages.
   */
  tU8 periodicmsg;
  /**
   * @brief Antenna sensing switching capability.
   */
  tU8 switchcap;
  /**
   * @brief Antenna sensing switching port number.
   */
  tU8 switch_port_id;
  /**
   * @brief Antenna sensing switching port configuration.
   */
  tU8 switch_port_cfg;
  /**
   * @brief Antenna sensing digon port number.
   */
  tU8 digon_port_id;
  /**
   * @brief Antenna sensing digon on port configuration.
   */
  tU8 digon_port_cfg;
  /**
   * @brief Antenna sensing digshort port number.
   */
  tU8 digshort_port_id;
  /**
   * @brief Antenna sensing digshort port configuration.
   */
  tU8 digshort_port_cfg;
  /**
   * @brief Antenna sensing digopen port number.
   */
  tU8 digopen_port_id;
  /**
   * @brief Antenna sensing digopen port configuration.
   */
  tU8 digopen_port_cfg;
} sw_config_antsens_gpio_t;

/**
 * @brief Clock configuration, clock identifier.
 */
typedef enum
{
  SW_CONFIG_CLK_CPU = 0
} sw_config_clk_id_t;

/**
 * @brief Clock speed and source configuration.
 */
typedef struct
{
  /**
   * @brief Clock identifier.
   */
  sw_config_clk_id_t clk_id;
  /**
   * @brief Clock source.
   */
  tU8 clk_src;
  /**
   * @brief Clock divider.
   */
  tU8 clk_div;
} sw_config_clk_cfg_t;

/**
 * @brief Message list configuration, list identifier.
 */
typedef enum
{
  SW_CONFIG_NMEA_LIST_0 = 0,
  SW_CONFIG_NMEA_LIST_1 = 1,
  SW_CONFIG_NMEA_LIST_2 = 2,
  SW_CONFIG_DBG_LIST_0 = 3,
  SW_CONFIG_DBG_LIST_1 = 4,
  SW_CONFIG_DBG_LIST_2 = 5,
  SW_CONFIG_STBIN = 6
} sw_config_list_id_t;

/**
 * @brief Clock speed and source configuration.
 */
typedef struct
{
  /**
   * @brief Message list identifier.
   */
  sw_config_list_id_t list_id;
  /**
   * @brief Message list rate.
   */
  tU8 list_rate;
  /**
   * @brief Message list low value.
   */
  tUInt list_low;
  /**
   * @brief Message list low value.
   */
  tUInt list_high;
} sw_config_msg_list_t;

/**
 * @brief GNSS algorithm configuration.
 */
typedef struct
{
  /**
   * @brief Minimum CN0 [dB] at which satellite can be tracked.
   */
  tU8 trkcn0;
  /**
   * @brief Minimum CN0 [dB] at which satellite can be tracked
   *        for positioning solution.
   */
  tU8 poscn0;
  /**
   * @brief Minimum elevation angle at which satellite can be
   *        tracked.
   */
  tU8 trkmskang;
  /**
   * @brief Minimum elevation angle at which satellite can be
   *        tracked for positioning solution.
   */
  tU8 posmskang;
  /**
   * @brief NCO center value.
   */
  tU8 NCOcntr;
  /**
   * @brief NCO range minimum value.
   */
  tU8 NCOmin;
  /**
   * @brief NCO range maximum value.
   */
  tU8 NCOmax;
} sw_config_gnss_cfg_t;

/**
 * @brief SBAS satellite configuration.
 */
typedef struct
{
  /**
   * @brief SBASPNR.
   */
  tU8 prnid;
  /**
   * @brief Satellite longitude in degree.
   */
  tU8 longitude;
  /**
   * @brief Satellite longitude sense.
   */
  tU8 longsens;
  /**
   * @brief SBAS service.
   */
  tU8 sbasserv;
  /**
   * @brief Is this satellite the default one.
   */
  boolean_t isdefault;
} sw_config_sbas_sat_t;

/**
 * @brief SBAS algorithm configuration.
 */
typedef struct
{
  /**
   * @brief Enable SBAS engine.
   */
  boolean_t en_engine;
  /**
   * @brief Enable satellite report in GSV message.
   */
  boolean_t en_report;
  /**
   * @brief Enable auto-search switch.
   */
  boolean_t en_autosearch;
  /**
   * @brief Auto-search satellites mask.
   */
  tUInt autosearchmask;
  /**
   * @brief Decoding timeout.
   */
  tU8 dectimeout;
  /**
   * @brief Differential timeout.
   */
  tU8 difftimeout;
  /**
   * @brief Next satellite timeout.
   */
  tU8 nextsattimeout;
  /**
   * @brief Next session timeout.
   */
  tU8 nextsesstimeout;
  /**
   * @brief Number of satellites.
   */
  tU8 numofsats;
  /**
   * @brief Array of satellite configurations.
   */
  sw_config_sbas_sat_t satcfg[SBAS_MAX_NUM_OF_SAT];
} sw_config_sbas_alg_t;

/**
 * @brief PPS Clock Identification.
 */
typedef enum
{
  SW_CONFIG_PPS_CLK_ID_16MHZ  = 0,
  SW_CONFIG_PPS_CLK_ID_32MHZ  = 1,
  SW_CONFIG_PPS_CLK_ID_64MHZ = 2
} sw_config_pps_clk_id_t;

/**
 * @brief PPS general configuration.
 */
typedef struct
{
  /**
   * @brief Enable PPS engine.
   */
  boolean_t enpps;
  /**
   * @brief Generation mode.
   */
  tUInt genmode;
  /**
   * @brief Clock.
   */
  sw_config_pps_clk_id_t ppsclock;
  /**
   * @brief Reference time.
   */
  tUInt reftime;
} sw_config_pps_gen_t;

/**
 * @brief PPS pulse related configuration.
 */
typedef struct
{
  /**
   * @brief Enable polarity switch.
   */
  boolean_t enpolinv;
  /**
   * @brief Pulse duration.
   */
  tDouble pulsedur;
  /**
   * @brief Delay correction.
   */
  tDouble delcorr;
} sw_config_pps_pul_t;

/**
 * @brief PPS satellite related configuration.
 */
typedef struct
{
  /**
   * @brief Mixing type.
   */
  tU8 enmix;
  /**
   * @brief Fix condition.
   */
  tU8 fixcond;
  /**
   * @brief Minimum number of satellite used for timing correction.
   */
  tU8 minsatnum;
  /**
   * @brief Satellite elevation mask for time correction.
   */
  tU8 satelevmask;
} sw_config_pps_sat_t;

/**
 * @brief Position Hold configuration.
 */
typedef struct
{
  /**
   * @brief Enable Position Hold.
   */
  boolean_t enposhold;
  /**
   * @brief Position Hold latitude.
   */
  tDouble pos_hold_lat;
  /**
   * @brief Position Hold longitude.
   */
  tDouble pos_hold_lon;
  /**
   * @brief Position Hold height.
   */
  tDouble pos_hold_hei;
} sw_config_pos_hold_t;

/**
 * @brief Traim related configuration.
 */
typedef struct
{
  /**
   * @brief Enable traim.
   */
  boolean_t entraim;
  /**
   * @brief Time error threshold.
   */
  tDouble threshold;
} sw_config_traim_t;

/**
 * @brief Satellite compensation related configuration.
 */
typedef struct
{
  /**
   * @brief RF path id.
   */
  tU8 pathid;
  /**
   * @brief Time compensation value.
   */
  tDouble comp;
} sw_config_sat_comp_values_t;

/**
 * @brief Satellite compensation related configuration.
 */
typedef struct
{
  /**
   * @brief Enable SBAS engine.
   */
  tU8 numofcomp;
  /**
   * @brief Compensations
   */
  sw_config_sat_comp_values_t satcomp[SAT_COMP_MAX_NUM_OF_COMP];
} sw_config_sat_comp_t;

/**
 * @brief Low power algorithm configuration.
 */
typedef struct
{
  /**
   * @brief State of the Low Power algorithm.
   */
  boolean_t en_lpa;
  /**
   * @brief Low Power algorithm feature.
   */
  tUInt feat;
  /**
   * @brief Time in s between two starts of fix activity.
   */
  tUInt fix_period;
  /**
   * @brief Number of fix reported each FIX Period.
   */
  tUInt fix_on_time;
  /**
   * @brief Number of no-fixes in hot conditions, before to signal
   *        a fix loss event.
   */
  tUInt no_fix_cnt;
  /**
   * @brief Number of no-fixes in non-hot conditions, before to signal
   *        a fix loss event.
   */
  tUInt no_fix_cnt2;
  /**
   * @brief Off duration time after a fix loss event.
   */
  tUInt no_fix_off;
  /**
   * @brief Adaptive multi-constellation algorithm.
   */
  boolean_t adapt_feat;
  /**
   * @brief Trimming of correlation time for each cycle.
   */
  boolean_t adapt_duty_cycle;
  /**
   * @brief EPHE threshold.
   */
  tUInt ehpe_th;
  /**
   * @brief Number of satellite used in Adaptive mode.
   */
  tU8 num_of_sat;
  /**
   * @brief OFF period in when Adaptive duty is enabled.
   */
  tUInt duty_off;
  /**
   * @brief Constellation mask, currently unused.
   */
  tUInt const_type;
} sw_config_lpa_t;

/**
 * @brief Power Domain Identification.
 */
typedef enum
{
  SW_CONFIG_PD_SMPS  = 0,
  SW_CONFIG_PD_LDO1  = 1,
  SW_CONFIG_PD_LDO2  = 2,
  SW_CONFIG_PD_BKLDO = 3
} sw_config_pd_t;

/**
 * @brief Power State Identification.
 */
typedef enum
{
  SW_CONFIG_PS_LF = 0,
  SW_CONFIG_PS_HF = 1
} sw_config_ps_t;

/**
 * @brief Low power state - Low power domain single pair configuration.
 */
typedef struct
{
  /**
   * @brief Power domain.
   */
  sw_config_pd_t pd;
  /**
   * @brief Power state.
   */
  sw_config_ps_t ps;
  /**
   * @brief Power voltage value.
   */
  tU8 voltage;
} sw_config_lps_cfg_t;

/**
 * @brief Low power state - Low power domain configuration.
 */
typedef struct
{
  /**
   * @brief Number of low power state to configure.
   */
  tU8 numoflps;
  /**
   * @brief Pairs configuration
   */
  sw_config_lps_cfg_t pairs[SWCFG_LP_MAX_PAIRS];
} sw_config_lps_t;

/**
 * @brief Assisted GPS configuration.
 */
typedef boolean sw_config_agps_t;

/**
 * @brief Anti-jamming, notch mode.
 */
typedef enum
{
  SW_CONFIG_NOTCH_DISABLED =  0,
  SW_CONFIG_NOTCH_NORMAL = 1,
  SW_CONFIG_NOTCH_AUTO = 2
} sw_config_notch_mode_t;

/**
 * @brief SBAS algorithm configuration.
 */
typedef struct
{
  /**
   * @brief Anti-jamming mode for GPS.
   */
  sw_config_notch_mode_t gps;
  /**
   * @brief Anti-jamming mode for GLONASS.
   */
  sw_config_notch_mode_t glonass;
} sw_config_antijamming_t;

/**
 * @brief Anti-jamming, notch mode.
 */
typedef enum
{
  SW_CONFIG_REC_TYPE_1 = 0,
  SW_CONFIG_REC_TYPE_2 = 1,
  SW_CONFIG_REC_TYPE_3 = 2,
  SW_CONFIG_REC_TYPE_4 = 3,
  SW_CONFIG_REC_TYPE_5 = 4,  
  SW_CONFIG_REC_TYPE_6 = 5,
  SW_CONFIG_REC_TYPE_7 = 6  
} sw_config_rec_type_t;

/**
 * @brief ODO configuration.
 */
typedef struct
{
  /**
   * @brief Odometer enabler.
   */
  boolean_t en;
  /**
   * @brief NMEA periodic messages.
   */
  boolean_t enmsg;
  /**
   * @brief Distance alarm.
   */
  tU16 alarm;
} sw_config_odo_t;

/**
 * @brief Logger configuration.
 */
typedef struct
{
  /**
   * @brief Logger enabler.
   */
  boolean_t en;
  /**
   * @brief Circular mode.
   */
  boolean_t circular;
  /**
   * @brief Record type.
   */
  sw_config_rec_type_t rectype;
  /**
   * @brief One shot mode.
   */
  boolean_t oneshot;
  /**
   * @brief Rate threshold.
   */
  tU8 rate;
  /**
   * @brief Speed threshold.
   */
  tU8 speed;
  /**
   * @brief Distanc threshold.
   */
  tU16 dist;
} sw_config_log_t;

/**
 * @brief Geo fencing configuration.
 */
typedef struct
{
  /**
   * @brief Geo fencing enabler.
   */
  boolean_t en;
  /**
   * @brief Tolerance
   */
  tU8 tol;
} sw_config_geofence_t;

/**
 * @brief Geo fencing circle.
 */
typedef struct
{
  /**
   * @brief Circle id
   */
  tU8 id;
  /**
   * @brief Circle enabler.
   */
  boolean_t en;
  /**
   * @brief Center latitude.
   */
  tDouble latitude;
  /**
   * @brief Center longitude.
   */
  tDouble longitude;
  /**
   * @brief Circle radius.
   */
  tDouble radius;
} sw_config_geofence_circle_t;
#ifdef __cplusplus
extern "C" {
#endif

extern void           sw_config_init                              ( void);
extern void           sw_config_reload                            ( void);
extern gnss_error_t   sw_config_get_param                         ( tU8 config_type,tInt param_id,void *value);
extern gnss_error_t   sw_config_set_param                         ( tInt param_id,void *value,tInt mode);
extern gnss_error_t   sw_config_set_group                         (sw_config_grp_id_t grp_id, void *value);
extern tUInt          sw_config_get_software_switch_status        ( tUInt mask);
extern void           sw_config_set_software_switch_status        ( tUInt mask, tInt status);
extern tUInt          sw_config_get_software_switch_status_by_id  ( tInt param_id, tUInt mask);
extern void           sw_config_set_software_switch_status_by_id  ( tInt param_id, tUInt mask, tInt status);
extern gnss_error_t   sw_config_save_param                        ( void);
extern gnss_error_t   sw_config_restore_param                     ( void);
extern void           sw_config_print                             ( void);
extern gnss_error_t   sw_config_get_default                       ( sw_config_t **);
extern gnss_error_t   sw_config_get_current                       ( sw_config_t **);
extern gnss_error_t   sw_config_data_block_copy                   ( tU8 config_type, sw_config_t *dest_sw_config_ptr);
extern gnss_error_t   sw_config_data_block_write                  ( tU16 length,tU16 offset, void *value);
extern tUInt          sw_config_convert_baudrate                  ( const tU8 baud_rate_id);
extern tUInt          sw_config_get_tag_version                   (void);
#ifdef __cplusplus
}
#endif
#endif
