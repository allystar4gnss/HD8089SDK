
#ifndef _GATT_DB_H_
#define _GATT_DB_H_

#include "typedefs.h"

typedef struct
{
    tS16 AXIS_X;
    tS16 AXIS_Y;
    tS16 AXIS_Z;
} AxesRaw_t;

uint8_t Add_Acc_Service(void);
void Read_Request_CB(uint16_t handle);
uint8_t Free_Fall_Notify(void);
uint8_t Acc_Update(AxesRaw_t *data);

uint8_t Add_Environmental_Sensor_Service(void);

#endif /* _GATT_DB_H_ */
