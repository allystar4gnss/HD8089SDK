#include "svc_i2c.h"
#include "in_out_i2c.h"
#include "gnss_debug.h"

/*****************************************************************************
   global variable definitions  (scope: module-exported)
*****************************************************************************/

/*****************************************************************************
   global variable definitions (scope: module-local)
*****************************************************************************/
static svc_i2c_com_handler_t          *in_out_i2c_com_handler;

tU32 in_out_i2c_in( tUInt i2c_id, tU8 *buff, tU32 len, const gpOS_clock_t* timeout) // this function is used to read bytes one by one
{
  tU32 read_bytes = 0U;
  gpOS_clock_t time_out;
  tU32 current_read_byte = 0U;

  while( read_bytes < len)
  {
    time_out = gpOS_time_plus( gpOS_time_now(), 500U *gpOS_timer_ticks_per_msec());
    read_bytes = svc_i2c_read_slave(in_out_i2c_com_handler, &buff[current_read_byte], len, &time_out);
    current_read_byte +=read_bytes;
    len -=read_bytes;
  }

  return read_bytes;
}

tU32 in_out_i2c_out( tUInt i2c_id, tU8 *buff, tU32 len, const gpOS_clock_t* timeout)
{
  tU32 written_bytes = 0U;
  gpOS_clock_t time_out;
  tU32 current_write_byte = 0U;

  while( written_bytes < len)
  {
    time_out = gpOS_time_plus( gpOS_time_now(), 500U *gpOS_timer_ticks_per_msec());
    written_bytes = svc_i2c_write_slave(in_out_i2c_com_handler, &buff[current_write_byte], len, &time_out);
    current_write_byte +=written_bytes;
    len -=written_bytes;
  }

  return written_bytes;
}

/********************************************//**
 * \brief
 *
 * \param
 * \return  void
 *
 ***********************************************/
gpOS_error_t in_out_i2c_init( tUInt addr, LLD_I2C_SpeedModeTy mode, tU32 out_freq)
{
  gpOS_error_t error = gpOS_SUCCESS;

  if( gpOS_FAILURE == svc_i2c_open_port( 0, gpOS_INTERRUPT_NOPRIORITY, addr, LLD_I2C_BUSCTRLMODE_SLAVE))
  {
    error = gpOS_FAILURE;
  }

  if( gpOS_FAILURE == svc_i2c_set_port_mode( 0, LLD_I2C_BUSCTRLMODE_SLAVE))
  {
    error = gpOS_FAILURE;
  }

  if( (in_out_i2c_com_handler == NULL) )
  {
    in_out_i2c_com_handler = svc_i2c_create_com_speed(0, mode, out_freq, 0xff);
  }

  if( in_out_i2c_com_handler == NULL)
  {

    error = gpOS_FAILURE;

  }

  return error;

}
