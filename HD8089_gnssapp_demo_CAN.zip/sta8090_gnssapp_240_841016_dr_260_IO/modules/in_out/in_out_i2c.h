//!
//!   \file       in_out_i2c.h
//!   \brief      <i><b> I2C Interface, header file</b></i>
//!   \author     Maristella Frazzetto
//!   \authors    Many
//!   \version    1.0
//!   \date       2016.10.28
//!   \bug        Unknown
//!   \warning    None
//!   \{
//!
#ifndef _I2C_INTERFACE_H
#define _I2C_INTERFACE_H

#ifdef __cplusplus
extern "C"
{
#endif

#include "gnss_os.h"
#include "gnss_bsp_defs.h"
#include "gnss_defs.h"
#include "lld_gpio.h"
#include "lld_i2c.h"

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
extern gpOS_error_t in_out_i2c_init   ( tUInt, LLD_I2C_SpeedModeTy, tU32);
extern tU32         in_out_i2c_in     ( tUInt , tU8 *, tU32, const gpOS_clock_t*);
extern tU32         in_out_i2c_out    ( tUInt , tU8 *, tU32, const gpOS_clock_t*);

#ifdef __cplusplus
}
#endif

#endif /* _I2C_INTERFACE_H */
