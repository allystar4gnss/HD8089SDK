/*****************************************************************************
   FILE:          dr_plugins.c
   PROJECT:       STA2062 GPS application
   SW PACKAGE:    STA2062 GPS library and application
------------------------------------------------------------------------------
   DESCRIPTION:   The main application to run and test STA2062 GPS library
------------------------------------------------------------------------------
   COPYRIGHT:     (c) 2005 STMicroelectronics, (S2S - SWD) Napoli (ITALY)
------------------------------------------------------------------------------
   Created by : Fulvio boggia
           on : 201
*****************************************************************************/

/*!
 * @file    dr_plugins.c
 * @brief   Plugin for Dead Reckoning
 */

/*****************************************************************************
   includes
*****************************************************************************/

#if defined(DR_CODE_LINKED)

#include "clibs.h"
#include "gpOS.h"
#include "gnssapp.h"
#include "gnssapp_plugins.h"
#include "gnss_events.h"
#include "nmea_support.h"
#include "nmea.h"
#include "gnss_debug.h"
#include "dr_plugin.h"
#include "dr_api.h"
#include "dr_msg.h"
#include "dr_gps.h"
#include "sm_odo.h"
#include "sm_can.h"
#include "sw_config_private.h"
#include "sm_sensors_api.h"
#include "gnss_msg.h"
#include "gnss_msg_queue.h"

#if defined( STBIN_LINKED )
#include "stbin_dr_plugin.h"
#endif

/*****************************************************************************
   external declarations
*****************************************************************************/

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/
#define TALKER_ID    "STM"

/* Sensor Over UART message decoding */
#define DR_SENMSG_ID_OFFSET  1

/*****************************************************************************
   typedefs and structures (scope: module-local)
*****************************************************************************/
typedef enum
{
  DR_NMEA_CMDID_DRSENS,
  DR_NMEA_CMDID_DRMMFB,
  DR_NMEA_CMDID_DRCALCTLT,
  DR_NMEA_CMDID_DRNVMSAVE,
  DR_NMEA_CMDID_NUMBER
} dr_nmea_cmdid_t;

/*****************************************************************************
   global variable definitions  (scope: module-exported)
*****************************************************************************/
extern tInt nmea_cmdif_task_priority;

/*****************************************************************************
   global variable definitions (scope: module-local)
*****************************************************************************/
static dr_plugin_handler_t  *dr_plugin_handler;


static const tChar * const dr_nmea_cmd_strings[] =
{
  "$PHDDRSENMSG",         // DR_NMEA_CMDID_DRSENS,
  "$PHDDRMMFB",           // DR_NMEA_CMDID_DRMMFB,
  "$PHDDRCALCTLT",        // DR_NMEA_CMDID_DRCALCTLT,
  "$PHDDRNVMSAVE",        // DR_NMEA_CMDID_DRNVMSAVE
  NULL                     // DR_NMEA_CMDID_NUMBER
};


/*****************************************************************************
   function prototypes (scope: module-local)
*****************************************************************************/

/* Send functions prototypes */
static void         send_DRMSG_msg            ( void);
static void         send_DRSAM_msg            ( const dr_sample_t *);
static void         send_DRSTATE_msg          ( const dr_msg_state_t *);
static void         send_DRDEBUG_msg          ( const dr_debug_t *);
static void         send_PSTMDRGPS_msg        ( const dr_msg_gps_sample_t *gps_sample);
static void         send_DR_NVM_W_msg         ( void);
static void         send_DR_KALMAN_INIT_msg   ( void);
static void         send_DR_NVM_R_msg         ( void);
static void         send_DR_CAN_MSG_msg       ( void);
static void         send_DR_3Dgyro_MSG_msg    ( void);
static void         send_DR_3Dacc_MSG_msg     ( void);
static void         send_DR_Pres_MSG_msg      ( void);
static void         send_DR_analog_MSG_msg    ( void);
static void         send_DRSTEP_msg           ( const dr_msg_step_t *step);
static void         send_DRCOV_msg            ( const dr_msg_kalman_stddev_t *stddev);
static void         send_DRUPDATE_msg         ( const dr_msg_state_t *update);
static void         send_DRTUNNEL_msg         ( const dr_msg_kal_tunnel_t *tunnel);
static void         send_DRSTYPE_msg          ( const sm_sensor_type_t* sens_type);
static void         send_DRCAL_msg            ( const dr_msg_calib_flags_t* dr_cal);
static void         send_DRAHRS_msg           ( const dr_msg_ahrs_t* dr_ahrs);
static void         send_MMFB_msg             ( const dr_msg_mmfb_t* dr_mmfb);
static void         send_MMFBKF_msg           ( const dr_msg_mmfbkf_t* );
static void         send_DRDBG_msg            ( const dr_msg_dbg_t* dr_dbg);
static void         send_DRDBG_read_nvm_msg   ( const dr_msg_dbg_nvm_t* dr_dbg_nvm);
static void         send_DRDBG_write_nvm_msg  ( const dr_msg_dbg_nvm_t* dr_dbg_nvm);
static void         send_DRDBG_init_msg       ( const dr_msg_dbg_nvm_t* dr_dbg_nvm);
static void         send_DRIMUAA_msg          (const dr_msg_imuaa_t* dr_imuaa);

/* Commands execution functions prototypes */
static void dr_nmea_cmdif_exec_dr_sen_msg ( tChar *);
static void dr_nmea_cmdif_exec_dr_mmfb    ( tChar *msg);
static void dr_nmea_cmdif_exec_dr_calctlt ( tChar *msg);
static void dr_nmea_cmdif_exec_dr_nvmsave ( tChar *msg);
static tInt dr_plugin_nmea_cmdif_parse    ( tChar *, tUInt , tChar *);

static const nmea_support_cmdif_exec_t dr_nmea_cmdif_exec_table[] =
{
  dr_nmea_cmdif_exec_dr_sen_msg,
  dr_nmea_cmdif_exec_dr_mmfb,
  dr_nmea_cmdif_exec_dr_calctlt,
  dr_nmea_cmdif_exec_dr_nvmsave,
  NULL
};

/* Plugin callbacks */
static void       dr_plugin_fix_data_lock_callback    ( void);
static void       dr_plugin_fix_data_unlock_callback  ( void);
static void       dr_plugin_fix_pos_vel_callback      ( position_t *extrap_pos, tDouble *course, tDouble *speed, tDouble delay, void *data_p);
static tInt       dr_plugin_fix_pos_status_callback   ( void);
static boolean_t  dr_plugin_fix_time_callback         ( gpOS_clock_t *fix_time);

/* Misc functions prototypes */
static void                     dr_plugin_enable_dr_msg         ( const boolean_t enable);
static gpOS_error_t             dr_plugin_nmea_outmsg_transmit  ( void *param);

static tUInt nmea_msg_list[2];

/*****************************************************************************
   function implementations (scope: module-local)
*****************************************************************************/

static gpOS_error_t dr_plugin_init( gpOS_partition_t *part)
{
  sm_sensors_config_t *dr_config_ptr;

  if( (dr_plugin_handler = (dr_plugin_handler_t *)gpOS_memory_allocate_p( part, sizeof( dr_plugin_handler_t))) == NULL)
  {
    ERROR_MSG( "[dr]: ERROR dr_plugin_init failed\r\n" );
    return( gpOS_FAILURE );
  }

  dr_config_ptr = (sm_sensors_config_t *)((tUInt)sw_config_private_get_base_address() + sizeof(tInt));

#ifdef __generic__
  GPS_DEBUG_MSG( ( "[dr]:%s - enable_analog =  0x%x\r\n",__func__, dr_config_ptr->enable_analog) );
  GPS_DEBUG_MSG( ( "[dr]:%s - enable_3Dgyro=  0x%x\r\n",__func__, dr_config_ptr->enable_3Dgyro) );
  GPS_DEBUG_MSG( ( "[dr]:%s - enable_3Dacc =  0x%x\r\n",__func__, dr_config_ptr->enable_3Dacc) );
  GPS_DEBUG_MSG( ( "[dr]:%s - enable_can =  0x%x\r\n",__func__, dr_config_ptr->enable_can) );
  GPS_DEBUG_MSG( ( "[dr]:%s - operating_mode = 0x%x\r\n",__func__, dr_config_ptr->operating_mode) );
  GPS_DEBUG_MSG( ( "[dr]:%s - can_port =  0x%x\r\n",__func__, dr_config_ptr->can_port) );
  GPS_DEBUG_MSG( ( "[dr]:%s - baudrate =  0x%x\r\n",__func__, dr_config_ptr->can_config.can_baudrate) );
  GPS_DEBUG_MSG( ( "[dr]:%s - odo_scale_enable =  0x%x\r\n",__func__, dr_config_ptr->odo_scale_enable));
  GPS_DEBUG_MSG( ( "[dr]:%s - gyro_offset_enable =  0x%x\r\n",__func__, dr_config_ptr->gyro_offset_enable));
  GPS_DEBUG_MSG( ( "[dr]:%s - gyro_gain_enable =  0x%x\r\n",__func__,  dr_config_ptr->gyro_gain_enable));
  GPS_DEBUG_MSG( ( "[dr]:%s - gyro_offset =  0x%x\r\n",__func__, dr_config_ptr->gyro_offset));
  GPS_DEBUG_MSG( ( "[dr]:%s - gyro_gain =  0x%x\r\n",__func__,  dr_config_ptr->gyro_gain));
  GPS_DEBUG_MSG( ( "[dr]:%s - sens_en =  0x%x\r\n",__func__, dr_config_ptr->sens_en));
  GPS_DEBUG_MSG( ( "[dr]:%s - sens_buf_size =  0x%x\r\n",__func__, dr_config_ptr->sens_buf_size));
  GPS_DEBUG_MSG( ( "[dr]:%s - CAN_buf_size =  0x%x\r\n",__func__, dr_config_ptr->CAN_buf_size));
#endif

  /* Sensor type must be set before kalman specific parameters configuration settings */
  dr_set_sensor_type((sm_sensor_type_t)sm_get_gyro_sensor_type(dr_config_ptr->operating_mode));

  if( dr_init_config(dr_config_ptr) == GNSS_ERROR)
  {
    ERROR_MSG( "[dr]: ERROR dr_init_config failed\r\n" );
    //return( gpOS_FAILURE );           /* DR init failure should allow the application to switch in GNSS only */
  }

  if( sm_sensors_init_p( part, dr_config_ptr) == GNSS_ERROR)
  {
    ERROR_MSG( "[dr]: ERROR sm_init failed\r\n" );
    //return( gpOS_FAILURE );           /* DR init failure should allow the application to switch in GNSS only */
  }
  /* TO DO: To implement a DR init failure management strategy */

  if ( sm_can_init_p( part, dr_config_ptr) == GNSS_ERROR )
  {
    ERROR_MSG( "[dr]: ERROR sm_can_init failed\r\n" );
    //return( gpOS_FAILURE );           /* DR init failure should allow the application to switch in GNSS only */
  }

  /* Set dr message NMEA log enable/disable */
  if(TRUE == dr_config_ptr->sm_msg_disable)
  {
    dr_plugin_enable_dr_msg(FALSE);
  }
  else
  {
    dr_plugin_enable_dr_msg(TRUE);
  }

  /* Configure nmea interface */
  nmea_set_fix_event_type(GNSS_EVENTID_DRFIXREADY);
  nmea_set_fix_data_lock_callback((nmea_fix_data_lock_callback_t)&dr_plugin_fix_data_lock_callback);
  nmea_set_fix_data_unlock_callback((nmea_fix_data_unlock_callback_t)&dr_plugin_fix_data_unlock_callback);
  nmea_set_fix_pos_vel_callback((nmea_fix_pos_vel_callback_t)&dr_plugin_fix_pos_vel_callback);
  nmea_set_fix_pos_status_callback((nmea_fix_pos_status_callback_t)&dr_plugin_fix_pos_status_callback);
  nmea_set_fix_data_extrapolate_callback((nmea_fix_data_extrapolate_callback_t)&dr_plugin_fix_time_callback);

  #if defined( STBIN_LINKED )
  stbin_dr_plugin_init( dr_plugin_handler);
  #endif

  return gpOS_SUCCESS;
}

static gpOS_error_t dr_plugin_suspend( void)
{
  dr_suspend();

  return gpOS_SUCCESS;
}

static gpOS_error_t dr_plugin_restart( void)
{
  dr_restart();
  return gpOS_SUCCESS;
}


static void send_DRSAM_msg(const dr_sample_t *dr_sample)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  index = _clibs_sprintf(out_msg, "$PHDDRSAM");
  //index += _clibs_sprintf(&out_msg[index], ",%d,%.4lf,%d,%d", dr_sample->cpu_time, dr_sample->gyro_volts, dr_sample->odo_count, dr_sample->reverse);
  index += _clibs_sprintf(&out_msg[index], ",%u,%d,%d,%d", dr_sample->cpu_time, (tInt)dr_sample->gyro_volts, dr_sample->odo_count, dr_sample->reverse);
  index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(&out_msg[index], "\r\n");

  nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );

}
static void send_DRSTATE_msg(const dr_msg_state_t *state)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  index = _clibs_sprintf(out_msg, "$PHDDRSTATE,%u,%3.7lf,%3.7lf,%1.2lf,%1.2lf,%1.4lf,%1.4lf,%1.5lf,%1.6lf,%1.6lf,%1.1lf",
    state->cpu_time,
    MCR_FP32_QM_TO_DOUBLE(state->lat,DR_MSG_DOUBLE_2_FP_FRACT24),
    MCR_FP32_QM_TO_DOUBLE(state->lon,DR_MSG_DOUBLE_2_FP_FRACT23),
    MCR_FP32_QM_TO_DOUBLE(state->heading,DR_MSG_DOUBLE_2_FP_FRACT23),
    MCR_FP32_QM_TO_DOUBLE(state->speed,DR_MSG_DOUBLE_2_FP_FRACT24),
    MCR_FP32_QM_TO_DOUBLE(state->gyro_offset,DR_MSG_DOUBLE_2_FP_FRACT24),
    MCR_FP32_QM_TO_DOUBLE(state->gyro_gain,DR_MSG_DOUBLE_2_FP_FRACT24),
    MCR_FP32_QM_TO_DOUBLE(state->odo_scale,DR_MSG_DOUBLE_2_FP_FRACT24),
    MCR_FP32_QM_TO_DOUBLE(state->gyro_ovst,DR_MSG_DOUBLE_2_FP_FRACT24),
    MCR_FP32_QM_TO_DOUBLE(state->acc_offset,DR_MSG_DOUBLE_2_FP_FRACT24),
    MCR_FP32_QM_TO_DOUBLE(state->height,DR_MSG_DOUBLE_2_FP_FRACT08)
    );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_STATE_NMEA_MSG );
}

static void send_DRDEBUG_msg(const dr_debug_t *debug)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

	index = _clibs_sprintf(out_msg, "$PHDDRDEBUG,%.1lf,%.1lf,%.1lf,%.1lf,%.1lf,%.1lf",
                         debug->lat_error,
                         debug->lon_error,
                         debug->heading_error,
                         debug->speed_error,
                         debug->height_error,
                         debug->vel_v_error
                         );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );
}

static void send_PSTMDRGPS_msg(const dr_msg_gps_sample_t *gps_sample)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

	index = _clibs_sprintf(out_msg, "$PHDDRGPS,%.9f,%.9f,%.5f,%.5f,%.3f,%.3f,%.3f,%.3f,%.3f,%.5f,%.1f",
			gps_sample->lat,
			gps_sample->lon,
			MCR_FP32_QM_TO_DOUBLE(gps_sample->vn,DR_MSG_DOUBLE_2_FP_FRACT14),
			MCR_FP32_QM_TO_DOUBLE(gps_sample->ve,DR_MSG_DOUBLE_2_FP_FRACT14),
			MCR_FP32_QM_TO_DOUBLE(gps_sample->pdop,DR_MSG_DOUBLE_2_FP_FRACT14),
			MCR_FP32_QM_TO_DOUBLE(gps_sample->hdop,DR_MSG_DOUBLE_2_FP_FRACT14),
			MCR_FP32_QM_TO_DOUBLE(gps_sample->vdop,DR_MSG_DOUBLE_2_FP_FRACT14),
			MCR_FP32_QM_TO_DOUBLE(gps_sample->rms_pos_residual,DR_MSG_DOUBLE_2_FP_FRACT14),
			MCR_FP32_QM_TO_DOUBLE(gps_sample->rms_vel_residual,DR_MSG_DOUBLE_2_FP_FRACT14),
			MCR_FP32_QM_TO_DOUBLE(gps_sample->vv,DR_MSG_DOUBLE_2_FP_FRACT14),
      MCR_FP32_QM_TO_DOUBLE(gps_sample->height,DR_MSG_DOUBLE_2_FP_FRACT08)
      );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_GPS_SAMPLE_NMEA_MSG );
}

static void send_DR_NVM_W_msg(void)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];
  tUInt imu_axes;
  tU8 imu_flags;
  dr_status_backup_t dr_status_backup;

  dr_get_status_backup(&dr_status_backup);

  imu_axes = ((((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[0]  & 0xf)<<20) |
              (((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[1]  & 0xf)<<16) |
              (((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[2]  & 0xf)<<12) |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[0] & 0xf)<<8)  |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[1] & 0xf)<<4)  |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[2] & 0xf)));

  imu_flags = (((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[0]<<5) |
               ((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[1]<<4) |
               ((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[2]<<3) |
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[0]<<2)|
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[1]<<1)|
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[2]))  |
               (((tU8)dr_status_backup.tilt_angles.roll_calib<<6)         |
               ((tU8)dr_status_backup.tilt_angles.pitch_calib<<7));

  index = _clibs_sprintf(out_msg, "$PHDDRNVM_WRITE,%3.8lf,%3.8lf,%1.3lf,%.5lf,%.4lf,%.4lf,%.3lf,%.3lf,%.3lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.1lf,%.1lf,%.1lf,%.1lf,%1x,%4x,%2x,%.6lf,%.6lf,%.6lf,%.1lf,%.6lf,%.3lf",
          dr_status_backup.dr_state_copy.lat,
          dr_status_backup.dr_state_copy.lon,
          dr_status_backup.dr_state_copy.heading,
          dr_status_backup.dr_state_copy.gyro_offset,
          dr_status_backup.dr_state_copy.gyro_gain,
          dr_status_backup.dr_state_copy.odo_scale,
          dr_status_backup.std_dev_copy.lat,
          dr_status_backup.std_dev_copy.lon,
          dr_status_backup.std_dev_copy.heading,
          dr_status_backup.std_dev_copy.gyro_offset,
          dr_status_backup.std_dev_copy.gyro_gain,
          dr_status_backup.std_dev_copy.odo_scale,
          dr_status_backup.dr_state_copy.gyro_ovst,
          dr_status_backup.std_dev_copy.gyro_ovst,
          dr_status_backup.temperature,
          dr_status_backup.tilt_angles.pitch,
          dr_status_backup.tilt_angles.roll,
          dr_status_backup.tilt_angles.yaw,
          ((dr_status_backup.dr_calib_status.gyro_offset_calib<<2)|
          (dr_status_backup.dr_calib_status.gyro_gain_calib   <<1)|
          (dr_status_backup.dr_calib_status.odo_scale_calib    )),
          imu_axes,
          imu_flags,
          dr_status_backup.dr_imu_sensors.acc.offset[0],
          dr_status_backup.dr_imu_sensors.acc.offset[1],
          dr_status_backup.dr_imu_sensors.acc.offset[2],
          dr_status_backup.dr_state_copy.height,
          dr_status_backup.std_dev_copy.acc_offs,
          dr_status_backup.std_dev_copy.height
          );

  index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(&out_msg[index], "\r\n");

  nmea_send_outmsg( out_msg, index, DR_NVM_ACCESS_NMEA_MSG );
}

static void send_DR_KALMAN_INIT_msg(void)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];
  tUInt imu_axes;
  tU8 imu_flags;
  dr_status_backup_t dr_status_backup;

  dr_get_status_backup(&dr_status_backup);

  imu_axes = ((((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[0]  & 0xf)<<20) |
              (((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[1]  & 0xf)<<16) |
              (((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[2]  & 0xf)<<12) |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[0] & 0xf)<<8)  |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[1] & 0xf)<<4)  |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[2] & 0xf)));

  imu_flags = (((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[0]<<5) |
               ((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[1]<<4) |
               ((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[2]<<3) |
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[0]<<2)|
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[1]<<1)|
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[2]))  |
               (((tU8)dr_status_backup.tilt_angles.roll_calib<<6)         |
               ((tU8)dr_status_backup.tilt_angles.pitch_calib<<7));

  index = _clibs_sprintf(out_msg, "$PHD_KALMAN_INIT,%3.8lf,%3.8lf,%1.3lf,%.5lf,%.4lf,%.4lf,%.3lf,%.3lf,%.3lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.1lf,%.1lf,%.1lf,%.1lf,%1x,%4x,%2x,%.6lf,%.6lf,%.6lf,%.1lf,%.6lf,%.3lf",
          dr_status_backup.dr_state_copy.lat,
          dr_status_backup.dr_state_copy.lon,
          dr_status_backup.dr_state_copy.heading,
          dr_status_backup.dr_state_copy.gyro_offset,
          dr_status_backup.dr_state_copy.gyro_gain,
          dr_status_backup.dr_state_copy.odo_scale,
          dr_status_backup.std_dev_copy.lat,
          dr_status_backup.std_dev_copy.lon,
          dr_status_backup.std_dev_copy.heading,
          dr_status_backup.std_dev_copy.gyro_offset,
          dr_status_backup.std_dev_copy.gyro_gain,
          dr_status_backup.std_dev_copy.odo_scale,
          dr_status_backup.dr_state_copy.gyro_ovst,
          dr_status_backup.std_dev_copy.gyro_ovst,
          dr_status_backup.temperature,
          dr_status_backup.tilt_angles.pitch,
          dr_status_backup.tilt_angles.roll,
          dr_status_backup.tilt_angles.yaw,
          ((dr_status_backup.dr_calib_status.gyro_offset_calib<<2)|
          (dr_status_backup.dr_calib_status.gyro_gain_calib   <<1)|
          (dr_status_backup.dr_calib_status.odo_scale_calib    )),
          imu_axes,
          imu_flags,
          dr_status_backup.dr_imu_sensors.acc.offset[0],
          dr_status_backup.dr_imu_sensors.acc.offset[1],
          dr_status_backup.dr_imu_sensors.acc.offset[2],
          dr_status_backup.dr_state_copy.height,
          dr_status_backup.std_dev_copy.acc_offs,
          dr_status_backup.std_dev_copy.height
          );

    index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
    index += _clibs_sprintf(&out_msg[index], "\r\n");

    nmea_send_outmsg( out_msg, index, DR_NVM_ACCESS_NMEA_MSG );
}

static void send_DR_NVM_R_msg(void)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];
  tUInt imu_axes;
  tU8 imu_flags;
  dr_status_backup_t dr_status_backup;

  dr_get_status_backup(&dr_status_backup);

  imu_axes = ((((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[0]  & 0xf)<<20) |
              (((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[1]  & 0xf)<<16) |
              (((tUInt)dr_status_backup.dr_imu_axes.acc_axes_map[2]  & 0xf)<<12) |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[0] & 0xf)<<8)  |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[1] & 0xf)<<4)  |
              (((tUInt)dr_status_backup.dr_imu_axes.gyro_axes_map[2] & 0xf)));

  imu_flags = (((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[0]<<5) |
               ((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[1]<<4) |
               ((tU8)dr_status_backup.dr_imu_axes.acc_axes_validity[2]<<3) |
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[0]<<2)|
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[1]<<1)|
               ((tU8)dr_status_backup.dr_imu_axes.gyro_axes_validity[2]))  |
               (((tU8)dr_status_backup.tilt_angles.roll_calib<<6)         |
               ((tU8)dr_status_backup.tilt_angles.pitch_calib<<7));

  index = _clibs_sprintf(out_msg, "$PHDDRNVM_READ,%3.8lf,%3.8lf,%1.3lf,%.5lf,%.4lf,%.4lf,%.3lf,%.3lf,%.3lf,%.6lf,%.6lf,%.6lf,%.6lf,%.6lf,%.1lf,%.1lf,%.1lf,%.1lf,%1x,%4x,%2x,%.6lf,%.6lf,%.6lf,%.1lf,%.6lf,%.3lf",
          dr_status_backup.dr_state_copy.lat,
          dr_status_backup.dr_state_copy.lon,
          dr_status_backup.dr_state_copy.heading,
          dr_status_backup.dr_state_copy.gyro_offset,
          dr_status_backup.dr_state_copy.gyro_gain,
          dr_status_backup.dr_state_copy.odo_scale,
          dr_status_backup.std_dev_copy.lat,
          dr_status_backup.std_dev_copy.lon,
          dr_status_backup.std_dev_copy.heading,
          dr_status_backup.std_dev_copy.gyro_offset,
          dr_status_backup.std_dev_copy.gyro_gain,
          dr_status_backup.std_dev_copy.odo_scale,
          dr_status_backup.dr_state_copy.gyro_ovst,
          dr_status_backup.std_dev_copy.gyro_ovst,
          dr_status_backup.temperature,
          dr_status_backup.tilt_angles.pitch,
          dr_status_backup.tilt_angles.roll,
          dr_status_backup.tilt_angles.yaw,
          ((dr_status_backup.dr_calib_status.gyro_offset_calib<<2)|
          (dr_status_backup.dr_calib_status.gyro_gain_calib   <<1)|
          (dr_status_backup.dr_calib_status.odo_scale_calib    )),
          imu_axes,
          imu_flags,
          dr_status_backup.dr_imu_sensors.acc.offset[0],
          dr_status_backup.dr_imu_sensors.acc.offset[1],
          dr_status_backup.dr_imu_sensors.acc.offset[2],
          dr_status_backup.dr_state_copy.height,
          dr_status_backup.std_dev_copy.acc_offs,
          dr_status_backup.std_dev_copy.height
          );

  index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(&out_msg[index], "\r\n");

  nmea_send_outmsg( out_msg, index, DR_NVM_ACCESS_NMEA_MSG );
}


/*}}}  */

static void send_DR_CAN_MSG_msg(void)
{
  tInt i;
  sm_can_msg_t dr_can_msg;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  while(sm_can_receive_message(&dr_can_msg) == gpOS_SUCCESS)
  {
    if((nmea_msg_list_check(nmea_msg_list,DR_RAW_SEN_SAMPLES_NMEA_MSG) == TRUE) || (TRUE == dr_plugin_handler->pstmdr_msg_enable))
    {
      tInt index     = 0;

      index = _clibs_sprintf(out_msg, "$PHDDRCAN,%02d,%02d,%u,",dr_can_msg.car_maker_id,dr_can_msg.can_obj_id,dr_can_msg.can_cpu_time);

      for(i=0;i<SM_CAN_MSG_PAYLOAD;i++)
      {
        index += _clibs_sprintf(&out_msg[index],"%02x",dr_can_msg.can_msg[i]);
      }
      index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
      index += _clibs_sprintf(&out_msg[index], "\r\n");

      nmea_send_outmsg( out_msg, index, DR_RAW_SEN_SAMPLES_NMEA_MSG );
    }
  }

}

static void send_DR_3Dgyro_MSG_msg(void)
{
  sm_3Dgyro_sample_t dr_3Dgyro_msg;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  while(sm_3Dgyro_receive_sample(&dr_3Dgyro_msg) == gpOS_SUCCESS)
  {
    if((nmea_msg_list_check(nmea_msg_list,DR_RAW_SEN_SAMPLES_NMEA_MSG) == TRUE) || (TRUE == dr_plugin_handler->pstmdr_msg_enable))
    {
      tInt index     = 0;

      index = _clibs_sprintf(out_msg, "$PHD3DGYRO,%u,%d,%d,%d,%d,%d",dr_3Dgyro_msg.slld_3Dgyro_sample.gyro_3D_cpu_time,(tShort)dr_3Dgyro_msg.slld_3Dgyro_sample.gyro_3D_x_data,(tShort)dr_3Dgyro_msg.slld_3Dgyro_sample.gyro_3D_y_data,(tShort)dr_3Dgyro_msg.slld_3Dgyro_sample.gyro_3D_z_data,dr_3Dgyro_msg.odo_sample.odo_count,dr_3Dgyro_msg.odo_sample.reverse);
      index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
      index += _clibs_sprintf(&out_msg[index], "\r\n");
      nmea_send_outmsg( out_msg, index, DR_RAW_SEN_SAMPLES_NMEA_MSG );
    }
  }
}

static void send_DR_3Dacc_MSG_msg(void)
{
  slld_3Dacc_sample_t dr_3Dacc_msg;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  while(sm_3Dacc_receive_sample(&dr_3Dacc_msg) == gpOS_SUCCESS)
  {
    if((nmea_msg_list_check(nmea_msg_list,DR_RAW_SEN_SAMPLES_NMEA_MSG) == TRUE) || (TRUE == dr_plugin_handler->pstmdr_msg_enable))
    {
      tInt index     = 0;

      index = _clibs_sprintf(out_msg, "$PHD3DACC,%u,%d,%d,%d",dr_3Dacc_msg.acc_3D_cpu_time,(tShort)dr_3Dacc_msg.acc_3D_x_data,(tShort)dr_3Dacc_msg.acc_3D_y_data,(tShort)dr_3Dacc_msg.acc_3D_z_data);
      index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
      index += _clibs_sprintf(&out_msg[index], "\r\n");
      nmea_send_outmsg( out_msg, index, DR_RAW_SEN_SAMPLES_NMEA_MSG );
    }
  }

}

static void send_DR_Pres_MSG_msg(void)
{
  slld_Pres_sample_t dr_pres_msg;
  tChar out_msg[64];

  while(sm_pres_receive_sample(&dr_pres_msg) == gpOS_SUCCESS)
  {
    if((nmea_msg_list_check(nmea_msg_list,DR_RAW_SEN_SAMPLES_NMEA_MSG) == TRUE) || (TRUE == dr_plugin_handler->pstmdr_msg_enable))
    {
      tInt index     = 0;

      index = _clibs_sprintf(out_msg, "$PHDDRPRES,%u,%d",dr_pres_msg.pres_cpu_time,(tInt)dr_pres_msg.pres_data);
      index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
      index += _clibs_sprintf(&out_msg[index], "\r\n");
      nmea_send_outmsg( out_msg, index, DR_RAW_SEN_SAMPLES_NMEA_MSG );
    }
  }
}

static void send_DR_analog_MSG_msg(void)
{
  sm_analog_sample_t dr_analog_msg;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  while(sm_analog_receive_sample(&dr_analog_msg) == gpOS_SUCCESS)
  {
    if((nmea_msg_list_check(nmea_msg_list,DR_RAW_SEN_SAMPLES_NMEA_MSG) == TRUE) || (TRUE == dr_plugin_handler->pstmdr_msg_enable))
    {
      tInt index     = 0;

      index = _clibs_sprintf(out_msg, "$PHDDRSAM,%u,%d,%d,%d",dr_analog_msg.cpu_time,dr_analog_msg.gyro_volts,dr_analog_msg.odo_count,dr_analog_msg.reverse);
      index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
      index += _clibs_sprintf(&out_msg[index], "\r\n");

      nmea_send_outmsg( out_msg, index, DR_RAW_SEN_SAMPLES_NMEA_MSG );
    }
  }
}

static void send_DRSTEP_msg(const dr_msg_step_t *step)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

	index = _clibs_sprintf(out_msg, "$PHDDRSTEP,%d,%.5lf,%.5lf,%d,%d,%.3lf,%.3lf,%d",
			        step->sample_count,
			        MCR_FP32_QM_TO_DOUBLE(step->yaw_rate_volts,DR_MSG_DOUBLE_2_FP_FRACT24),
			        MCR_FP32_QM_TO_DOUBLE(step->gyro_noise,DR_MSG_DOUBLE_2_FP_FRACT24),
			        step->tot_odo_step,
			        (step->final_odo_count - step->initial_odo_count),
			        MCR_FP32_QM_TO_DOUBLE(step->cpu_delta_time,DR_MSG_DOUBLE_2_FP_FRACT24),
			        ((tDouble) (step->final_cpu_time - step->initial_cpu_time))/(1023000.0),
			        step->valid_odo
			        );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );
}

static void send_DRCOV_msg(const dr_msg_kalman_stddev_t *stddev)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

	index = _clibs_sprintf(out_msg, "$PHDDRCOV,%.2lf,%.2lf,%.4lf,%.4lf,%.2lf,%.4lf,%.6lf,%.6lf,%.4lf",
                         MCR_FP32_QM_TO_DOUBLE(stddev->lat,DR_MSG_DOUBLE_2_FP_FRACT08),
                         MCR_FP32_QM_TO_DOUBLE(stddev->lon,DR_MSG_DOUBLE_2_FP_FRACT08),
                         MCR_FP32_QM_TO_DOUBLE(stddev->heading,DR_MSG_DOUBLE_2_FP_FRACT18),
                         MCR_FP32_QM_TO_DOUBLE(stddev->gyro_gain,DR_MSG_DOUBLE_2_FP_FRACT18)*GAIN_SCALE,
                         MCR_FP32_QM_TO_DOUBLE(stddev->gyro_offset,DR_MSG_DOUBLE_2_FP_FRACT18)*OFFS_SCALE,
                         MCR_FP32_QM_TO_DOUBLE(stddev->odo_scale,DR_MSG_DOUBLE_2_FP_FRACT18)*SCALE_SCALE,
                         MCR_FP32_QM_TO_DOUBLE(stddev->gyro_ovst,DR_MSG_DOUBLE_2_FP_FRACT18),
                         MCR_FP32_QM_TO_DOUBLE(stddev->acc_offset,DR_MSG_DOUBLE_2_FP_FRACT18),
                         MCR_FP32_QM_TO_DOUBLE(stddev->height,DR_MSG_DOUBLE_2_FP_FRACT08)
                       );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_COVARIANCE_NMEA_MSG );
}

static void send_DRUPDATE_msg(const dr_msg_state_t *update)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

	index = _clibs_sprintf(out_msg, "$PHDDRUPD,%.1lf,%.1lf,%.1lf,%.2lf,%.3lf,%.3lf,%.6lf,%.6lf,%.1lf",
                         MCR_FP32_QM_TO_DOUBLE(update->lat,DR_MSG_DOUBLE_2_FP_FRACT18),
                         MCR_FP32_QM_TO_DOUBLE(update->lon,DR_MSG_DOUBLE_2_FP_FRACT18),
                         MCR_FP32_QM_TO_DOUBLE(update->heading,DR_MSG_DOUBLE_2_FP_FRACT18),
                         MCR_FP32_QM_TO_DOUBLE(update->gyro_gain,DR_MSG_DOUBLE_2_FP_FRACT23)*GAIN_SCALE,
                         MCR_FP32_QM_TO_DOUBLE(update->gyro_offset,DR_MSG_DOUBLE_2_FP_FRACT23)*OFFS_SCALE,
                         MCR_FP32_QM_TO_DOUBLE(update->odo_scale,DR_MSG_DOUBLE_2_FP_FRACT23)*SCALE_SCALE,
                         MCR_FP32_QM_TO_DOUBLE(update->gyro_ovst,DR_MSG_DOUBLE_2_FP_FRACT23),
                         MCR_FP32_QM_TO_DOUBLE(update->acc_offset,DR_MSG_DOUBLE_2_FP_FRACT23),
                         MCR_FP32_QM_TO_DOUBLE(update->height,DR_MSG_DOUBLE_2_FP_FRACT18)
                        );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );
}

static void send_DRTUNNEL_msg(const dr_msg_kal_tunnel_t *tunnel)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

	index = _clibs_sprintf(out_msg,"$PHDDRTUNNEL,%d,%d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f",
				    tunnel->exit,          //bool
				    tunnel->duration,      //s
				    MCR_FP32_QM_TO_DOUBLE(tunnel->length,DR_MSG_DOUBLE_2_FP_FRACT14),        //m
				    MCR_FP32_QM_TO_DOUBLE(tunnel->head_error,DR_MSG_DOUBLE_2_FP_FRACT14),    //deg
				    MCR_FP32_QM_TO_DOUBLE(tunnel->yaw_rate_error,DR_MSG_DOUBLE_2_FP_FRACT14),//deg/s
				    MCR_FP32_QM_TO_DOUBLE(tunnel->calib_error,DR_MSG_DOUBLE_2_FP_FRACT14),   //mV
				    MCR_FP32_QM_TO_DOUBLE(tunnel->pos_error,DR_MSG_DOUBLE_2_FP_FRACT14),     //m
				    MCR_FP32_QM_TO_DOUBLE(tunnel->pos_error_perc,DR_MSG_DOUBLE_2_FP_FRACT14),//%
				    MCR_FP32_QM_TO_DOUBLE(tunnel->noise_error,DR_MSG_DOUBLE_2_FP_FRACT14));  //deg

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );
}

static void send_DRSTYPE_msg(const sm_sensor_type_t* sens_type)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

	index = _clibs_sprintf(out_msg,"$PHDDRSTYPE,%d",*sens_type);

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );
}


static void send_DROFFSET_msg(const dr_kal_yaw_rate_offset_t* offset)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  index = _clibs_sprintf(out_msg,"$PHDDROFFSET,%d,%.2lf,%.2lf,%d,%.2lf,%d,%.3f",
                           offset->static_calib,
                           offset->last_stopped_value,
                           offset->yaw_rate_signal_std_dev*1000, //mV
                           offset->calibrated,
                           offset->error,
                           offset->calibrated_time,
                           offset->temperature_correction*1000 //mV
                          );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );
}

static void send_DRCAL_msg(const dr_msg_calib_flags_t* dr_cal)
{
	tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];
  tU8 imu_flags;
  boolean_t dr_is_calib = FALSE;
  tChar dr_calib_state = 'N';

  imu_flags = (((tU8)dr_cal->acc_axes_validity[0]<<5) |
               ((tU8)dr_cal->acc_axes_validity[1]<<4) |
               ((tU8)dr_cal->acc_axes_validity[2]<<3) |
               ((tU8)dr_cal->gyro_axes_validity[0]<<2)|
               ((tU8)dr_cal->gyro_axes_validity[1]<<1)|
               ((tU8)dr_cal->gyro_axes_validity[2]))  |
               (((tU8)dr_cal->roll_calib<<6)         |
               ((tU8)dr_cal->pitch_calib<<7));

  if((TRUE == dr_cal->odo_is_calib)&&
     (TRUE == dr_cal->gyro_gain_is_calib)&&
     (TRUE == dr_cal->gyro_offset_is_calib))
  {
    dr_is_calib = TRUE;
  }

  if((dr_cal->odo_is_calib         == TRUE) &&
     (dr_cal->gyro_offset_is_calib == TRUE) &&
     (dr_cal->gyro_gain_is_calib   == FALSE))
  {
     dr_calib_state = 'L';
  }

  if(dr_is_calib == TRUE)
  {
     dr_calib_state = 'F';
  }

  index = _clibs_sprintf(out_msg,"$PHDDRCAL,%u,%u,%u,%u,%2x,%u,%u,%c",
                          dr_is_calib,
                          dr_cal->odo_is_calib,
                          dr_cal->gyro_gain_is_calib,
                          dr_cal->gyro_offset_is_calib,
                          imu_flags,
                          dr_cal->gyro_integrity,
                          dr_cal->acc_integrity,
                          dr_calib_state
                        );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_CALIBRATION_NMEA_MSG );
}

static void send_DRAHRS_msg(const dr_msg_ahrs_t* dr_ahrs)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  index = _clibs_sprintf(out_msg,"$PHDDRAHRS,%.1f,%.1f,%.1f,%.3f,%.3f,%.1f",
                          dr_ahrs->tilt_angles.pitch,
                          dr_ahrs->tilt_angles.roll,
                          dr_ahrs->tilt_angles.yaw,
                          dr_ahrs->slope,
                          dr_ahrs->slope_accuracy,
                          dr_ahrs->delta_height
                        );

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_SLOPE_NMEA_MSG );
}

static void send_MMFB_msg(const dr_msg_mmfb_t* dr_mmfb)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];
  tUInt hhmmss = (tUInt)dr_mmfb->utc;
  tUInt ms;

  ms = (tUInt)((dr_mmfb->utc - (tDouble)hhmmss)*1000);

  index = _clibs_sprintf(out_msg,"$PHDDRMMFB,%06d.%03d,%1u,%1u,%1u,%1u,%.9f,%.9f,%.1f,%.5f,%.4f,%.4f,%.4f,%.4f",
                         hhmmss,
                         ms,
                         ((dr_mmfb->validity) & 0x8) >> 3,
                         ((dr_mmfb->validity) & 0x4) >> 2,
                         ((dr_mmfb->validity) & 0x2) >> 1,
                         ((dr_mmfb->validity) & 0x1),
                         dr_mmfb->lat,
                         dr_mmfb->lon,
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfb->height, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfb->heading, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfb->lat_error, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfb->lon_error, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfb->height_error, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfb->heading_error, DR_MSG_DOUBLE_2_FP_FRACT23 ));

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );
}

static void send_MMFBKF_msg(const dr_msg_mmfbkf_t* dr_mmfbkf)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  index = _clibs_sprintf(out_msg,"$PHDDRMMFBKF,%u,%u,%d,%d,%1u,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%1u,%.2f,%.2f,%.2f",
                         dr_mmfbkf->cpu_time,
                         dr_mmfbkf->elapsed_time,
                         dr_mmfbkf->utc_delta_s,
                         dr_mmfbkf->utc_delta_ms,
                         dr_mmfbkf->pos_accepted,
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_innov_lat, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_innov_lon, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_meas_noise_lat, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_meas_noise_lon, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_update_lat, DR_MSG_DOUBLE_2_FP_FRACT24 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_update_lon, DR_MSG_DOUBLE_2_FP_FRACT23 ),
                         dr_mmfbkf->hea_accepted,
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->hea_innov, DR_MSG_DOUBLE_2_FP_FRACT23 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->hea_meas_noise, DR_MSG_DOUBLE_2_FP_FRACT23 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->hea_update, DR_MSG_DOUBLE_2_FP_FRACT23 ));

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );

	#ifdef NAVIREPLAY
	DR_DEBUG_MSG(("$PHDDRMMFBKF,%u,%u,%d,%d,%1u,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%1u,%.2f,%.2f,%.2f\r\n",
                         dr_mmfbkf->cpu_time,
                         dr_mmfbkf->elapsed_time,
                         dr_mmfbkf->utc_delta_s,
                         dr_mmfbkf->utc_delta_ms,
                         dr_mmfbkf->pos_accepted,
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_innov_lat, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_innov_lon, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_meas_noise_lat, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_meas_noise_lon, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_update_lat, DR_MSG_DOUBLE_2_FP_FRACT24 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->pos_update_lon, DR_MSG_DOUBLE_2_FP_FRACT23 ),
                         dr_mmfbkf->hea_accepted,
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->hea_innov, DR_MSG_DOUBLE_2_FP_FRACT23 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->hea_meas_noise, DR_MSG_DOUBLE_2_FP_FRACT23 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_mmfbkf->hea_update, DR_MSG_DOUBLE_2_FP_FRACT23 )));
	#endif /*NAVIREPLAY*/
}


static void send_DRGNSA_msg(const dr_msg_drgnsa_t* dr_gnsa)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  index = _clibs_sprintf(out_msg,"$PHDDRGNSA,%1u,%1u,%1u,%1u,%1u,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f",
                         dr_gnsa->accepted,
                         dr_gnsa->valid_for_heading,
                         dr_gnsa->valid_for_offset,
                         dr_gnsa->valid_for_gain,
                         dr_gnsa->valid_for_odo,
                         MCR_FP32_QM_TO_DOUBLE( dr_gnsa->lat_meas_noise, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_gnsa->lon_meas_noise, DR_MSG_DOUBLE_2_FP_FRACT14 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_gnsa->height_meas_noise, DR_MSG_DOUBLE_2_FP_FRACT18 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_gnsa->hea_meas_noise, DR_MSG_DOUBLE_2_FP_FRACT23 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_gnsa->vel_v_meas_noise, DR_MSG_DOUBLE_2_FP_FRACT23 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_gnsa->pos_error, DR_MSG_DOUBLE_2_FP_FRACT18 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_gnsa->height_error, DR_MSG_DOUBLE_2_FP_FRACT18 ),
                         MCR_FP32_QM_TO_DOUBLE( dr_gnsa->vel_error, DR_MSG_DOUBLE_2_FP_FRACT24 ),
                         MCR_FP16_QM_TO_DOUBLE( dr_gnsa->signal_strength, DR_MSG_DOUBLE_2_FP_FRACT08 ));

	index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
	index += _clibs_sprintf(&out_msg[index], "\r\n");

	nmea_send_outmsg( out_msg, index, DR_DEBUG_NMEA_MSG );

}

static void send_DRDBG_msg(const dr_msg_dbg_t* dr_dbg)
{
  tInt index     = 0;
  tChar out_msg[256];
  tU8 i;

  index = _clibs_sprintf(out_msg,"$PHDDRDBG,%1u,%1c,%1u",
                         dr_dbg->mod_id,
                         dr_dbg->type_id,
                         dr_dbg->data_id);

  for(i = 0; i < DR_MSG_DBG_PAYLOAD_SIZE; i++)
  {
    index += _clibs_sprintf(out_msg + index, ",%f",dr_dbg->data[i]);
  }

  index += _clibs_sprintf(out_msg + index, "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(out_msg + index, "\r\n");

  nmea_send_msg_to_uart(out_msg, index);
}

static void send_DRDBG_read_nvm_msg(const dr_msg_dbg_nvm_t* dr_dbg_nvm)
{
  tInt index     = 0;
  tChar out_msg[256];
  tU8 i;

  index = _clibs_sprintf(out_msg,"$PHDDRDBGNVM_READ,%1u", dr_dbg_nvm->mod_id);

  for(i = 0; i < DR_MSG_DBG_NVM_PAYLOAD_SIZE; i++)
  {
    index += _clibs_sprintf(out_msg + index, ",%.4f",dr_dbg_nvm->data[i]);
  }

  index += _clibs_sprintf(out_msg + index, "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(out_msg + index, "\r\n");

  nmea_send_msg_to_uart(out_msg, index);
}

static void send_DRDBG_write_nvm_msg(const dr_msg_dbg_nvm_t* dr_dbg_nvm)
{
  tInt index     = 0;
  tChar out_msg[256];
  tU8 i;

  index = _clibs_sprintf(out_msg,"$PHDDRDBGNVM_WRITE,%1u", dr_dbg_nvm->mod_id);

  for(i = 0; i < DR_MSG_DBG_NVM_PAYLOAD_SIZE; i++)
  {
    index += _clibs_sprintf(out_msg + index, ",%.4f",dr_dbg_nvm->data[i]);
  }

  index += _clibs_sprintf(out_msg + index, "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(out_msg + index, "\r\n");

  nmea_send_msg_to_uart(out_msg, index);
}

static void send_DRDBG_init_msg(const dr_msg_dbg_nvm_t* dr_dbg_nvm)
{
  tInt index     = 0;
  tChar out_msg[256];
  tU8 i;

  index = _clibs_sprintf(out_msg,"$PHDDRDBG_INIT,%1u", dr_dbg_nvm->mod_id);

  for(i = 0; i < DR_MSG_DBG_NVM_PAYLOAD_SIZE; i++)
  {
      index += _clibs_sprintf(out_msg + index, ",%.4f",dr_dbg_nvm->data[i]);
  }

  index += _clibs_sprintf(out_msg + index, "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(out_msg + index, "\r\n");

  nmea_send_msg_to_uart(out_msg, index);
}

static void send_DRIMUAA_msg(const dr_msg_imuaa_t* dr_imuaa)
{
  tInt index     = 0;
  tChar out_msg[256];
  tU8 i;
  tS8 imu_axes[DR_MSG_IMUAA_N_AXES + 1U],offset;

  index = _clibs_sprintf(out_msg,"$PHDDRIMUAA,%1u,%1u",
                         dr_imuaa->acc_est_status,
                         dr_imuaa->gyro_est_status);

  for(i = 0; i < DR_MSG_IMUAA_N_AXES; i++)
  {
      offset = (dr_imuaa->imu_mask[i] >= 0)?48:103;
      imu_axes[i] = offset + dr_imuaa->imu_mask[i];
  }
  imu_axes[DR_MSG_IMUAA_N_AXES] = 0;
  index += _clibs_sprintf(out_msg + index, ",%s",imu_axes);
  index += _clibs_sprintf(out_msg + index, "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(out_msg + index, "\r\n");

  nmea_send_msg_to_uart(out_msg, index);
}

/********************************************//**
 * \brief Transmit DR NMEA message list
 *
 * \param void
 * \return void
 *
 ***********************************************/
static void send_DRMSG_msg(void)
{
  dr_debug_msg_t dr_msg;
  static dr_msg_gps_sample_t dr_msg_gps_sample_copy;
  boolean_t pstmdr_msg_enable = dr_plugin_handler->pstmdr_msg_enable;

  if(FALSE == dr_fix_is_extrapolated())
  {
    /* Read and transmit sensor queues */
    send_DR_analog_MSG_msg();
    send_DR_CAN_MSG_msg();
    send_DR_3Dacc_MSG_msg();
    send_DR_3Dgyro_MSG_msg();
    send_DR_Pres_MSG_msg();

    /* Read and transmit dr process queue */
    while(dr_msg_read(&dr_msg) == TRUE)
    {
      switch (dr_msg.type)
      {
        case DR_MSG_GPS_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_GPS_SAMPLE_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_PSTMDRGPS_msg(&dr_msg.data.sample.gps_sample);
               _clibs_memcpy(&dr_msg_gps_sample_copy, &dr_msg.data.sample.gps_sample, sizeof( dr_msg_gps_sample_t ) );
            }
        break;
        case DR_MSG_SAMPLE_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRSAM_msg(&dr_msg.data.sample.dr_sample);
            }
        break;
        case DR_MSG_STATE_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_STATE_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRSTATE_msg(&dr_msg.data.sample.dr_state);
            }
        break;
        case DR_MSG_DEBUG_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRDEBUG_msg(&dr_msg.data.sample.dr_debug);
            }
        break;
        case DR_MSG_NVM_WRITE_ID:
            if((nmea_msg_list_check(nmea_msg_list,DR_NVM_ACCESS_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DR_NVM_W_msg();
            }
        break;
        case DR_MSG_NVM_READ_ID:
            if((nmea_msg_list_check(nmea_msg_list,DR_NVM_ACCESS_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DR_NVM_R_msg();
            }
        break;
        case DR_MSG_SENSORS_ID:
            /* only print if requested in FW Config */
            if((nmea_msg_list_check(nmea_msg_list,DR_SENSORS_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               sm_lowlatency_sens_SENMSG(&dr_msg.data.sample.dr_sensors_msg);
            }
        break;

        case DR_MSG_KALMAN_INIT_ID:
            if((nmea_msg_list_check(nmea_msg_list,DR_NVM_ACCESS_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DR_KALMAN_INIT_msg();
            }
        break;
        case DR_MSG_COV_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_COVARIANCE_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRCOV_msg(&dr_msg.data.sample.dr_covariance);
            }
        break;
        case DR_MSG_UPDATE_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRUPDATE_msg(&dr_msg.data.sample.dr_update);
            }
        break;
        case DR_MSG_STEP_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRSTEP_msg(&dr_msg.data.sample.dr_step);
            }
        break;
        case DR_MSG_TUNNEL_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRTUNNEL_msg(&dr_msg.data.sample.dr_tunnel);
            }
        break;
        case DR_MSG_SENS_TYPE_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRSTYPE_msg(&dr_msg.data.sample.dr_sensor_type);
            }
        break;
        case DR_MSG_CALIB_FLAGS_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_CALIBRATION_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRCAL_msg(&dr_msg.data.sample.dr_calib);
            }
        break;
        case DR_MSG_AHRS_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_SLOPE_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRAHRS_msg(&dr_msg.data.sample.dr_ahrs);
            }
        break;
        case DR_MSG_MMFB_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_MMFB_msg(&dr_msg.data.sample.dr_mmfb);
            }
        break;
        case DR_MSG_MMFBKF_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_MMFBKF_msg(&dr_msg.data.sample.dr_mmfbkf);
            }
        break;
        case DR_MSG_GNSA_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRGNSA_msg(&dr_msg.data.sample.dr_gnsa);
            }
        break;
        case DR_MSG_DBG_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRDBG_msg(&dr_msg.data.sample.dr_dbg);
            }
        break;
        case DR_MSG_DBG_READ_NVM_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRDBG_read_nvm_msg(&dr_msg.data.sample.dr_dbg_nvm);
            }
        break;
        case DR_MSG_DBG_WRITE_NVM_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRDBG_write_nvm_msg(&dr_msg.data.sample.dr_dbg_nvm);
            }
        break;
        case DR_MSG_DBG_INIT_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRDBG_init_msg(&dr_msg.data.sample.dr_dbg_nvm);
            }
        break;
        case DR_MSG_IMUAA_ID :
            if((nmea_msg_list_check(nmea_msg_list,DR_DEBUG_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
            {
               send_DRIMUAA_msg(&dr_msg.data.sample.dr_imuaa);
            }
        break;
        default :
        break;
      }
    }
  }
  if(TRUE == dr_fix_is_extrapolated())
  {
    if((nmea_msg_list_check(nmea_msg_list,DR_GPS_SAMPLE_NMEA_MSG)  == TRUE) || (TRUE == pstmdr_msg_enable))
    {
      send_PSTMDRGPS_msg(&dr_msg_gps_sample_copy);
    }
  }
}




/********************************************//**
 * \brief Enable/disable $DRPSTM NMEA messages transmission
 *
 * \param enable const boolean_t Switch On/off transmission
 * \return void
 *
 ***********************************************/
static void dr_plugin_enable_dr_msg(const boolean_t enable)
{
  dr_plugin_handler->pstmdr_msg_enable = enable;
}


/********************************************//**
 * \brief execute DR plugin command
 *
 * \param input_cmd_msg tChar* command string
 * \return tInt NMEA_OK Command valid
 *             NMEA_NOT_VALID Command not valid
 ***********************************************/
static tInt dr_plugin_nmea_cmdif_parse( tChar *input_cmd_msg, tUInt cmd_size, tChar *cmd_par)
{
  tUInt cmd_id;

  if( nmea_support_cmdif_getid( input_cmd_msg, cmd_size, dr_nmea_cmd_strings, DR_NMEA_CMDID_NUMBER, &cmd_id) == NMEA_NOT_VALID)
  {
    return NMEA_NOT_VALID;
  }

  dr_nmea_cmdif_exec_table[cmd_id]( cmd_par );
  return NMEA_OK;
}


/********************************************//**
 * \brief Transmit DR plugin output message list
 *
 * \param param void*
 * \return gpOS_error_t gpOS_SUCCESS
 *
 ***********************************************/
static gpOS_error_t dr_plugin_nmea_outmsg_transmit( void *param)
{
  nmea_support_ext_params_t *nmea_params = (nmea_support_ext_params_t *)param;

  nmea_msg_list[0] = nmea_params->msg_list[0];
  nmea_msg_list[1] = nmea_params->msg_list[1];

  send_DRMSG_msg();
  return gpOS_SUCCESS;
}

/********************************************//**
 * \brief Callback to lock DR fix data
 *
 * \param void
 * \return void
 *
 ***********************************************/
static void dr_plugin_fix_data_lock_callback(void)
{
  dr_fix_store();
  dr_fix_read_claim();
}

/********************************************//**
 * \brief Callback to unlock DR fix data
 *
 * \param void
 * \return void
 *
 ***********************************************/
static void dr_plugin_fix_data_unlock_callback(void)
{
  dr_fix_read_release();
}

/********************************************//**
 * \brief Callback to get position and velocity
 *        from DR fix
 *
 * \param extrap_pos position_t*
 * \param course tDouble*
 * \param speed tDouble*
 * \param delay tDouble
 * \param data_p void*
 * \return void
 *
 ***********************************************/
static void dr_plugin_fix_pos_vel_callback(position_t *extrap_pos,
                                           tDouble *course,
                                           tDouble *speed,
                                           tDouble delay,
                                           void *data_p)
{
  dr_position_t dr_pos;
  dr_velocity_t dr_vel;

  dr_pos = dr_fix_get_pos();
  dr_vel = dr_fix_get_speed_heading();

  extrap_pos->latitude = dr_pos.latitude;
  extrap_pos->longitude = dr_pos.longitude;
  extrap_pos->height = dr_pos.height;
  *course = dr_vel.heading;
  *speed = dr_vel.speed;
}

/********************************************//**
 * \brief Callback to get the DR fix status
 *
 * \param void
 * \return tInt DR Fix status
 *
 ***********************************************/
static tInt dr_plugin_fix_pos_status_callback(void)
{
  return(dr_fix_get_fix_status());
}

/********************************************//**
 * \brief Callback to get the DR fix time
 *
 * \param gpOS_clock_t *
 * \return TRUE
 *
 ***********************************************/
static boolean_t dr_plugin_fix_time_callback(gpOS_clock_t *fix_time)
{
  if(TRUE == dr_fix_is_extrapolated())
  {
    *fix_time = dr_fix_get_time();
  }
  else
  {
    *fix_time = (gpOS_clock_t)0;
  }

  return TRUE;
}

/********************************************//**
 * \brief Update sensors message queue (senosor over UART)
 *
 * \param msg tChar* Message string
 * \return void
 *
 ***********************************************/
static void dr_nmea_cmdif_exec_dr_sen_msg(tChar *msg)
{
  tInt field_count = 0;
  tUInt msg_id,time_stamp;
  tUInt gyro_volt = 0;
  tUInt odo_counter = 0;
  tDouble speed = 0;
  tUInt rev_status = 0;
  tUInt dummy_1= 0, dummy_2= 0;
  tUInt front_left_cnt = 0, front_right_cnt = 0;
  tUInt front_left_dir = 0, front_right_dir = 0;
  tUInt rear_left_cnt = 0, rear_right_cnt = 0;
  tUInt rear_left_dir = 0, rear_right_dir = 0;
  tInt xval = 0, yval = 0, zval = 0;
  tInt phi = 0, theta = 0, psi = 0;
  tInt temperature = 0, temperature_validity = 0;
  tUInt pressure = 0;

  field_count =_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u",&msg_id,&time_stamp);

  time_stamp = gpOS_time_now();  //use local cpu time

  if(0 == field_count)
  {
     return;
  }

  switch(msg_id)
  {
         case SM_ODO_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d",&dummy_1,&dummy_2,&odo_counter);
              sm_update_odo(time_stamp,odo_counter);
         break;
         case SM_REV_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d",&dummy_1,&dummy_2,&rev_status);
              sm_update_rev(time_stamp,rev_status);
         break;
         case SM_ODO_REV_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d",&dummy_1,&dummy_2,&odo_counter,&rev_status);
              sm_update_odo_rev(time_stamp,odo_counter,rev_status);
         break;
         case SM_GYRO_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d",&dummy_1,&dummy_2,&gyro_volt);
              sm_update_gyro(time_stamp,gyro_volt);
         break;
         case SM_GYRO_ODO_REV_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d",&dummy_1,&dummy_2,&gyro_volt,&odo_counter,&rev_status);
              sm_update_gyro_odo_rev(time_stamp,gyro_volt,odo_counter,rev_status);
         break;
         case SM_DWP_ODO_MSG_ID:
         break;
         case SM_DWP_2W_F_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d",&dummy_1,&dummy_2,&front_left_cnt,&front_right_cnt);
              sm_update_dwp_2w_front_wheels(time_stamp,front_left_cnt,front_right_cnt);
         break;
         case SM_DWP_2W_F_REV_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d,%d",
                                        &dummy_1,&dummy_2,
                                        &front_left_cnt,&front_right_cnt,
                                        &front_left_dir,&front_right_dir);
              sm_update_dwp_2w_rev_front_wheels(time_stamp,
                                                        front_left_cnt, front_left_dir,
                                                        front_right_cnt,front_right_dir);
         break;
         case SM_DWP_2W_R_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d",&dummy_1,&dummy_2,&rear_left_cnt,&rear_right_cnt);
              sm_update_dwp_2w_rear_wheels(time_stamp,rear_left_cnt,rear_right_cnt);
         break;
         case SM_DWP_2W_R_REV_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d,%d",
                                        &dummy_1,&dummy_2,
                                        &rear_left_cnt,&rear_right_cnt,
                                        &rear_left_dir,&rear_right_dir);
              sm_update_dwp_2w_rev_rear_wheels(time_stamp,
                                                        rear_left_cnt, rear_left_dir,
                                                        rear_right_cnt,rear_right_dir);
         break;
         case SM_DWP_4W_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d,%d",
                                        &dummy_1,&dummy_2,
                                        &front_left_cnt,&front_right_cnt,
                                        &rear_left_cnt,&rear_right_cnt);
              sm_update_dwp_4w(time_stamp,
                                       front_left_cnt, front_right_cnt,
                                       rear_left_cnt, rear_right_cnt);
         break;
         case SM_DWP_4W_REV_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d,%d,%d,%d,%d,%d",
                                        &dummy_1,&dummy_2,
                                        &front_left_cnt,&front_right_cnt,
                                        &rear_left_cnt,&rear_right_cnt,
                                        &front_left_dir,&front_right_dir,
                                        &rear_left_dir,&rear_right_dir);
              sm_update_dwp_4w_rev(time_stamp,
                                           front_left_cnt, front_left_dir,
                                           front_right_cnt, front_right_dir,
                                           rear_left_cnt, rear_left_dir,
                                           rear_right_cnt, rear_right_dir);
         break;
         case SM_IGNITION_DATA_MSG_ID:
         break;
         case SM_SPEED_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%lf",&dummy_1,&dummy_2,&speed);
              sm_update_speed(time_stamp, speed);
         break;
         case SM_DWP_ODO_SPEED_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d",&dummy_1,&dummy_2,&rear_left_cnt,&rear_right_cnt);
              sm_update_dwp_odo_speed(time_stamp,rear_left_cnt,rear_right_cnt);
         break;
         case SM_DWP_2W_F_SPEED_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d",&dummy_1,&dummy_2,&front_left_cnt,&front_right_cnt);
              sm_update_dwp_2w_front_wheels_speed(time_stamp,front_left_cnt,front_right_cnt);
         break;
         case SM_DWP_2W_F_REV_SPEED_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d,%d",
                                        &dummy_1,&dummy_2,
                                        &front_left_cnt,&front_right_cnt,
                                        &front_left_dir,&front_right_dir);
              sm_update_dwp_2w_rev_front_wheels_speed(time_stamp,
                                                              front_left_cnt, front_left_dir,
                                                              front_right_cnt,front_right_dir);
         break;
         case SM_DWP_2W_R_SPEED_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d",&dummy_1,&dummy_2,&rear_left_cnt,&rear_right_cnt);
              sm_update_dwp_2w_rear_wheels_speed(time_stamp,rear_left_cnt,rear_right_cnt);
         break;
         case SM_DWP_2W_R_REV_SPEED_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d,%d",
                                        &dummy_1,&dummy_2,
                                        &rear_left_cnt,&rear_right_cnt,
                                        &rear_left_dir,&rear_right_dir);
              sm_update_dwp_2w_rev_rear_wheels_speed(time_stamp,
                                                             rear_left_cnt, rear_left_dir,
                                                             rear_right_cnt,rear_right_dir);
         break;
         case SM_DWP_4W_SPEED_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d,%d",
                                        &dummy_1,&dummy_2,
                                        &front_left_cnt,&front_right_cnt,
                                        &rear_left_cnt,&rear_right_cnt);
              sm_update_dwp_4w_speed(time_stamp,
                                             front_left_cnt, front_right_cnt,
                                             rear_left_cnt, rear_right_cnt);
         break;
         case SM_DWP_4W_REV_SPEED_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d,%d,%d,%d,%d,%d",
                                        &dummy_1,&dummy_2,
                                        &front_left_cnt,&front_right_cnt,
                                        &rear_left_cnt,&rear_right_cnt,
                                        &front_left_dir,&front_right_dir,
                                        &rear_left_dir,&rear_right_dir);
              sm_update_dwp_4w_rev_speed(time_stamp,
                                                 front_left_cnt, front_left_dir,
                                                 front_right_cnt, front_right_dir,
                                                 rear_left_cnt, rear_left_dir,
                                                 rear_right_cnt, rear_right_dir);
         break;
         case SM_TEMPERATURE_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d",&dummy_1,&dummy_2,&temperature,&temperature_validity);
              sm_update_temperature(time_stamp,temperature,(boolean_t)temperature_validity);
         break;
         case SM_3A_ACC_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d",&dummy_1,&dummy_2,&xval,&yval,&zval);
              sm_update_3axis_acc(time_stamp,xval,yval,zval);
         break;
         case SM_3A_GYRO_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d",&dummy_1,&dummy_2,&xval,&yval,&zval);
              sm_update_3axis_gyro(time_stamp,xval,yval,zval);
         break;
         case SM_MOUNT_ANGLES_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d,%d,%d",&dummy_1,&dummy_2,&phi,&theta,&psi);
              sm_update_installation_angles(time_stamp,phi,theta,psi);
         break;
         case SM_PRES_DATA_MSG_ID:
              field_count=_clibs_sscanf(msg+DR_SENMSG_ID_OFFSET,"%d,%u,%d",&dummy_1,&dummy_2,&pressure);
              sm_update_pres(time_stamp,pressure);
         break;
         default:
         break;
  }
}

/********************************************//**
 * \brief Send map matching data to dr process
 *
 * \param msg tChar* Message string
 * \return void
 *
 ***********************************************/
static void dr_nmea_cmdif_exec_dr_mmfb(tChar *msg)
{
  tInt field_count = 0;
  dr_mmfb_data_t mmfb_data;
  dr_gps_sample_t gnss;

  field_count =_clibs_sscanf(msg,",%lf,%hhd,%hhd,%hhd,%hhd,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf,",
                              &(mmfb_data.utc),
                              &(mmfb_data.lat_valid),
                              &(mmfb_data.lon_valid),
                              &(mmfb_data.height_valid),
                              &(mmfb_data.heading_valid),
                              &(mmfb_data.lat),
                              &(mmfb_data.lon),
                              &(mmfb_data.height),
                              &(mmfb_data.heading),
                              &(mmfb_data.lat_error),
                              &(mmfb_data.lon_error),
                              &(mmfb_data.height_error),
                              &(mmfb_data.heading_error)
                              );

  if(0 == field_count)
  {
    return;
  }

  /* save the current cpu time */
  mmfb_data.cpu_time = gpOS_time_now();
  /* get the last fix data */
  dr_gps_fix_copy_internal( &gnss );
  /* comute the difference between the current cpu time and the gnss last fix data */
  mmfb_data.elapsed_time = gpOS_time_minus(mmfb_data.cpu_time,gnss.cpu_time);

  /* Prepare the msg PSTMDRMMFB */
  dr_set_mmfb_data(&mmfb_data);
}

/********************************************//**
 * \brief Request dr process to enter in gyro only
 *        tilt calculation mode
 *
 * \param msg tChar* Message string
 * \return void
 *
 ***********************************************/
static void dr_nmea_cmdif_exec_dr_calctlt(tChar *msg)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

  // Call api to set
  dr_set_gyro_only_tilt_calc(TRUE);

  index = _clibs_sprintf(out_msg, "$PHDDRCALCTLTOK");
  index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
  index += _clibs_sprintf(&out_msg[index], "\r\n");

  nmea_send_msg_to_uart(out_msg, index);
}

/********************************************//**
 * \brief Request to save the DR status in NVM
 *
 * \param msg tChar* Message string
 * \return void
 *
 ***********************************************/
static void dr_nmea_cmdif_exec_dr_nvmsave(tChar *msg)
{
  tInt index     = 0;
  tChar out_msg[NMEA_OUT_MSG_BUFFER_SIZE];

   // Call api to set
   dr_set_nvmsave_cmd_request(TRUE);

   index = _clibs_sprintf(out_msg, "$PHDDRNVMSAVEOK");
   index += _clibs_sprintf(&out_msg[index], "*%02X", nmea_support_checksum(out_msg));
   index += _clibs_sprintf(&out_msg[index], "\r\n");

   nmea_send_msg_to_uart(out_msg, index);
}

/*****************************************************************************
   function implementations (scope: module-exported)
*****************************************************************************/

gpOS_error_t dr_plugin_api( const gnssapp_plugins_cmd_t cmd, gnssapp_plugins_cmd_param_t *param)
{
  gpOS_error_t error = gpOS_SUCCESS;

  switch( cmd)
  {
    case GNSSAPP_PLUGINS_CMD_INIT:
      error = dr_plugin_init((gpOS_partition_t *)param->data_ptr);
      break;

    case GNSSAPP_PLUGINS_CMD_GETVER:
      *((const tChar **)param->data_ptr) = dr_version();
      break;

    case GNSSAPP_PLUGINS_CMD_START:
      error = dr_plugin_restart();
      break;

    case GNSSAPP_PLUGINS_CMD_SUSPEND:
      error = dr_plugin_suspend();
      WAAS_DEBUG_LEVEL1_MSG(("waas dr_plugin_suspend ok\r\n"));
      break;

    default:
      error = gpOS_FAILURE;
      break;
  }

  return error;
}

/*****************************************************************************
   function implementations (scope: module-exported)
*****************************************************************************/

gnssapp_plugins_handler_t dr_gnssapp_plugin_handler =
{
  NULL,
  GNSSAPP_PLUGINS_ID_DR,
  dr_plugin_api,
  dr_plugin_nmea_cmdif_parse,
  dr_plugin_nmea_outmsg_transmit,
  #if defined( STBIN_LINKED )
  stbin_dr_plugin_cmdif_parse,
  stbin_dr_plugin_outmsg_transmit
  #else
  (gnssapp_plugins_stbin_cmdif_callback_t)NULL,
  (gnssapp_plugins_stbin_outmsg_callback_t)NULL
  #endif
};
#endif  // DR_CODE_LINKED
