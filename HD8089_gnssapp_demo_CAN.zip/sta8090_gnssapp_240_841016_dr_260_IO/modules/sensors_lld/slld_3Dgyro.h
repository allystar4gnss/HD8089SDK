/*!
 * slld_3dgyro.h
 * Defines the interface for 3Dgyro driver.
 * \date 02/01/2017
 */

#ifndef SLLD_3DGYRO_H
#define SLLD_3DGYRO_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "lld_gpio.h"
#include "slld_common.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define SLLD_3D6DGYRO_WHO_AM_I                0x0FU

#define SLLD_TEMP_SHIFT                       8U    // Shift for FP temperature

#define SLLD_3DGYRO_ID                        0xD4U
#define SLLD_3DGYRO_ID_1                      0xD3U   //A3G4250D
#define SLLD_6DGYRO_ID_ASM330LXH              0x61U   //ASM330LXH
#define SLLD_6DGYRO_ID_LSM6DS3                0x69U   //LSM6DS3
#define SLLD_6DGYRO_ID_LSM6DSM                0x6AU   //LSM6DSM
#define SLLD_6DGYRO_ID_LSM6DSR                0x6BU   //LSM6DSR

#define SLLD_3DGYRO_CTRL_REG1                 0x20U
#define SLLD_3DGYRO_NORNAL_MODE_ENABLE        0x08U   /*(1<<3)*/
#define SLLD_3DGYRO_OUT_TEMP_ADDRESS          0x26U
#define SLLD_3DGYRO_OUT_X_L_ADDRESS           0x28U
#define SLLD_3DGYRO_INCREMENT_ADDRESS         0x40U

#define SLLD_3D6DGYRO_READ_OPERATION          0x80U

// A3G4250
#define SLLD_3DGYRO_TEMP_RANGE_OFFSET         128 // Value to be substracted to temperature value to fit the fp conversion macro range

#define SLLD_3DGYRO_SPI_READ_COMMAND_BYTE             (tU8)(SLLD_3DGYRO_OUT_X_L_ADDRESS | SLLD_3D6DGYRO_READ_OPERATION | SLLD_3DGYRO_INCREMENT_ADDRESS)
#define SLLD_3DGYRO_SPI_READ_TEMP_COMMAND_BYTE        (tU8)(SLLD_3DGYRO_OUT_TEMP_ADDRESS | SLLD_3D6DGYRO_READ_OPERATION)
#define SLLD_6DGYRO_SPI_READ_COMMAD_BYTE              (tU8)(SLLD_6DGYRO_OUT_X_G_ADDRESS | SLLD_3D6DGYRO_READ_OPERATION )
#define SLLD_6DGYRO_SPI_READ_TEMP_COMMAND_BYTE        (tU8)(SLLD_6DGYRO_OUT_TEMP_ADDRESS | SLLD_3D6DGYRO_READ_OPERATION )
#define SLLD_6DGYRO_BOSCH_SPI_READ_COMMAND_BYTE       (tU8)(SLLD_COMBO_BMI160_GYR_OUT_X_L_ADDRESS | SLLD_3D6DGYRO_READ_OPERATION )
#define SLLD_6DGYRO_BOSCH_SPI_READ_TEMP_COMMAND_BYTE  (tU8)(SLLD_COMBO_BMI160_TEMP_ADDRESS | SLLD_3D6DGYRO_READ_OPERATION )

#define SLLD_3DGYRO_SLAVE_ADDR                0x68U
#define SLLD_3DGYRO_I2C_AUTO_INC_MASK         0x80U  /* Register address in automatically incremented to allow multiple data r/w */

#define SLLD_3D6DGYRO_SPI_BUS_TYPE            0x00U
#define SLLD_3D6DGYRO_I2C_BUS_TYPE            0x01U

#define SLLD_ST_MEMS_3DGYRO_TYPE              0x00U
#define SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE    0x01U
#define SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE      0x02U
#define SLLD_MEMS_6DGYRO_BMI160_TYPE          0x03U
#define SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE      0x04U
#define SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE      0x05U
#define SLLD_MEMS_6DGYRO_SMI130_TYPE          0x06U


#define SLLD_3D6DGYRO_SPI_ID                  0
#define SLLD_3D6DGYRO_SPI_INT_PRIORITY        10


#define SLLD_3DGYRO_SPI_GPIO_ADDR       (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define SLLD_3DGYRO_SPI_CS_PIN          LLD_GPIO_PIN18
#define SLLD_3DGYRO_SPI_CS_PIN_MODE     LLD_GPIO_MODE_ALTA
#define SLLD_3D6DGYRO_SPI_BUS_FREQUENCY 1000000
#define SLLD_3DGYRO_SCALING_FACTOR      (-0.00009)
#define SLLD_3DGYRO_OFFSET              (1.47)
#define SLLD_3D6DGYRO_CONF_GPIO_MASK    0x3fU
#define SLLD_3D6DGYRO_NOT_CONFIG        ((tU32)0xffffffffU)
#define SLLD_3D6DGYRO_GPIO0_LAST_CH     (32U)
#define SLLD_3D6DGYRO_GPIO1_LAST_CH     (tU32)LLD_GPIOCHUNDEF

//SMI130
#define SLLD_GYRO_ID_SMI130             0x0FU   // SMI130

// Registers address
#define SLLD_SMI130_GYR_RANGE           0x0FU   // GYR Register (RANGE)
#define SLLD_SMI130_GYR_BW              0x10U   // GYE Register (BW)
#define SLLD_SMI130_GYR_HBW             0x13U   // GYR Register (HBW)
#define SLLD_SMI130_GYR_OUT_X_L_ADDRESS 0x02U   // RATE_X_LSB register address

// Registers values
#define SLLD_SMI130_GYR_RANGE_FS_125    0x04U   // FS= 125�/s resolution= 262.4 LSB/�/s
#define SLLD_SMI130_TEMP_SENSOR_SENSITIVITY   2.0    //  Temperature sensitivity = 1/2 K/LSB
#define SLLD_SMI130_GYR_BW_MAX          0x01U   // GYR Max BW = 230 Hz. ODR= 2*BW
#define SLLD_SMI130_GYR_BW_23           0x04U   // GYR Max BW = 23 Hz. ODR= 2*BW
#define SLLD_SMI130_GYR_HBW_FILT        0x00U   // data high bw filetered
#define SLLD_SMI130_GYR_HBW_SHADOW_EN   0x00U   // shadow dis


/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct slld_3Dgyro_msg_tag
{
  gpOS_clock_t  gyro_3D_cpu_time;
  tU16          gyro_3D_x_data;
  tU16          gyro_3D_y_data;
  tU16          gyro_3D_z_data;
  fp_s16_t      gyro_3D_temp;
} slld_3Dgyro_sample_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t slld_3Dgyro_init            ( const tU8 bus_type, const tU8 SA0, const tU8 i2c_SlaveAd_conf, const slld_fifo_info_t);
extern gnss_error_t slld_3Dgyro_CS_init         ( const tU8 bus_type, const tU8 cs_gpio_conf, const tU8 cs_pullup);
extern void         slld_3Dgyro_get_sample        (slld_3Dgyro_sample_t *);
extern boolean_t    slld_get_gyro_Init_Status     (void);

#ifdef __cplusplus
}
#endif

#endif /* DR_3DGYRO_H */
