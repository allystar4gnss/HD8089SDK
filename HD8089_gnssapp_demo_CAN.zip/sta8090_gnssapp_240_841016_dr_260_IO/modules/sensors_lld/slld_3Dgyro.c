/*!
 * slld_3Dgyro.c
 * Implements the basic driver blocks for a 3d gyro or a gyro in a combo.
 * Initialization, get message functions
 * \date 23/01/2017
 */

#include "gpOS.h"
#include "clibs.h"
#include "gnss_bsp_defs.h"

#ifdef __linux__
#include <string.h>
#endif
#include "slld_api.h"
#if defined(__linux__)
gnss_error_t                slld_3Dgyro_init              (const tU8 , const tU8 , const tU8 ,const slld_fifo_info_t );
{
  return GNSS_ERROR;
}
#else
#include "lld_gpio.h"
#include "svc_ssp.h"
#include "svc_i2c.h"
// Use DR_DEBUG for debug message
#undef DR_DEBUG
#include "gnss_debug.h"


svc_ssp_com_handler_t *                 slld_3D6Dgyro_spi_com_hnd;
svc_i2c_com_handler_t *                 slld_3D6Dgyro_i2c_com_hnd;
static boolean_t                        slld_3D6Dgyro_initialized = FALSE;
tU8                                     slld_3D6Dgyro_bus_type = SLLD_3D6DGYRO_SPI_BUS_TYPE;
static tU8                              slld_3D6Dgyro_type = SLLD_ST_MEMS_3DGYRO_TYPE;
static tU32                             slld_3D6Dgyro_cs_gpio_id = SLLD_3D6DGYRO_NOT_CONFIG;

static tU8 slld_3Dgyro_spi_read_command[7] = {(tU8)SLLD_3DGYRO_SPI_READ_COMMAND_BYTE,0,0,0,0,0,0};
static tU8 slld_3Dgyro_spi_read_temp_command[2] = {(tU8)SLLD_3DGYRO_SPI_READ_TEMP_COMMAND_BYTE,0};

static tU8 slld_6Dgyro_st_spi_read_command[7] = {(tU8)SLLD_6DGYRO_SPI_READ_COMMAD_BYTE,0,0,0,0,0,0};
static tU8 slld_6Dgyro_st_spi_read_temp_command[3] = {(tU8)SLLD_6DGYRO_SPI_READ_TEMP_COMMAND_BYTE,0,0};

static tU8 slld_6Dgyro_bosch_spi_read_command[7] = {(tU8)SLLD_6DGYRO_BOSCH_SPI_READ_COMMAND_BYTE,0,0,0,0,0,0};
static tU8 slld_6Dgyro_bosch_spi_read_temp_command[3] = {(tU8)SLLD_6DGYRO_BOSCH_SPI_READ_TEMP_COMMAND_BYTE,0,0};

static tU8 *slld_6Dgyro_spi_read_command = (tU8*)slld_6Dgyro_st_spi_read_command;
static tU8 *slld_6Dgyro_spi_read_temp_command = (tU8*)slld_6Dgyro_st_spi_read_temp_command;

/* Prototypes */
gnss_error_t                slld_3Dgyro_setup             (const slld_fifo_info_t);
gnss_error_t                slld_3Dgyro_init_CtrlReg_i2c  (const slld_fifo_info_t);
gnss_error_t                slld_3Dgyro_init_CtrlReg_spi  (const slld_fifo_info_t);
void                        slld_3Dgyro_spi_cs_disable    (void *);
void                        slld_3Dgyro_spi_cs_enable     (void *);


void slld_3Dgyro_get_sample(slld_3Dgyro_sample_t *sample)
{
  tS16 local_temp;

  if(SLLD_3D6DGYRO_SPI_BUS_TYPE == slld_3D6Dgyro_bus_type)
  {
    tU8 *in_buf_xyz_ptr;
    //Read 8bits or 16 bits temp sensor
    tU8 in_buf_temp_ptr[3];

    //Read x,y,z sensor
    in_buf_xyz_ptr = (tU8 *)((tUInt)&sample->gyro_3D_x_data - 1) ;

    switch (slld_3D6Dgyro_type)
    {
      case SLLD_ST_MEMS_3DGYRO_TYPE:
      {
        // Read the gyro x,y,z data
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3Dgyro_spi_read_command,7,in_buf_xyz_ptr,NULL) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI read x,y,z error!\r\n"));
        }

        // Read the temperature data
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3Dgyro_spi_read_temp_command,2,in_buf_temp_ptr,NULL) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI read temp error!\r\n"));
        }
        //DR_DEBUG_MSG(("[slld_3Dgyro] temp[1]=0x%x \r\n",in_buf_temp_ptr[1]));

        local_temp = (tS16)in_buf_temp_ptr[1] - SLLD_3DGYRO_TEMP_RANGE_OFFSET;
        //DR_DEBUG_MSG(("[dr_3Dgyro] temp :0x%x \r\n",local_temp));
        sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM(((tDouble)local_temp),SLLD_TEMP_SHIFT);

      }
      break;

      case SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE:
      case SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE:
      case SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE:
      case SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE:
      case SLLD_MEMS_6DGYRO_BMI160_TYPE:
      {
        // Read the gyro x,y,z data
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_6Dgyro_spi_read_command,7,in_buf_xyz_ptr,NULL) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI read x,y,z error!\r\n"));
        }

        // Read the temperature data
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_6Dgyro_spi_read_temp_command,3,in_buf_temp_ptr,NULL) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI read temp error!\r\n"));
        }

        local_temp = ((tS16)(in_buf_temp_ptr[2]<<8U)) +in_buf_temp_ptr[1];

        switch (slld_3D6Dgyro_type)
        {
          case SLLD_MEMS_6DGYRO_BMI160_TYPE:
          {
            sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM(((((tDouble)local_temp)/ SLLD_COMBO_BMI160_TEMP_SENSOR_SENSITIVITY) + SLLD_COMBO_TEMP_CONST),SLLD_TEMP_SHIFT);
            //DR_DEBUG_MSG(("[dr_3Dgyro] temp:%u temp after sensitivity factor:%f \r\n",local_temp,((((tDouble)local_temp)/ DR_COMBO_BMI160_TEMP_SENSOR_SENSITIVITY) + DR_COMBO_TEMP_CONST)));
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE:
          case SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE:
          {
            sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM((((tDouble)local_temp)/ SLLD_6DGYRO_TEMP_SENSOR_SENSITIVITY),SLLD_TEMP_SHIFT);
            //DR_DEBUG_MSG(("[dr_3Dgyro] temp after sensitivity factor:%f fix point value:%d\r\n",(((tDouble)local_temp)/ DR_6DGYRO_TEMP_SENSOR_SENSITIVITY),sample->gyro_3D_temp));
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE:
          case SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE:
          {
            sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM((((tDouble)local_temp)/ SLLD_6DGYRO_TEMP_SENSOR_SENS_256),SLLD_TEMP_SHIFT);
            //DR_DEBUG_MSG(("[dr_3Dgyro] temp after sensitivity factor:%f fix point value:%d\r\n",(((tDouble)local_temp)/ DR_6DGYRO_TEMP_SENSOR_SENSITIVITY),sample->gyro_3D_temp));
          }
          break;

          default:
          // else unknown sensor type
          break;
        }

      }
      break;

      default:
      // else unknown sensor type
      break;
    }
  }
  else
  {
    gpOS_clock_t timeout;
    tU8 slld_3Dgyro_i2c_data[8]={0,0,0,0,0,0,0,0};

    switch (slld_3D6Dgyro_type)
    {
      case SLLD_ST_MEMS_3DGYRO_TYPE:
      {
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_3DGYRO_OUT_TEMP_ADDRESS|SLLD_3DGYRO_I2C_AUTO_INC_MASK, 1, slld_3Dgyro_i2c_data, 8, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read error!\r\n"));
        }
        local_temp   = ((tS16)slld_3Dgyro_i2c_data[0])- SLLD_3DGYRO_TEMP_RANGE_OFFSET; /* data[1] contains Status reg (not used) */
        DR_DEBUG_MSG(("[slld_3Dgyro] temp :%d \r\n",local_temp));
        sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM(((tDouble)local_temp),SLLD_TEMP_SHIFT);

        sample->gyro_3D_x_data = ((tU16)slld_3Dgyro_i2c_data[3]<<8)+ slld_3Dgyro_i2c_data[2];
        sample->gyro_3D_y_data = ((tU16)slld_3Dgyro_i2c_data[5]<<8)+ slld_3Dgyro_i2c_data[4];
        sample->gyro_3D_z_data = ((tU16)slld_3Dgyro_i2c_data[7]<<8)+ slld_3Dgyro_i2c_data[6];
      }
      break;

      case SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE:
      case SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE:
      case SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE:
      case SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE:
      {
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_6DGYRO_OUT_TEMP_ADDRESS, 1, slld_3Dgyro_i2c_data, 8, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read Gyro Data error!\r\n"));
        }

        local_temp = ((tS16)slld_3Dgyro_i2c_data[1]<<8U)+ slld_3Dgyro_i2c_data[0];

        switch (slld_3D6Dgyro_type)
        {
          case SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE:
          case SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE:
          {
            sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM((((tDouble)local_temp)/ SLLD_6DGYRO_TEMP_SENSOR_SENS_256),SLLD_TEMP_SHIFT);
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE:
          case SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE:
          {
            sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM((((tDouble)local_temp)/ SLLD_6DGYRO_TEMP_SENSOR_SENSITIVITY),SLLD_TEMP_SHIFT);
          }
          break;

          default:
          // else unknown sensor type
          break;
        }

        //DR_DEBUG_MSG(("[dr_3Dgyro] temp after sensitivity factor:%f fix point value:%d\r\n",(((tDouble)local_temp)/ DR_6DGYRO_TEMP_SENSOR_SENSITIVITY),sample->gyro_3D_temp));

        sample->gyro_3D_x_data = ((tU16)slld_3Dgyro_i2c_data[3]<<8U)+ slld_3Dgyro_i2c_data[2];
        sample->gyro_3D_y_data = ((tU16)slld_3Dgyro_i2c_data[5]<<8U)+ slld_3Dgyro_i2c_data[4];
        sample->gyro_3D_z_data = ((tU16)slld_3Dgyro_i2c_data[7]<<8U)+ slld_3Dgyro_i2c_data[6];
      }
      break;

      case SLLD_MEMS_6DGYRO_BMI160_TYPE:
      {
        tU8 slld_Temp[2] = {0,0};

        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_BMI160_GYR_OUT_X_L_ADDRESS, 1, slld_3Dgyro_i2c_data, 6, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read Gyro Data error!\r\n"));
        }

        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_BMI160_TEMP_ADDRESS, 1, slld_Temp, 2, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read Temperature error!\r\n"));
        }

        local_temp = ((tS16)slld_Temp[1]<<8)+ slld_Temp[0];
        sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM(((((tDouble)local_temp)/ SLLD_COMBO_BMI160_TEMP_SENSOR_SENSITIVITY) + SLLD_COMBO_TEMP_CONST),SLLD_TEMP_SHIFT);
        //DR_DEBUG_MSG(("[slld_3Dgyro] temp=0x%x temp after sensitivity factor:%f \r\n",local_temp,((((tDouble)local_temp)/ SLLD_6DGYRO_TEMP_SENSOR_SENSITIVITY) + SLLD_COMBO_TEMP_CONST)));

        sample->gyro_3D_x_data = ((tU16)slld_3Dgyro_i2c_data[1]<<8U)+ slld_3Dgyro_i2c_data[0];
        sample->gyro_3D_y_data = ((tU16)slld_3Dgyro_i2c_data[3]<<8U)+ slld_3Dgyro_i2c_data[2];
        sample->gyro_3D_z_data = ((tU16)slld_3Dgyro_i2c_data[5]<<8U)+ slld_3Dgyro_i2c_data[4];
      }
      break;

      case SLLD_MEMS_6DGYRO_SMI130_TYPE:
      {
        tS8 temp;

        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_SMI130_GYR_OUT_X_L_ADDRESS, 1, slld_3Dgyro_i2c_data, 7, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read Gyro Data error!\r\n"));
        }

        temp   = ((tS8)slld_3Dgyro_i2c_data[6]);

        sample->gyro_3D_temp = MCR_DOUBLE_TO_FP16_QM((((tDouble)temp)/ SLLD_SMI130_TEMP_SENSOR_SENSITIVITY) ,SLLD_TEMP_SHIFT);
        //DR_DEBUG_MSG(("[slld_3Dgyro] temp=%d temp after sensitivity factor:%f \r\n",temp, (((tDouble)temp)/ SLLD_SMI130_TEMP_SENSOR_SENSITIVITY) ));

        sample->gyro_3D_x_data = ((tU16)slld_3Dgyro_i2c_data[1]<<8)+ slld_3Dgyro_i2c_data[0];
        sample->gyro_3D_y_data = ((tU16)slld_3Dgyro_i2c_data[3]<<8)+ slld_3Dgyro_i2c_data[2];
        sample->gyro_3D_z_data = ((tU16)slld_3Dgyro_i2c_data[5]<<8)+ slld_3Dgyro_i2c_data[4];

        DR_DEBUG_MSG(("[slld_3Dgyro] get sample SM130 x=%x y=%0x z=%0x\r\n",
            sample->gyro_3D_x_data, sample->gyro_3D_y_data, sample->gyro_3D_z_data));
      }
      break;

      default:
      // Unknown sensor
      break;
    }

  }
  //DR_DEBUG_MSG(("[slld_3Dgyro] sample->gyro_3D_x_data:0x%x sample->gyro_3D_y_data:0x%x sample->gyro_3D_z_data:0x%x\r\n",sample->gyro_3D_x_data,sample->gyro_3D_y_data,sample->gyro_3D_z_data));
  sample->gyro_3D_cpu_time = gpOS_time_now();
}

gnss_error_t slld_3Dgyro_init_CtrlReg_spi(const slld_fifo_info_t slld_fifo_info)
{
  tU8 slld_3D6Dgyro_spi_command[3];
  tU8 slld_3D6Dgyro_spi_command_response[7];
  tU8 i;

  switch (slld_3D6Dgyro_type)
  {
    // 3D Gyro ST Mems
    case SLLD_ST_MEMS_3DGYRO_TYPE:
      {
        // Read the CTRL_REG1 register
        slld_3D6Dgyro_spi_command[0] = (tU8) ( SLLD_3D6DGYRO_READ_OPERATION | SLLD_3DGYRO_CTRL_REG1 );
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_3DGYRO_CTRL_REG1 error!\r\n"));
        }

        // Write in the CTRL_REG1 register
        slld_3D6Dgyro_spi_command[0] = SLLD_3DGYRO_CTRL_REG1;
        slld_3D6Dgyro_spi_command[1] = slld_3D6Dgyro_spi_command_response[1] | SLLD_3DGYRO_NORNAL_MODE_ENABLE;
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_3DGYRO_CTRL_REG1 error!\r\n"));
        }
      }
      break;

    // 6D Gyro ST Mems
    case SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE:
    case SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE:
    case SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE:
    case SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE:
     {
        switch (slld_3D6Dgyro_type)
        {
          case SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE:
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330XLH recognized SPI mode \r\n"));
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE:
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] LSM6DS3 recognized SPI mode \r\n"));
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE:
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] LSM6DSM recognized SPI mode \r\n"));
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE:
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR recognized SPI mode \r\n"));
          }
          break;

          default:
          // Unknown sensor
          break;
        }

        // ASM330LHX ZRL built in temperature compensation turn off procedure start
        if(slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE)
        {
          tU8 Addr00RegisterValue;
          tU8 Addr45RegisterValue;
          tU8 Addr46RegisterValue;
          tU8 Addr47RegisterValue;

          // Start sequence
          Addr00RegisterValue = (tU8)0x01;
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_ASM330LXH_REG00;
          slld_3D6Dgyro_spi_command[1] = Addr00RegisterValue;
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_6DGYRO_ADDR_00 error!\r\n"));
            return GNSS_ERROR;
          }

          // Read registers
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_ASM330LXH_REG00);
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_6DGYRO_ADDR_00 error!\r\n"));
            return GNSS_ERROR;
          }
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_ASM330LXH_REG45);
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_6DGYRO_ADDR_45 error!\r\n"));
            return GNSS_ERROR;
          }
          else
          {
            Addr45RegisterValue = slld_3D6Dgyro_spi_command_response[1];
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 45h (TC ON): 0x%x\r\n", Addr45RegisterValue));
          }
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_ASM330LXH_REG46);
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_6DGYRO_ADDR_46 error!\r\n"));
            return GNSS_ERROR;
          }
          else
          {
            Addr46RegisterValue = slld_3D6Dgyro_spi_command_response[1];
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 46h (TC ON): 0x%x\r\n", Addr46RegisterValue));
          }
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_ASM330LXH_REG47);
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_6DGYRO_ADDR_47 error!\r\n"));
            return GNSS_ERROR;
          }
          else
          {
            Addr47RegisterValue = slld_3D6Dgyro_spi_command_response[1];
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 47h (TC ON): 0x%x\r\n", Addr47RegisterValue));
          }

          // Write registers
          Addr45RegisterValue &= (tU8)0x81;
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_ASM330LXH_REG45;
          slld_3D6Dgyro_spi_command[1] = Addr45RegisterValue;
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_6DGYRO_ADDR_45 error!\r\n"));
            return GNSS_ERROR;
          }
          Addr46RegisterValue &= (tU8)0x81;
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_ASM330LXH_REG46;
          slld_3D6Dgyro_spi_command[1] = Addr46RegisterValue;
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_6DGYRO_ADDR_46 error!\r\n"));
            return GNSS_ERROR;
          }
          Addr47RegisterValue &= (tU8)0x81;
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_ASM330LXH_REG47;
          slld_3D6Dgyro_spi_command[1] = Addr47RegisterValue;
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_6DGYRO_ADDR_47 error!\r\n"));
            return GNSS_ERROR;
          }

          // Re read registers
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_ASM330LXH_REG45);
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_6DGYRO_ADDR_45 error!\r\n"));
            return GNSS_ERROR;
          }
          else
          {
            Addr45RegisterValue = slld_3D6Dgyro_spi_command_response[1];
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 45h (TC OFF): 0x%x\r\n", Addr45RegisterValue));
          }
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_ASM330LXH_REG46);
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_6DGYRO_ADDR_46 error!\r\n"));
            return GNSS_ERROR;
          }
          else
          {
            Addr46RegisterValue = slld_3D6Dgyro_spi_command_response[1];
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 46h (TC OFF): 0x%x\r\n", Addr46RegisterValue));
          }
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_ASM330LXH_REG47);
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_6DGYRO_ADDR_47 error!\r\n"));
            return GNSS_ERROR;
          }
          else
          {
            Addr47RegisterValue = slld_3D6Dgyro_spi_command_response[1];
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 47h (TC OFF): 0x%x\r\n", Addr47RegisterValue));
          }

          Addr00RegisterValue = (tU8)0x00;
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_ASM330LXH_REG00;
          slld_3D6Dgyro_spi_command[1] = Addr00RegisterValue;
          if(svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_6DGYRO_ADDR_00 error!\r\n"));
            return GNSS_ERROR;
          }
        } // ASM330LHX ZRL built in temperature compensation turn off procedure end

        // Read the current CTRL2_G register
        slld_3D6Dgyro_spi_command[0] = (tU8) ( SLLD_3D6DGYRO_READ_OPERATION | SLLD_6DGYRO_CTRL2_G );
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI read DR_6DGYRO_CTRL2_G error!\r\n"));
        }

        // Write in the CTRL2_G register ODR_50Hz shall be the same for 3dGyro and Acc!
        slld_3D6Dgyro_spi_command[0] = SLLD_6DGYRO_CTRL2_G;
        if (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE)
        {
          slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command_response[1] & ~SLLD_COMBO_ASM330LXH_ODR_MASK & ~SLLD_6DGYRO_ASM330LXH_FS_MASK) | SLLD_COMBO_ASM330LXH_ODR_50Hz| SLLD_6DGYRO_ASM330LXH_FS_125;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_6DGYRO_CTRL2_G error!\r\n"));
          }
        }
        else
          /* SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE*/
          /* SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE*/
          /* SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE*/
         {
            // If Acc ODR has been set, use the same for the Gyro
            if  (slld_fifo_info.slld_3Dacc_FiFoModeEn == TRUE)
            {
              slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command_response[1] & ~SLLD_COMBO_LSM6DS3_ODR_MASK & ~SLLD_6DGYRO_LSM6DS3_FS_MASK)  | SLLD_6DGYRO_LSM6DS3_FS_125 | ( (tU8)slld_fifo_info.odr_val.odr_fifo_LSM6DS3 << 4U);
            }
            else
            {
              slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command_response[1] & ~SLLD_COMBO_LSM6DS3_ODR_MASK & ~SLLD_6DGYRO_LSM6DS3_FS_MASK) | SLLD_COMBO_LSM6DS3_ODR_52Hz | SLLD_6DGYRO_LSM6DS3_FS_125;
            }

            if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_6DGYRO_CTRL2_G error!\r\n"));
            }
          }

        if ( (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE)  ||
             (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE) )
        {
          // Read CTRL10_C register
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_6DGYRO_CTRL10_C);
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_6DGYRO_CTRL10_C error!\r\n"));
          }

          // Write in the CTRL10_C register
          slld_3D6Dgyro_spi_command[0] = SLLD_6DGYRO_CTRL10_C;
          slld_3D6Dgyro_spi_command[1] = slld_3D6Dgyro_spi_command_response[1] | SLLD_6DGYRO_G_XYZ_ENABLED;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_6DGYRO_CTRL10_C error!\r\n"));
          }
        }

        // Read FIFO_CTRL register
        if  (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE)
        {
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_ASM330LXH_FIFO_CTRL);
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_COMBO_ASM330LXH_FIFO_CTRL error!\r\n"));
          }

          // Write in the FIFO_CTRL register
          // Configure the Bypass mode
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_ASM330LXH_FIFO_CTRL;
          slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command_response[1] & ~SLLD_COMBO_ASM330LXH_FIFO_MODE_MASK) ;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
             DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_COMBO_ASM330LXH_FIFO_CTRL error!\r\n"));
          }
        }
        else
          /* SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE*/
          /* SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE*/
          if ( ( slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE) ||
               ( slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE ))
          {
            // If FIFO mode has been set for acc data don't change FIFO_CTRL5 and CTRL4_C register
            // Fifo mode for Gyro not yet supported
            if (slld_fifo_info.slld_3Dacc_FiFoModeEn == FALSE)
            {
              // Read the FIFO_CTRL5 register
              slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_LSM6DS3_FIFO_CTRL5);
              if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_COMBO_LSM6DS3_FIFO_CTRL5 error!\r\n"));
              }

              // Write in the FIFO_CTRL5 register
              // Configure the Bypass mode
              slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_LSM6DS3_FIFO_CTRL5;
              slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command_response[1] & ~SLLD_COMBO_LSM6DS3_BYPASS_MODE_MASK) ;
              if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_COMBO_LSM6DS3_FIFO_CTRL5 error!\r\n"));
              }

              if  (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE)
              {
                // Read the current CTRL4_C register
                slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_CTRL4_C);
                if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
                {
                  DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_COMBO_CTRL4_C error!\r\n"));
                }

                // Write in the CTRL4_C register
                // Configure BW_ODR_SCAL to 0; the BW depends on the ODR value
                slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_CTRL4_C;
                slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command[1]& ~SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR) | SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR;
                if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
                {
                  DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_COMBO_CTRL4_C error!\r\n"));
                }
              }
            }
          }
          else
          {
            // No FIFO mode for DR_ST_MEMS_6DGYRO_LSM6DSR_TYPE
          }

        // Read the current CTRL3_C register
        slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_CTRL3_C);
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_COMBO_CTRL3_C error!\r\n"));
        }

        // Write in the CTRL3_C register
        slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_CTRL3_C;
        // Configure the Multi Access; only when more than 8bits are programmed in read/write mode
        slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command_response[1] & ~SLLD_COMBO_IF_ADD_INC & ~SLLD_COMBO_BDU_MASK) | SLLD_COMBO_IF_ADD_INC | SLLD_COMBO_BDU_MASK;
        if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL)  == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_COMBO_CTRL3_C error!\r\n"));
        }

        if(slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE)
        {
          // Read Dump register for LSM6DSR
          tU8 DumpValue[0x53U];

#ifdef TEST_LSM6DSR
         // Write 0x00 in the DR_LSM6DSR_BASIC_REG
          slld_3D6Dgyro_spi_command[0] = DR_LSM6DSR_BASIC_REG;
          slld_3D6Dgyro_spi_command[1] = 0x00;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write DR_LSM6DSR_BASIC_REG error!\r\n"));
          }

          // Reset registers to their default values
          // Read the current 12h register
          slld_3D6Dgyro_spi_command[0] = (tU8)(DR_3D6DGYRO_READ_OPERATION | 0x12U);
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read DR_COMBO_CTRL3_C error!\r\n"));
          }

          // Write '1' in bit 12h<7> register
          slld_3D6Dgyro_spi_command[0] = 0x12U;
          slld_3D6Dgyro_spi_command[1] = (tU8)(slld_3D6Dgyro_spi_command_response[1] | 0x80U) ;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write 12h register error!\r\n"));
          }
 #endif /* TEST_LSM6DSR */

          // Write in the DR_LSM6DSR_BASIC_REG
          slld_3D6Dgyro_spi_command[0] = SLLD_LSM6DSR_BASIC_REG;
          slld_3D6Dgyro_spi_command[1] = SLLD_LSM6DSR_DUMP_MODE;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write DR_LSM6DSR_BASIC_REG error!\r\n"));
          }
          // Read registers from 0x2e to 0x7f
          slld_3D6Dgyro_spi_command[0] = (tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_LSM6DSR_DUMP_REG);
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,0x53U,DumpValue,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read DR_LSM6DSR_DUMP_REG error!\r\n"));
          }

          DR_DEBUG_MSG(("[slld_3Dgyro] contents of registers 0x2E to 0x7F (hex format):\r\n"));

          for ( i=0x00U; i<=0x51U; i++)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register %x: %x\r\n ",0x2EU+i,DumpValue[i+1]));
          }

#ifdef TEST_LSM6DSR
          // Turn Off temperature compensation
          // Write 0x00 in the 4Eh and 4Fh registers
          slld_3D6Dgyro_spi_command[0] = 0x4EU;
          slld_3D6Dgyro_spi_command[1] = 0x00U;
          slld_3D6Dgyro_spi_command[2] = 0x00U;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,3,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write 4Eh and 4Fh registers error!\r\n"));
          }

          // Read the 4Eh and 4Fh registers
          slld_3D6Dgyro_spi_command[0] = DR_3D6DGYRO_READ_OPERATION | 0x4EU;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_command,dr_3D6Dgyro_spi_command,3,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read 4Eh or 4Fh error!\r\n"));
          }
          else
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 4Eh : %x\r\n ",slld_3D6Dgyro_spi_command_response[1]));
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 4Fh : %x\r\n ",slld_3D6Dgyro_spi_command_response[2]));
         }

          // Write 0x00 in the 56h registers
          slld_3D6Dgyro_spi_command[0] = 0x56U;
          slld_3D6Dgyro_spi_command[1] = 0x00U;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write 4Fh register error!\r\n"));
          }

          // Read the 56h register
          slld_3D6Dgyro_spi_command[0] = DR_3D6DGYRO_READ_OPERATION | 0x56U;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read 56h register error!\r\n"));
          }
          else
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 56h : %x\r\n ",slld_3D6Dgyro_spi_command_response[1]));
          }

          // Write 0x80 in the 71h registers, 0x00 in 72h and 73h
          slld_3D6Dgyro_spi_command[0] = 0x71U;
          slld_3D6Dgyro_spi_command[1] = 0x80U;
          slld_3D6Dgyro_spi_command[2] = 0x00U;
          slld_3D6Dgyro_spi_command[3] = 0x00U;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,4,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write 71h 72h and 73h registers error!\r\n"));
          }

        // Read the 71h 72h and 73hh registers
          slld_3D6Dgyro_spi_command[0] = DR_3D6DGYRO_READ_OPERATION | 0x71U;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,4,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read 71h, 72h or 73h error!\r\n"));
          }
          else
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 71h : %x\r\n ",slld_3D6Dgyro_spi_command_response[1]));
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 72h : %x\r\n ",slld_3D6Dgyro_spi_command_response[2]));
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 73h : %x\r\n ",slld_3D6Dgyro_spi_command_response[3]));
        }

          // Write 0x00 in the 7Dh 7Eh and 7Fh registers
          slld_3D6Dgyro_spi_command[0] = 0x7DU;
          slld_3D6Dgyro_spi_command[1] = 0x00U;
          slld_3D6Dgyro_spi_command[2] = 0x00U;
          slld_3D6Dgyro_spi_command[3] = 0x00U;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,4,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write 7Dh 7Eh and 7Fh registers error!\r\n"));
          }

          // Read the 7Dh 7Eh and 7Fh registers
          slld_3D6Dgyro_spi_command[0] = DR_3D6DGYRO_READ_OPERATION | 0x7DU;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,4,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read 7Dh, 7Eh or 7Fh registers error!\r\n"));
          }
          else
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 7Dh : %x\r\n ",slld_3D6Dgyro_spi_command_response[1]));
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 7Eh : %x\r\n ",slld_3D6Dgyro_spi_command_response[2]));
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register 7Fh : %x\r\n ",slld_3D6Dgyro_spi_command_response[3]));
          }

          // Write 0x00 in the DR_LSM6DSR_BASIC_REG
          slld_3D6Dgyro_spi_command[0] = DR_LSM6DSR_BASIC_REG;
          slld_3D6Dgyro_spi_command[1] = 0x00;
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write DR_LSM6DSR_BASIC_REG error!\r\n"));
          }
#endif /*TEST_LSM6DSR*/
        }

      }
      break;

      case SLLD_MEMS_6DGYRO_BMI160_TYPE:
        {
          GPS_DEBUG_MSG(("[slld_3Dgyro] BMI160 recognized SPI mode \r\n"));

          // Write in SLLD_COMBO_BMI160_CMD_REGISTER register
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_BMI160_CMD_REGISTER;
          // Configure the Normal mode for Gyro
          slld_3D6Dgyro_spi_command[1] = SLLD_COMBO_BMI160_GYR_SET_PMU_NORMAL_MODE;
          if (svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_COMBO_BMI160_CMD_REGISTER error!\r\n"));
          }

          // Read the Ctrl registers for Gyro
          slld_3D6Dgyro_spi_command[0] = (tU8) ( SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_BMI160_GYR_CONF );
          if (svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,3,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_COMBO_BMI160_GYR_CONF error!\r\n"));
            return GNSS_ERROR;
          }

          // Set GYR_CNF register
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_BMI160_GYR_CONF;
          slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command_response[1] & SLLD_COMBO_BMI160_GYR_CONF_RES) | SLLD_COMBO_BMI160_GYR_BWP_NORMAL | SLLD_COMBO_BMI160_GYR_ODR_50Hz;
          // Set GYR_RANGE register
          slld_3D6Dgyro_spi_command[2] = (slld_3D6Dgyro_spi_command_response[2] & SLLD_COMBO_BMI160_GYR_RANGE_RES ) | SLLD_COMBO_BMI160_GYR_RANGE_FS_125 ;
          // Write in the SLLD_6GDGYRO_BMI160_GYR_CONF/SLLD_6GDGYRO_BMI160_GYR_RANGE registers
          if (svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,3,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_COMBO_BMI160_GYR_CONF error!\r\n"));
          }

          // Read the FIFO_CONFIG_1 registers
          slld_3D6Dgyro_spi_command[0] = (tU8) ( SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_BMI160_FIFO_CONFIG1 );
          if (svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI read SLLD_COMBO_BMI160_FIFO_CONFIG1 error!\r\n"));
          }

          // Set FIFO_CONFIG_1 register
          slld_3D6Dgyro_spi_command[0] = SLLD_COMBO_BMI160_FIFO_CONFIG1;
          slld_3D6Dgyro_spi_command[1] = (slld_3D6Dgyro_spi_command_response[1] & SLLD_COMBO_BMI160_FIFO1_RES ) | SLLD_COMBO_BMI160_NO_FIFO ;
          // Write in the DR_COMBO_BMI160_FIFO_CONFIG1 register
          if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] SPI write SLLD_COMBO_BMI160_FIFO_CONFIG1 error!\r\n"));
          }
        }
        break;

      // unknown ytpe
      default:
        {
          //Impossible case
        }
        break;
  }
  return GNSS_NO_ERROR;
}

gnss_error_t slld_3Dgyro_init_CtrlReg_i2c(const slld_fifo_info_t slld_fifo_info)
{
  gpOS_clock_t timeout;
  gnss_error_t return_error = GNSS_NO_ERROR;

  switch (slld_3D6Dgyro_type)
  {
    // 3D Gyro ST Mems
    case SLLD_ST_MEMS_3DGYRO_TYPE:
    {
      tU8 slld_3D6Dgyro_i2c_command_response;

      // Read the CTRL_REG1 register
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_3DGYRO_CTRL_REG1, 1, &slld_3D6Dgyro_i2c_command_response, 1, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dgyro] I2c read error!\r\n"));
        return_error = GNSS_ERROR;
      }

      // Write in the CTRL_REG1 register
      slld_3D6Dgyro_i2c_command_response|= SLLD_3DGYRO_NORNAL_MODE_ENABLE;
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_3DGYRO_CTRL_REG1, 1, &slld_3D6Dgyro_i2c_command_response, 1, 1,&timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dgyro] I2c write error!\r\n"));
        return_error = GNSS_ERROR;
      }
    }
    break;

    // 6D Gyro ST Mems
    case SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE:
    case SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE:
    case SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE:
    case SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE:
      {
        tU8 Ctrl3RegisterValue;
        tU8 CtrlRegisterValue[10];
        tU8 Ctrl2GRegisterValue;
        tU8 CtrlFifoRegisterValue;
        tU8 Ctrl10CRegisterValue;
        tU8 Ctrl4CRegisterValue;

        switch (slld_3D6Dgyro_type)
        {
          case SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE:
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330XLH recognized I2c mode \r\n"));
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE:
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] LSM6DS3 recognized I2c mode \r\n"));
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE:
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] LSM6DSM recognized I2c mode \r\n"));
          }
          break;

          case SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE:
          {
            GPS_DEBUG_MSG(("[dr_3Dgyro] LSM6DSR recognized I2c mode \r\n"));
          }
          break;

          default:
          // Unknown sensor
          break;

        }

        // ASM330LHX ZRL built in temperature compensation turn off procedure start
        if(slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE)
        {
          tU8 Addr00RegisterValue;
          tU8 Addr45RegisterValue;
          tU8 Addr46RegisterValue;
          tU8 Addr47RegisterValue;


          // Start sequence
          Addr00RegisterValue = (tU8)0x01;
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG00, 1, &Addr00RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write DR_6DGYRO_ADDR_00 error!\r\n"));
            return_error = GNSS_ERROR;
          }

          // Read registers
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG00, 1, &Addr00RegisterValue, 1, &timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[dr_3Dgyro] I2c read DR_6DGYRO_ADDR_00 error!\r\n"));
            return_error = GNSS_ERROR;
          }
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG45, 1, &Addr45RegisterValue, 1, &timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_6DGYRO_ADDR_45 error!\r\n"));
            return_error = GNSS_ERROR;
          }
          else
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 45h (TC ON): 0x%x\r\n", Addr45RegisterValue));
          }
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG46, 1, &Addr46RegisterValue, 1, &timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_6DGYRO_ADDR_46 error!\r\n"));
            return_error = GNSS_ERROR;
          }
          else
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 46h (TC ON): 0x%x\r\n", Addr46RegisterValue));
          }
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG47, 1, &Addr47RegisterValue, 1, &timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_6DGYRO_ADDR_47 error!\r\n"));
            return_error = GNSS_ERROR;
          }
          else
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 47h (TC ON): 0x%x\r\n", Addr47RegisterValue));
          }

          // Write registers
          Addr45RegisterValue &= (tU8)0x81;
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG45, 1, &Addr45RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_6DGYRO_ADDR_45 error!\r\n"));
            return_error = GNSS_ERROR;
          }

          Addr46RegisterValue &= (tU8)0x81;
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG46, 1, &Addr46RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_6DGYRO_ADDR_46 error!\r\n"));
            return_error = GNSS_ERROR;
          }
          Addr47RegisterValue &= (tU8)0x81;
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG47, 1, &Addr47RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_6DGYRO_ADDR_47 error!\r\n"));
            return_error = GNSS_ERROR;
          }

          // Re read registers
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG45, 1, &Addr45RegisterValue, 1, &timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_6DGYRO_ADDR_45 error!\r\n"));
            return_error = GNSS_ERROR;
          }
          else
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 45h (TC OFF): 0x%x\r\n", Addr45RegisterValue));
          }
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG46, 1, &Addr46RegisterValue, 1, &timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_6DGYRO_ADDR_46 error!\r\n"));
            return_error = GNSS_ERROR;
          }
          else
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 46h (TC OFF): 0x%x\r\n", Addr46RegisterValue));
          }
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG47, 1, &Addr47RegisterValue, 1, &timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c read DR_6DGYRO_ADDR_47 error!\r\n"));
            return_error = GNSS_ERROR;
          }
          else
          {
            GPS_DEBUG_MSG(("[slld_3Dgyro] ASM330LXH Register 47h (TC OFF): 0x%x\r\n", Addr47RegisterValue));
          }

          Addr00RegisterValue = (tU8)0x00;
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_REG00, 1, &Addr00RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_6DGYRO_ADDR_00 error!\r\n"));
            return_error = GNSS_ERROR;
          }
        } // ASM330LHX ZRL built in temperature compensation turn off procedure end

        // Read the current CTRL3_C register
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_CTRL3_C, 1, &Ctrl3RegisterValue, 1, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_6DGYRO_CTRL3_C error!\r\n"));
          return_error = GNSS_ERROR;
        }

        // Write in the CTRL3_C register
        Ctrl3RegisterValue = (Ctrl3RegisterValue & ~SLLD_COMBO_IF_ADD_INC & ~SLLD_COMBO_BDU_MASK) | SLLD_COMBO_IF_ADD_INC | SLLD_COMBO_BDU_MASK;
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_CTRL3_C, 1, &Ctrl3RegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_CTRL3_C error!\r\n"));
          return_error = GNSS_ERROR;
        }

        // Read the other Ctrl registers
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_6DGYRO_CTRL2_G, 1, &CtrlRegisterValue[0], 10, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read CTRL register error!\r\n"));
          return_error = GNSS_ERROR;
        }

        if  (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE)
        {
          // Write in the CTRL2_G register
          Ctrl2GRegisterValue = CtrlRegisterValue[0];
          Ctrl2GRegisterValue = (Ctrl2GRegisterValue & ~SLLD_COMBO_ASM330LXH_ODR_MASK & ~SLLD_6DGYRO_ASM330LXH_FS_MASK) | SLLD_COMBO_ASM330LXH_ODR_50Hz | SLLD_6DGYRO_ASM330LXH_FS_125;
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_6DGYRO_CTRL2_G, 1, &Ctrl2GRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_ASM330LXH_CTRL2_G error!\r\n"));
            return_error = GNSS_ERROR;
          }
        }
        else
        /*SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE*/
        /*SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE*/
        /*SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE*/
         {
            // Write in the CTRL2_G register
            Ctrl2GRegisterValue = CtrlRegisterValue[0];
            // If Acc ODR has been set, use the same for the Gyro
            if (slld_fifo_info.slld_3Dacc_FiFoModeEn == TRUE)
            {
              Ctrl2GRegisterValue = ( ((Ctrl2GRegisterValue & ~SLLD_COMBO_LSM6DS3_ODR_MASK& ~SLLD_6DGYRO_LSM6DS3_FS_MASK)| SLLD_6DGYRO_LSM6DS3_FS_125) | ( (tU8)slld_fifo_info.odr_val.odr_fifo_LSM6DS3 << 4U) );
            }
            else
            {
              Ctrl2GRegisterValue = (Ctrl2GRegisterValue & ~SLLD_COMBO_LSM6DS3_ODR_MASK & ~SLLD_6DGYRO_LSM6DS3_FS_MASK) | SLLD_COMBO_LSM6DS3_ODR_52Hz | SLLD_6DGYRO_LSM6DS3_FS_125;
            }
            timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
            if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_6DGYRO_CTRL2_G, 1, &Ctrl2GRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
            {
              DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_LSM6DS3_CTRL2_G error!\r\n"));
              return_error = GNSS_ERROR;
            }
          }

        if ( (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE)  ||
             (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE) )
        {
          // Write in the CTRL10_C  register
          Ctrl10CRegisterValue = CtrlRegisterValue[8];
          Ctrl10CRegisterValue |= SLLD_6DGYRO_G_XYZ_ENABLED;
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_6DGYRO_CTRL10_C, 1, &Ctrl10CRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write error!\r\n"));
            return_error = GNSS_ERROR;
          }
        }

        if (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE)
        {
          // Write in the FIFO_CTRL register
          CtrlFifoRegisterValue = CtrlRegisterValue[9];
          CtrlFifoRegisterValue = (CtrlFifoRegisterValue & ~SLLD_COMBO_ASM330LXH_FIFO_MODE_MASK);
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_ASM330LXH_FIFO_CTRL, 1, &CtrlFifoRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_ASM330XLH_FIFO_CTRL error!\r\n"));
            return_error = GNSS_ERROR;
          }
        }
        else
          /*SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE*/
          /*SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE*/
          if ( (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE)  ||
               (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE) )
          {
            // If FIFO mode has been set for acc data don't change FIFO_CTRL5 register
            // Fifo mode for Gyro not yet supported
            if (slld_fifo_info.slld_3Dacc_FiFoModeEn == FALSE)
            {
              // Read the current FIFO_CTRL5 register
              timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
              if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL5, 1, &CtrlFifoRegisterValue, 1, &timeout) == gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_COMBO_LSM6DS3_FIFO_CTRL5 error!\r\n"));
                return_error = GNSS_ERROR;
              }

              // Write in the FIFO_CTRL5 register
              CtrlFifoRegisterValue &= ~SLLD_COMBO_LSM6DS3_BYPASS_MODE_MASK;
              timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
              if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL5, 1, &CtrlFifoRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
              {
                DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_LSM6DS3_FIFO_CTRL5 error!\r\n"));
                return_error = GNSS_ERROR;
              }

              if (slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE)
              {
                // Read the current CTRL4_C register
                timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
                if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_CTRL4_C, 1, &Ctrl4CRegisterValue, 1, &timeout) == gpOS_FAILURE)
                {
                  DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_6DGYRO_CTRL4_C error!\r\n"));
                  return_error = GNSS_ERROR;
                }

                // Write in the CTRL4_C register
                Ctrl4CRegisterValue = (Ctrl4CRegisterValue & ~SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR) | SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR;
                timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
                if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_CTRL4_C, 1, &Ctrl4CRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
                {
                  DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_CTRL4_C error!\r\n"));
                  return_error = GNSS_ERROR;
                }
              }
            }
          }

        // Read Dump register for LSM6DSR
        if(slld_3D6Dgyro_type == SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE)
        {
          tU8 CtrlCRegister00Value;
          tU8 DumpValue[0x52U];
          tU8 i;

          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read LSM6DSR Dump read procedure starts!\r\n"));

          // Write in the DR_LSM6DSR_BASIC_REG
          CtrlCRegister00Value = SLLD_LSM6DSR_DUMP_MODE;
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_LSM6DSR_BASIC_REG, 1, &CtrlCRegister00Value, 1, 1,&timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c write DR_LSM6DSR_BASIC_REG error!\r\n"));
            return_error = GNSS_ERROR;
          }

          // Read registers from 0x2e to 0x7f
          timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
          if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_LSM6DSR_DUMP_REG, 1, &DumpValue[0], 0x52U, &timeout) == gpOS_FAILURE)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] I2c read DR_LSM6DSR_DUMP_REG error!\r\n"));
            return_error = GNSS_ERROR;
          }

          DR_DEBUG_MSG(("[slld_3Dgyro] contents of registers 0x2E to 0x7F (hex format):\r\n"));

          for ( i=0x00U; i<=0x51U; i++)
          {
            DR_DEBUG_MSG(("[slld_3Dgyro] LSM6DSR Register %x: %x\r\n ",0x2EU+i,DumpValue[i]));
          }
          DR_DEBUG_MSG(("\r\n"));
        }

      }
      break;

    case SLLD_MEMS_6DGYRO_BMI160_TYPE:
      {
        tU8 GyroCtrlRegister[6];
        tU8 FifoConfig1Register;
        tU8 CmdRegisterValue = SLLD_COMBO_BMI160_GYR_SET_PMU_NORMAL_MODE;

        GPS_DEBUG_MSG(("[slld_3Dgyro] BMI160 recognized I2c mode \r\n"));

        // Write in the SLLD_COMBO_BMI160_CMD registers
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_BMI160_CMD_REGISTER, 1, &CmdRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_BMI160_CMD_REGISTER error!\r\n"));
          return_error = GNSS_ERROR;
        }

         // Read the Ctrl registers for Gyro
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_BMI160_GYR_CONF, 1, &GyroCtrlRegister[0], 6, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read CTRL register error!\r\n"));
          return_error = GNSS_ERROR;
        }

        // Set GYR_CNF register
        GyroCtrlRegister[0] = (GyroCtrlRegister[0] & SLLD_COMBO_BMI160_GYR_CONF_RES) | SLLD_COMBO_BMI160_GYR_BWP_NORMAL | SLLD_COMBO_BMI160_GYR_ODR_50Hz;
        // Set GYR_RANGE register
        GyroCtrlRegister[1] = (GyroCtrlRegister[1] & SLLD_COMBO_BMI160_GYR_RANGE_RES ) | SLLD_COMBO_BMI160_GYR_RANGE_FS_125 ;

        // Set FIFO_CONFIG_1 register
        FifoConfig1Register = (GyroCtrlRegister[5] & SLLD_COMBO_BMI160_FIFO1_RES ) | SLLD_COMBO_BMI160_NO_FIFO ;

        // Write in the DR_6GDGYRO_BMI160_GYR_CONF/DR_6GDGYRO_BMI160_GYR_RANGE registers
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_BMI160_GYR_CONF, 1, &GyroCtrlRegister[0], 2, 2, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_BMI160_GYR_CONF/SLLD_COMBO_BMI160_GYR_RANGE error!\r\n"));
          return_error = GNSS_ERROR;
        }

          // Write in the DR_COMBO_BMI160_FIFO_CONFIG1 register
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_BMI160_FIFO_CONFIG1, 1, &FifoConfig1Register, 1, 1,&timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c write SLLD_COMBO_BMI160_FIFO_CONFIG1 error!\r\n"));
          return_error = GNSS_ERROR;
        }
      }
      break;

    case SLLD_MEMS_6DGYRO_SMI130_TYPE:
      {
        tU8 GyroCtrlRegisterValue;
        tU8 GyroCtrlRegister[5];

        GPS_DEBUG_MSG(("[slld_3Dgyro] SMI130 recognized I2c mode \r\n"));

        // Write in the SLLD_SMI130_GYR_RANGE registers
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        GyroCtrlRegisterValue = SLLD_SMI130_GYR_RANGE_FS_125;
        if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_SMI130_GYR_RANGE, 1, &GyroCtrlRegisterValue, 1, 1,&timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c write DR_SMI130_GYR_RANGE error!\r\n"));
          return_error = GNSS_ERROR;
        }

         // Write in DR_SMI130_GYR_BW registers
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        GyroCtrlRegisterValue = SLLD_SMI130_GYR_BW_MAX;
        if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_SMI130_GYR_BW, 1, &GyroCtrlRegisterValue, 1, 1, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read DR_SMI130_GYR_BW register error!\r\n"));
          return_error = GNSS_ERROR;
        }

         // Write in DR_SMI130_GYR_HBW registers
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        GyroCtrlRegisterValue = (tU8) ( SLLD_SMI130_GYR_HBW_FILT | SLLD_SMI130_GYR_HBW_SHADOW_EN );
        if( svc_i2c_write( slld_3D6Dgyro_i2c_com_hnd, SLLD_SMI130_GYR_HBW, 1, &GyroCtrlRegisterValue, 1, 1, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read DR_SMI130_GYR_HBW register error!\r\n"));
          return_error = GNSS_ERROR;
        }

        // re-Read the Gyro Ctrl registers
        timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
        if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_SMI130_GYR_RANGE, 1, &GyroCtrlRegister[0], 5, &timeout) == gpOS_FAILURE)
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] I2c read CTRL register error!\r\n"));
          return_error = GNSS_ERROR;
        }
        else
        {
           DR_DEBUG_MSG(("[slld_3Dgyro] register 0x%x=%x\r\n",SLLD_SMI130_GYR_RANGE,GyroCtrlRegister[0]));
           DR_DEBUG_MSG(("[slld_3Dgyro] register 0x%x=%x\r\n",SLLD_SMI130_GYR_BW,GyroCtrlRegister[1]));
           DR_DEBUG_MSG(("[slld_3Dgyro] register 0x%x=%x\r\n",SLLD_SMI130_GYR_HBW,GyroCtrlRegister[4]));
        }

      }
      break;

    // unknown ytpe
    default:
      {
        return_error = GNSS_ERROR;
      }
      break;

    }
  return return_error;
}

gnss_error_t slld_3Dgyro_setup(const slld_fifo_info_t slld_fifo_info)
{
  gnss_error_t error = GNSS_NO_ERROR;

  if(SLLD_3D6DGYRO_SPI_BUS_TYPE == slld_3D6Dgyro_bus_type)
  {
    tU8 slld_3D6Dgyro_spi_command[2] = {(tU8)(SLLD_3D6DGYRO_READ_OPERATION | SLLD_3D6DGYRO_WHO_AM_I),0};
    tU8 slld_3D6Dgyro_spi_command_response[7];

    // Read the WHO_AM_I register
    if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_3D6DGYRO_WHO_AM_I error!\r\n"));
    }

    if ( (slld_3D6Dgyro_spi_command_response[1] == SLLD_3DGYRO_ID ) ||
         (slld_3D6Dgyro_spi_command_response[1] == SLLD_3DGYRO_ID_1) ||
         (slld_3D6Dgyro_spi_command_response[1] == SLLD_6DGYRO_ID_ASM330LXH ) ||
         (slld_3D6Dgyro_spi_command_response[1] == SLLD_6DGYRO_ID_LSM6DS3 ) ||
         (slld_3D6Dgyro_spi_command_response[1] == SLLD_6DGYRO_ID_LSM6DSM )  ||
         (slld_3D6Dgyro_spi_command_response[1] == SLLD_6DGYRO_ID_LSM6DSR))
    {
      DR_DEBUG_MSG(("[slld_3Dgyro] ID 0x%01x\r\n",slld_3D6Dgyro_spi_command_response[1]));

      switch (slld_3D6Dgyro_spi_command_response[1])
      {
        case SLLD_3DGYRO_ID:
        case SLLD_3DGYRO_ID_1:
        {
          /* 3D gyro ST Mems type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_3DGYRO_TYPE;
        }
        break;

        case SLLD_6DGYRO_ID_ASM330LXH:
        {
          /* 6D gyro ST Mems type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE;
          slld_6Dgyro_spi_read_command = (tU8*)slld_6Dgyro_st_spi_read_command;
          slld_6Dgyro_spi_read_temp_command = (tU8*)slld_6Dgyro_st_spi_read_temp_command;
        }
        break;

        case SLLD_6DGYRO_ID_LSM6DS3:
        {
          /* 6D gyro ST Mems type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE;
          slld_6Dgyro_spi_read_command = (tU8*)slld_6Dgyro_st_spi_read_command;
          slld_6Dgyro_spi_read_temp_command = (tU8*)slld_6Dgyro_st_spi_read_temp_command;
        }
        break;

        case SLLD_6DGYRO_ID_LSM6DSM:
        {
          /* 6D gyro ST Mems type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE;
          slld_6Dgyro_spi_read_command = (tU8*)slld_6Dgyro_st_spi_read_command;
          slld_6Dgyro_spi_read_temp_command = (tU8*)slld_6Dgyro_st_spi_read_temp_command;
        }
        break;

        case SLLD_6DGYRO_ID_LSM6DSR:
        {
          /* 6D gyro ST Mems type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE;
        }
        break;

        default:
        {
          error = GNSS_ERROR;
        }
        break;
      }
    }
    /* Other components */
    else
    {
      slld_3D6Dgyro_spi_command[0] = (tU8) ( SLLD_3D6DGYRO_READ_OPERATION | SLLD_COMBO_CHIPID_REGISTER );
      // Read other WHO_AM_I register
      if ( svc_ssp_write(slld_3D6Dgyro_spi_com_hnd,slld_3D6Dgyro_spi_command,2,slld_3D6Dgyro_spi_command_response,NULL) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dgyro] I2c read SLLD_3D6DGYRO_WHO_AM_I error!\r\n"));
      }

      DR_DEBUG_MSG(("[slld_3Dgyro] SPI ID 0x%01x\r\n",slld_3D6Dgyro_spi_command_response[1]));

      if (slld_3D6Dgyro_spi_command_response[1] == SLLD_COMBO_ID_BMI160)
      {
        /* 6D gyro BMI160 type */
        slld_3D6Dgyro_type = SLLD_MEMS_6DGYRO_BMI160_TYPE;
        slld_6Dgyro_spi_read_command = (tU8*)slld_6Dgyro_bosch_spi_read_command;
        slld_6Dgyro_spi_read_temp_command = (tU8*)slld_6Dgyro_bosch_spi_read_temp_command;
      }
      else
      {
        DR_DEBUG_MSG(("[slld_3Dgyro] Device not recognized!\r\n"));
        error = GNSS_ERROR;
      }

    }
    if ( error == GNSS_NO_ERROR )
    {
      error = slld_3Dgyro_init_CtrlReg_spi(slld_fifo_info);
    }
  }
  else
  {
    tU8 slld_3D6Dgyro_i2c_command_response[1] = {0};
    gpOS_clock_t timeout;

    // Read the ST Mems WHO_AMI_I register
    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
    if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_3D6DGYRO_WHO_AM_I, 1, &slld_3D6Dgyro_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_3Dgyro] I2c SLLD_3D6DGYRO_WHO_AM_I read error!\r\n"));
      return GNSS_ERROR;
    }

    /* If ST Mems */
    if( (slld_3D6Dgyro_i2c_command_response[0] == SLLD_3DGYRO_ID) ||
        (slld_3D6Dgyro_i2c_command_response[0] == SLLD_3DGYRO_ID_1) ||
        (slld_3D6Dgyro_i2c_command_response[0] == SLLD_6DGYRO_ID_ASM330LXH) ||
        (slld_3D6Dgyro_i2c_command_response[0] == SLLD_6DGYRO_ID_LSM6DS3) ||
        (slld_3D6Dgyro_i2c_command_response[0] == SLLD_6DGYRO_ID_LSM6DSM) ||
        (slld_3D6Dgyro_i2c_command_response[0] == SLLD_6DGYRO_ID_LSM6DSR))
    {
      DR_DEBUG_MSG(("[slld_3Dgyro] I2c ID 0x%01x\r\n",slld_3D6Dgyro_i2c_command_response[0]));

      switch (slld_3D6Dgyro_i2c_command_response[0])
      {
        case SLLD_3DGYRO_ID:
        case SLLD_3DGYRO_ID_1:
        {
          /* 3D gyro ST Mems type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_3DGYRO_TYPE;
        }
        break;

        case SLLD_6DGYRO_ID_ASM330LXH:
        {
          /* 6D gyro ST ASM330XLH type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_6DGYRO_ASM330XLH_TYPE;
        }
        break;

        case SLLD_6DGYRO_ID_LSM6DS3:
        {
          /* 6D gyro ST LSM6DS3 type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_6DGYRO_LSM6DS3_TYPE;
        }
        break;

        case SLLD_6DGYRO_ID_LSM6DSM:
        {
          /* 6D gyro ST LSM6DSM type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_6DGYRO_LSM6DSM_TYPE;
        }
        break;

        case SLLD_6DGYRO_ID_LSM6DSR:
        {
          /* 6D gyro ST LSM6DSR type */
          slld_3D6Dgyro_type = SLLD_ST_MEMS_6DGYRO_LSM6DSR_TYPE;
        }
        break;

        default:
        {
          error = GNSS_ERROR;
        }
        break;
      }
    }
    /* Other components */
    else
    {
      // Read other WHO_AMI_I register
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dgyro_i2c_com_hnd, SLLD_COMBO_CHIPID_REGISTER, 1, &slld_3D6Dgyro_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[slld_3Dgyro] I2c SLLD_COMBO_CHIP_REGISTER read error!\r\n"));
        error = GNSS_ERROR;
      }

      DR_DEBUG_MSG(("[slld_3Dgyro] I2c ID 0x%01x\r\n",slld_3D6Dgyro_i2c_command_response[0]));

      switch (slld_3D6Dgyro_i2c_command_response[0])
      {
        case SLLD_COMBO_ID_BMI160:
        {
          /* 6D gyro BMI160 type */
          slld_3D6Dgyro_type = SLLD_MEMS_6DGYRO_BMI160_TYPE;
        }
        break;


        case SLLD_GYRO_ID_SMI130:
        {
          /* 6D gyro SMI130 type */
          slld_3D6Dgyro_type = SLLD_MEMS_6DGYRO_SMI130_TYPE;
        }
        break;

        default:
        {
          DR_DEBUG_MSG(("[slld_3Dgyro] Device not recognized!\r\n"));
          error = GNSS_ERROR;
        }
        break;

      }
    }

    if ( error == GNSS_NO_ERROR)
    {
      error =  slld_3Dgyro_init_CtrlReg_i2c(slld_fifo_info);
    }
  }

  return  error;
}

void slld_3Dgyro_spi_cs_enable(void *par)
{
  if(SLLD_3D6DGYRO_NOT_CONFIG == slld_3D6Dgyro_cs_gpio_id)
  {
     LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SLLD_3DGYRO_SPI_GPIO_ADDR,SLLD_3DGYRO_SPI_CS_PIN);
  }
  else
  { /* TO DO: GPIO ID management for N ports target */
    if(slld_3D6Dgyro_cs_gpio_id < SLLD_3D6DGYRO_GPIO0_LAST_CH)
    {
       LLD_GPIO_SetStateLow((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (1U << slld_3D6Dgyro_cs_gpio_id));
    }
    else
      if(slld_3D6Dgyro_cs_gpio_id < SLLD_3D6DGYRO_GPIO1_LAST_CH)
      {
       LLD_GPIO_SetStateLow((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1U << (slld_3D6Dgyro_cs_gpio_id-32)));
      }
      else
      {
        // Impossible case
      }
  }
}

void slld_3Dgyro_spi_cs_disable(void *par)
{
  if(SLLD_3D6DGYRO_NOT_CONFIG == slld_3D6Dgyro_cs_gpio_id)
  {
     LLD_GPIO_SetStateHigh(SLLD_3DGYRO_SPI_GPIO_ADDR,SLLD_3DGYRO_SPI_CS_PIN);
  }
  else
  { /* TO DO: GPIO ID management for N ports target */
    if(slld_3D6Dgyro_cs_gpio_id < SLLD_3D6DGYRO_GPIO0_LAST_CH)
    {
       LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (1U << slld_3D6Dgyro_cs_gpio_id));
    }
    else
      if(slld_3D6Dgyro_cs_gpio_id < SLLD_3D6DGYRO_GPIO1_LAST_CH)
      {
        LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1U << (slld_3D6Dgyro_cs_gpio_id-32)));
      }
      else
      {
        // Impossible case
      }

  }
}

gnss_error_t slld_3Dgyro_init(const tU8 bus_type, const tU8 SA0, const tU8 i2c_SlaveAd_conf,const slld_fifo_info_t slld_fifo_info)
{
  if(SLLD_3D6DGYRO_SPI_BUS_TYPE == bus_type)
  {

     slld_3D6Dgyro_spi_com_hnd = svc_ssp_create_com(SLLD_3D6DGYRO_SPI_ID, LLD_SSP_INTERFACE_MOTOROLA_SPI,SLLD_3D6DGYRO_SPI_BUS_FREQUENCY, LLD_SSP_DATA_BITS_8,(svc_ssp_hook_t)slld_3Dgyro_spi_cs_enable, NULL, (svc_ssp_hook_t)slld_3Dgyro_spi_cs_disable, NULL);

     if(slld_3D6Dgyro_spi_com_hnd == NULL)
     {
        DR_DEBUG_MSG(("[slld_3Dgyro] SPI init failed!\r\n"));
        return GNSS_ERROR;
     }
     slld_3D6Dgyro_bus_type = SLLD_3D6DGYRO_SPI_BUS_TYPE;
  }
  else
  {
    /* backward compatibility */
    if (0x0U == i2c_SlaveAd_conf)
    {
     // Implementation for I2c bus type
     DR_DEBUG_MSG(("[slld_3Dgyro] I2C SLave Address: 0x%x!\r\n",(SLLD_3DGYRO_SLAVE_ADDR|SA0)));
     slld_3D6Dgyro_i2c_com_hnd = svc_i2c_create_com( 0U, (LLD_I2C_SpeedModeTy)LLD_I2C_STANDARD_MODE, (tU16)(SLLD_3DGYRO_SLAVE_ADDR|SA0));
    }
    else
    {
      /* i2c Slave address is in Param 672 of SwConfig*/
     DR_DEBUG_MSG(("[slld_3Dgyro] CDB-672 I2C SLave Address: 0x%x\r\n",i2c_SlaveAd_conf));
     slld_3D6Dgyro_i2c_com_hnd = svc_i2c_create_com( 0U, (LLD_I2C_SpeedModeTy)LLD_I2C_STANDARD_MODE, (tU16)i2c_SlaveAd_conf);
    }
    svc_i2c_set_port_mode( 0U, (LLD_I2C_BusCtrlModeTy)LLD_I2C_BUSCTRLMODE_MASTER);

    if(slld_3D6Dgyro_i2c_com_hnd == NULL)
    {
      return GNSS_ERROR;
    }
    slld_3D6Dgyro_bus_type = SLLD_3D6DGYRO_I2C_BUS_TYPE;
  }

  if(slld_3Dgyro_setup(slld_fifo_info) == GNSS_ERROR)
  {
    return GNSS_ERROR;
  }

  slld_3D6Dgyro_initialized = TRUE;

  return GNSS_NO_ERROR;
}


gnss_error_t slld_3Dgyro_CS_init(const tU8 bus_type, const tU8 cs_gpio_conf, const tU8 cs_pullup)
{
  tU32 cs_gpio;
  LLD_GPIO_ModeTy cs_mode;

  // if mode is SPI and cs gpio config is not set in nvm
  // Check for back compatibility
  if((SLLD_3D6DGYRO_SPI_BUS_TYPE == bus_type) && (0x0U == cs_gpio_conf))
  {
      LLD_GPIO_SetControlMode(SLLD_3DGYRO_SPI_GPIO_ADDR,SLLD_3DGYRO_SPI_CS_PIN,(LLD_GPIO_ModeTy)SLLD_3DGYRO_SPI_CS_PIN_MODE);
      LLD_GPIO_SetDirectionOutput(SLLD_3DGYRO_SPI_GPIO_ADDR,SLLD_3DGYRO_SPI_CS_PIN);
      LLD_GPIO_SetStateHigh(SLLD_3DGYRO_SPI_GPIO_ADDR,SLLD_3DGYRO_SPI_CS_PIN);
  }

  // if mode is SPI and cs gpio config is set in nvm or mode is I2C but cs pull up is set in nvm
  // pull up the cs
  if ( ((SLLD_3D6DGYRO_SPI_BUS_TYPE == bus_type)&&(0x0U != cs_gpio_conf)) || ((SLLD_3D6DGYRO_I2C_BUS_TYPE == bus_type) && (cs_pullup == 0x01U)) )
  {
    cs_gpio = ( tU32)(cs_gpio_conf & SLLD_3D6DGYRO_CONF_GPIO_MASK);
    cs_mode = ( LLD_GPIO_ModeTy)(cs_gpio_conf >> 6);
    slld_3D6Dgyro_cs_gpio_id = cs_gpio;
    if(cs_gpio < SLLD_3D6DGYRO_GPIO0_LAST_CH)
    {
      LLD_GPIO_SetControlMode((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (1U << cs_gpio), cs_mode);
      LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (1U << cs_gpio));
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (1U << cs_gpio));
    }
    else if(cs_gpio < SLLD_3D6DGYRO_GPIO1_LAST_CH)
    {
      LLD_GPIO_SetControlMode((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1U << (cs_gpio-32U)), cs_mode);
      LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1U << (cs_gpio-32U)));
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (1U << (cs_gpio-32U)));
    }
    else
      {
        /* impossible case */
        return GNSS_ERROR;
      }

  }

  return GNSS_NO_ERROR;
}

boolean_t slld_get_gyro_Init_Status(void)
{
  //DR_DEBUG_MSG(("[slld_get_gyro_Init_Status] slld_3D6Dgyro_initialized:%d\r\n",slld_3D6Dgyro_initialized));
  return slld_3D6Dgyro_initialized;
}

#endif  //__linux__

