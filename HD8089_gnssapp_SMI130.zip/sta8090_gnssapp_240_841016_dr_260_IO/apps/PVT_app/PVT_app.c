/*********************************************************************************************
   FILE:          PVT_app.c
----------------------------------------------------------------------------------------------
   DESCRIPTION: Every 2 second, it gets GNSS position/speed.time and displays it in Debug log
----------------------------------------------------------------------------------------------
   COPYRIGHT:     (c) 2016 STMicroelectronics
**********************************************************************************************/

/*****************************************************************************
   includes
*****************************************************************************/
#include "gnss_api.h"     /* to use GNSS api */
#include "gnss_debug.h"   /* to send data to debug port */
#include "nmea_support.h" /* to use nmea_support_degrees_to_int() function */

#if !defined (DEMO_USE_FREERTOS_API)
#include "gpOS.h"         /* to use OS related functions */
#endif

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/
#define PVT_APP_TASK_STACK_SIZE   1000   /* size of the sample application task stack */
#define MS_TO_KPH     (3600.0 / 1000.0)     /* define used for conversion */

/*****************************************************************************
   global variable definitions
*****************************************************************************/
tInt pvt_app_task_priority = 0;   /* task priority value (value set arbitrary here)*/
static TaskHandle_t xFrPVTAppProcess;

/*****************************************************************************
   function prototypes (scope: module-local)
*****************************************************************************/
/* Function which is called by "PVT_app_task" */
#if defined (DEMO_USE_FREERTOS_API)
static void pvt_app_process( void *pvParameters );
#else
static gpOS_task_exit_status_t pvt_app_process( void *p );
#endif

/*****************************************************************************
   function implementations
*****************************************************************************/
/* Function which is called by "PVT_app_task" */
#if defined (DEMO_USE_FREERTOS_API)
static void pvt_app_process( void *pvParameters )
#else
static gpOS_task_exit_status_t pvt_app_process( void *p )
#endif
{
  while ( TRUE )
  {
#if defined (DEMO_USE_FREERTOS_API)
     vTaskDelay( 2000/portTICK_PERIOD_MS );/* Wait for 2s */
#else
     gpOS_task_delay( 2*gpOS_timer_ticks_per_sec()); /* Wait for 2s */
#endif

     if (gnss_fix_get_pos_status() != NO_FIX)      /* Check if a 2D or 3D Fix is available */
     {
      position_t *user_position;
      velocity_t *user_velocity;
      tInt     lat_deg, lon_deg, lat_min, lon_min, lat_min_frac, lon_min_frac, week, hh, mm, ss, ms;
      char    lat_sense, lon_sense;
      tUInt   cpu_time;
      tDouble tow, course, speed;

      user_position = gnss_fix_get_fil_pos();        /* get user position */
      user_velocity = gnss_fix_get_fil_vel();        /* get user velocity */
      gnss_fix_get_time( &week, &tow, &cpu_time);    /* get time data */

       /* Note: to convert real degrees in "understandable" values for latitude and longitude -> uses existing NMEA support function to avoid code duplication.
                But this conversion could be done locally with another user defined function. */
       nmea_support_degrees_to_int( user_position->latitude, 'N', 'S', 5, &lat_deg, &lat_min, &lat_min_frac, &lat_sense );
       GPS_DEBUG_MSG(( "[PVT_app]user position -> latitude: %03d%c%02d.%03d\r\n", lat_deg, lat_sense, lat_min, lat_min_frac));         /* Display user latitude */
       nmea_support_degrees_to_int( user_position->longitude, 'E', 'W', 5, &lon_deg, &lon_min, &lon_min_frac, &lon_sense);
       GPS_DEBUG_MSG(( "[PVT_app]user position -> longitude: %03d%c%02d.%03d\r\n", lon_deg, lon_sense, lon_min, lon_min_frac));        /* Display user longitude */

       GPS_DEBUG_MSG(( "[PVT_app]user position -> height: %03.2f\r\n", user_position->height));                                        /* Display user height */

       gnss_conv_vel_to_course_speed(user_velocity, &course, &speed);                                                                    /* Convert velocity E/N into speed */
       GPS_DEBUG_MSG(( "[PVT_app]user speed -> %03.3f km/h, %03.3f m/s\r\n", speed* MS_TO_KPH, speed));                              /* Display user speed */

       gnss_get_utc_time(tow, &hh, &mm, &ss, &ms);                                                                                       /* Compute UTC time */
       GPS_DEBUG_MSG(( "[PVT_app] week: %04d UTC time: %2d:%2d:%2d\r\n", week, hh, mm, ss));                                         /* Display week and UTC time */
     }
     else
     {
       GPS_DEBUG_MSG(( "[PVT_app] No acquired GNSS FIX yet. \r\n"));
     }
  }
}

/* Creation of "PVT_app_task" */
void pvt_app_init(gpOS_partition_t *part)
{
#if defined (DEMO_USE_FREERTOS_API)
  xTaskCreate( pvt_app_process, "PVT_app_task", PVT_APP_TASK_STACK_SIZE, NULL, pvt_app_task_priority + 15, &xFrPVTAppProcess );
#else
  gpOS_task_create_p( part, pvt_app_process, NULL, PVT_APP_TASK_STACK_SIZE, pvt_app_task_priority + 15, "PVT_app_task", gpOS_TASK_FLAGS_ACTIVE );
#endif
}


