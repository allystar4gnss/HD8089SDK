/*****************************************************************************
   FILE:          NOC_app.c
   PROJECT:       STA8090 GPS application
   SW PACKAGE:    STA8090 GPS library and application
------------------------------------------------------------------------------
   DESCRIPTION:   Module to run and test STA8090 CAN module
------------------------------------------------------------------------------
   COPYRIGHT:     (c) 2016 STMicroelectronics, Catania (ITALY)
------------------------------------------------------------------------------
   Created by : Aldo Occhipinti
           on : 2016.02.04
*****************************************************************************/

/*****************************************************************************
   includes
*****************************************************************************/
#include <math.h>
#include "clibs.h"
#include "typedefs.h"
#include "NOC_app.h"
#include "gnss_debug.h"
#include "gnss_events.h"
#include "lld_gpio.h"
#include "svc_can.h"
#include "platform.h"
#include "sw_config.h"

/*****************************************************************************
   external declarations
*****************************************************************************/

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/
#define CANTX_TASK_WORKSPACE            2048
#define CANRX_TASK_WORKSPACE            2048

#define CAN_RX_OBJECTS_NUM                10
#define LL_DEG_MASK                    0x7FU
#define LL_MIN_MASK                    0xFFU
#define SCALE_10                        10.0
#define MS_TO_KPH          (3600.0 / 1000.0)

#define NOC_CMDID_MSG1                   0x1
#define NOC_CMDID_MSG2                   0x2
#define NOC_CMDID_MSG3                   0x4
#define NOC_CMDID_MSG4                   0x8

#define INT_ROUND(x)    ((tInt)floor((x)+0.5))

//#define DEBUG_ACCEPTANCE_FILTER  /* this define can be enabled to debug the proper working */
                                   /* of the Acceptance Filtering setting in the NoC Viewer  */

/*****************************************************************************
   typedefs and structures (scope: module-local)
*****************************************************************************/

/********************************************//**
 * \brief can handler
 ***********************************************/
typedef struct can_handler_s
{
  gpOS_partition_t *  part;              /**< partition used for dynamic allocation */

  gpOS_task_t *       TxTask;            /**< TxTask pointer */
  gpOS_task_t *       RxTask;            /**< RxTask pointer */

  gpOS_semaphore_t *  RxAccess_sem;      /**< RxAccess semaphore */

  tU8  port;
} can_handler_t;

/********************************************//**
 * \brief To store data for the Nmea Over Can
 *        common information
 ***********************************************/
typedef struct NoC_outmsg_common_data_s
{
  // gnss_get_date()
  tInt       day;
  tInt       month;
  tInt       year;

  // gnss_get_utc_time()
  tInt       hours;
  tInt       mins;
  tInt       secs;
  tInt       msecs;

  // gnss_fix_get_dops_local();
  tDouble    pdop;
  tDouble    hdop;
  tDouble    vdop;
  tDouble    gdop;

  //nmea_fix_get_position_velocity()
  position_t extrap_pos;
  tDouble    speed;
  tDouble    course;

  // gnss_get_constellation_mask()
  tU16       GPS_enabled;
  tU16       Glonass_enabled;

  // gnss_get_sats_visible()
  tU8        sats_ID[TRK_CHANNELS_SUPPORTED];
  tU16       sats_azimuth[TRK_CHANNELS_SUPPORTED];
  tU8        sats_elevation[TRK_CHANNELS_SUPPORTED];
  // gnss_fix_get_raw_measurements_local()
  tU8        sats_CN0[TRK_CHANNELS_SUPPORTED];

  // gnss_fix_get_num_sats_used_local()
  tInt       num_sats_used;
  tInt       num_sats_visible;

  // gnss_fix_get_pos_status_local()
  tInt       fix_type;

} NoC_outmsg_common_data_t;


/*****************************************************************************
   global variable definitions  (scope: module-exported)
*****************************************************************************/

/*****************************************************************************
   global variable definitions (scope: module-local)
*****************************************************************************/
static can_handler_t *can_handler = NULL;
static gnss_events_synch_handler_t *nmea_can_outmsg_synchdlr_ptr;
static void * noc_outmsg_fixdata_ptr;
static tUInt  NoC_msg_list;
#ifdef DEBUG_ACCEPTANCE_FILTER
static tU32 dummy_msg_id  = 1700;
#endif

/*****************************************************************************
   function prototypes (scope: module-local)
*****************************************************************************/
static gpOS_task_exit_status_t NoC_tx_process    ( void *);
static void NoC_send_configured_base_msg( const NoC_outmsg_common_data_t *, const gnss_time_t);
static void NoC_send_QIC_msg1( const NoC_outmsg_common_data_t * );
static void NoC_send_QIC_msg2( const NoC_outmsg_common_data_t * );
static void NoC_send_QIC_msg3( const NoC_outmsg_common_data_t * );
static void NoC_send_QIC_msg4( const NoC_outmsg_common_data_t * );

/*****************************************************************************
   function implementations (scope: module-local)
*****************************************************************************/

/********************************************//**
 * \brief   get constellation mask
 *
 * \param   sat_constellation_mask
 *
 * \return  None
 *
 ***********************************************/
static void NoC_get_constellation_mask(gnss_sat_type_mask_t *sat_constellation_mask, NoC_outmsg_common_data_t *NoC_common_data_p)
 {
    gnss_sat_type_mask_t const_mask_supported = gnss_get_constellation_mask();

    *sat_constellation_mask = 0;
    NoC_common_data_p->GPS_enabled = 0;
    NoC_common_data_p->Glonass_enabled = 0;

    if ( sw_config_get_software_switch_status( GPS_ON_OFF_SWITCH ) )
    {
      *sat_constellation_mask |= ( 1 << GNSS_SAT_TYPE_GPS );
      NoC_common_data_p->GPS_enabled = 1;
    }

    if ( MCR_ISBITSET( const_mask_supported, GNSS_SAT_TYPE_GLONASS ) )
    {
      if ( sw_config_get_software_switch_status( GLONASS_ON_OFF_SWITCH ) )
      {
        *sat_constellation_mask |= ( 1 << GNSS_SAT_TYPE_GLONASS );
        NoC_common_data_p->Glonass_enabled = 1;
      }
    }
 }

/********************************************//**
 * \brief   translate Glonass sat IDs
 *
 * \param   Glonass sat ID
 *
 * \return  translated sat ID
 *
 ***********************************************/
static satid_t NoC_translate_satid(satid_t sat_id)
{
  satid_t translated_sat_id;

  if(gnss_sat_id_to_sat_type(sat_id) == GNSS_SAT_TYPE_GLONASS)
  {
    tChar glonass_output_format;
    sw_config_get_param(CURRENT_CONFIG_DATA,GLONASS_OUTPUT_FORMAT_ID,&glonass_output_format);
    switch(glonass_output_format)
    {
      case GLONASS_OUTPUT_FORMAT_FREQ:
        translated_sat_id = sat_id;
      break;

      case GLONASS_OUTPUT_FORMAT_SLOT:
        {
          tInt slot;
          if(gnss_glonass_get_satellite_slot(sat_id,&slot)==GNSS_NO_ERROR)
          {
            translated_sat_id = 64+slot;
          }
        }
      break;
    }
  }
  else
  {
    translated_sat_id = sat_id;
  }

  return translated_sat_id;
}

/********************************************//**
 * \brief   Get the visible satellites
 *
 * \param   sat_constellation_mask
 * \param   sats_visible
 *
 * \return  num of visible sats
 *
 ***********************************************/
static void NoC_get_gnss_satellites_used_list( NoC_outmsg_common_data_t *NoC_common_data_p )
{
  tInt i;
  raw_t *raw_data;
  raw_measure_list_t *raw_meas;
  tInt sats_used = 0;
  tInt satellite_CN0;
  gnss_sat_type_mask_t sat_constellation_mask;

  NoC_get_constellation_mask( &sat_constellation_mask, NoC_common_data_p );
  raw_meas = gnss_fix_get_raw_measurements_local( NULL );
  raw_data = raw_meas->list;

   for ( i = 0; i < TRK_CHANNELS_SUPPORTED; i++ )
   {
     boolean_t current_sat_excluded = FALSE;
     gnss_exclusion_type_t exclusion_type;

     current_sat_excluded = (gnss_fix_get_excluded_sats_range_local(i, &exclusion_type,NULL)==TRUE) || (gnss_fix_get_excluded_sats_doppl_local(i, &exclusion_type,NULL)==TRUE);

     if ( ( raw_meas->chans_used[i] ) &&
         MCR_ISBITSET( sat_constellation_mask, gnss_sat_id_to_sat_type( raw_data[i].dsp.satid ) ) &&
         (current_sat_excluded == FALSE) )
     {
        NoC_common_data_p->sats_ID[sats_used] = raw_data[i].dsp.satid;
        satellite_CN0 = raw_data[i].dsp.signal_strength;

        if (satellite_CN0 < 61)
        {
          NoC_common_data_p->sats_CN0[sats_used] = (tU8)satellite_CN0;
        }
        else
        {
          NoC_common_data_p->sats_CN0[sats_used] = 61;
        }

        sats_used++;
      }
   }

   NoC_common_data_p->num_sats_used = sats_used;
}


static void NoC_get_gnss_satellites( NoC_outmsg_common_data_t *NoC_common_data_p )
{
  tInt i;
  tInt sats_used;
  visible_sats_data_t sats_visible;
  boolean_t used_sat_found;

  NoC_get_gnss_satellites_used_list( NoC_common_data_p );

  gnss_get_sats_visible( &sats_visible );
  NoC_common_data_p->num_sats_visible = sats_visible.list_size;

     for ( i = 0; i < NoC_common_data_p->num_sats_used; i++ )
     {
       sats_used = 0;
       used_sat_found = FALSE;

       while ((used_sat_found == FALSE) && (sats_used < sats_visible.list_size))
       {
         if ( NoC_common_data_p->sats_ID[i] == sats_visible.list[sats_used].satid )
         {
            used_sat_found = TRUE;
            NoC_common_data_p->sats_ID[i]=(tU8) NoC_translate_satid( sats_visible.list[sats_used].satid);
            NoC_common_data_p->sats_elevation[i] = (tU8)sats_visible.list[sats_used].elevation;
            NoC_common_data_p->sats_azimuth[i] = (tU16)sats_visible.list[sats_used].azimuth;
         }

         sats_used++;
       }
     }

     /*GPS_DEBUG_MSG(("[NoC debug] measured sats_used=%d num_sats_visible=%d\r\n",
         NoC_common_data_p->num_sats_used, NoC_common_data_p->num_sats_visible));*/
}

 /********************************************//**
 * \brief   Construct the real degrees into deg, min, min_fractions and 'N' or 'S'
 *
 * \param   real_degrees const tDouble
 * \param   plus_char const tChar
 * \param   minus_char const tChar
 * \param   decimal_places const tInt
 * \param   deg_int tInt*
 * \param   min_int tInt*
 * \param   min_frac_int tInt*
 * \param   sec_int tInt*
 * \param   sec_frac_int tInt*
 * \param   sense_char tChar*
 * \return  None
 *
 ***********************************************/
static void NoC_support_degrees_to_int( const tDouble real_degrees, const tChar plus_char, const tChar minus_char,
                                        const tInt decimal_places, tInt *deg_int, tInt *min_int, tInt *min_frac_int,
                                        tInt *sec_int, tInt *sec_frac_int, tChar *sense_char)
{
  tInt i;
  tInt frac_scale = 1;
  tInt sec_frac_scale = 1;
  tDouble half_round_value;
  tDouble abs_real_degrees;
  tDouble real_mins, real_secs;

  for ( i = 0; i < decimal_places; i++)
  {
    frac_scale *= 10;
  }

  for (i = 0; i < 2; i++)
  {
    sec_frac_scale *= 10;
  }

  half_round_value = 0.5 / (tDouble)(frac_scale * 60.0);

  if( real_degrees >= 0.0)
  {
    abs_real_degrees = real_degrees + half_round_value;

    if ( sense_char != NULL)
    {
       *sense_char = plus_char;
    }
  }
  else
  {
    abs_real_degrees = -real_degrees + half_round_value;

    if ( sense_char != NULL)
    {
      *sense_char = minus_char;
    }
  }

  if ( deg_int != NULL)
  {
      *deg_int = (tInt)abs_real_degrees;
  }

  real_mins = (abs_real_degrees - (tDouble)*deg_int) * 60.0;

  if ( min_int != NULL)
  {
      *min_int = (tInt)(real_mins);
  }

  if ( min_frac_int != NULL)
  {
     *min_frac_int = (tInt)((real_mins- (tDouble)*min_int) * (tDouble)frac_scale);
  }

  real_secs =  (real_mins- (tDouble)*min_int) * 60.0;

  if ( sec_int != NULL)
  {
     *sec_int= (tInt)(real_secs);
  }

  if ( sec_frac_int != NULL)
  {
     *sec_frac_int = (tInt)((real_secs- (tDouble)*sec_int) * (tDouble)sec_frac_scale);
  }
}

/********************************************//**
 * \brief   Free all allocated memory
 *
 * \return  gpOS_error_t
 *
 ***********************************************/
static gpOS_error_t can_fail( void)
{
  gpOS_error_t error = gpOS_FAILURE;

  if ( gpOS_task_delete( can_handler->TxTask) == gpOS_FAILURE)
  {
    GPS_DEBUG_MSG(("[NoC] Can Task Delete error!\r\n"));
  }

  gpOS_memory_deallocate_p( can_handler->part, can_handler);

  return error;
}

/********************************************//**
 * \brief Get the position and the velocity
 *
 * \param   position_t *extrap_pos
 * \param   tDouble *course
 * \param   tDouble *speed
 * \param   void *data_p
 *
 * \return None
 *
 ***********************************************/
static void NoC_fix_get_position_velocity( position_t *extrap_pos, tDouble *course, tDouble *speed, void *data_p )
{
  position_t pos;
  velocity_t vel;

  gnss_fix_get_fil_pos_vel_local(&pos, &vel, data_p);

  extrap_pos->latitude  = pos.latitude;
  extrap_pos->longitude = pos.longitude;
  extrap_pos->height    = pos.height;

  if ( gnss_conv_vel_to_course_speed( &vel, course, speed ) == GNSS_ERROR)
  {
    GPS_DEBUG_MSG(("[NoC] Fix Get Position error!\r\n"));
  }
}

/********************************************//**
 * \brief   Get data common to several NoC output messages
 *
 * \param   data_p              Fix data structure
 * \param   NoC_common_data_p   Common NoC output data structure
 * \param   utc_time            Current utc time
 *
 * \return  None
 *
 ***********************************************/
static void NoC_get_common_data( void * data_p, NoC_outmsg_common_data_t *NoC_common_data_p, const gnss_time_t utc_time)
{
  if ( NoC_common_data_p != NULL)
  {

    if ( gnss_get_utc_time( utc_time.tow, &NoC_common_data_p->hours, &NoC_common_data_p->mins, &NoC_common_data_p->secs, &NoC_common_data_p->msecs ) == GNSS_ERROR)
    {
      GPS_DEBUG_MSG(("[NoC] Fix Get UTC Time error!\r\n"));
    }

    if ( gnss_get_date( utc_time.week_n, utc_time.tow, &NoC_common_data_p->year, &NoC_common_data_p->month, &NoC_common_data_p->day ) == GNSS_ERROR)
    {
      GPS_DEBUG_MSG(("[NoC] Fix Get Date error!\r\n"));
    }

    NoC_fix_get_position_velocity( &NoC_common_data_p->extrap_pos, &NoC_common_data_p->course, &NoC_common_data_p->speed, data_p );
    NoC_common_data_p->num_sats_used = gnss_fix_get_num_sats_used_local( data_p ) - gnss_fix_get_num_sats_excluded_local( data_p );
    NoC_common_data_p->fix_type = ( tInt )gnss_fix_get_pos_status_local( data_p );
    gnss_fix_get_dops_local( &NoC_common_data_p->pdop, &NoC_common_data_p->hdop, &NoC_common_data_p->vdop, &NoC_common_data_p->gdop, data_p );
    NoC_get_gnss_satellites( NoC_common_data_p );
  }
}


/********************************************//**
 * \brief   Sends the QIC Message 4
 *
 * \param   NoC_common_data_p
 *
 * \return  None
 *
 ***********************************************/
static void NoC_send_QIC_msg4( const NoC_outmsg_common_data_t *NoC_common_data_p)
{
   tU8 out_msg[8];
   tU8 tmp;
   tU32 obj;
   tU32 msg_id, dlc;
   tU64 *payload;

   msg_id  = 0x70B;
   obj = 23;
   dlc = 8;

   if ( NoC_common_data_p != NULL)
   {
     tmp = (tU8)(((tUInt)NoC_common_data_p->num_sats_used) & 0x3FU);
     out_msg[0] = (tU8)(tmp | (( ((tUInt)NoC_common_data_p->fix_type) & 0x03U) << 6));
     out_msg[1] = (tU8)NoC_common_data_p->num_sats_visible;

     //GPS_DEBUG_MSG(("Can FIx %d \r\n", out_msg[1] ));

    {
      tUInt tmp1, tmp2, tmp3;

      tmp1 = (tUInt) INT_ROUND( NoC_common_data_p->pdop * (tDouble)SCALE_10);
      tmp2 = (tUInt) INT_ROUND( NoC_common_data_p->hdop * (tDouble)SCALE_10);
      tmp3 = (tUInt) INT_ROUND( NoC_common_data_p->vdop * (tDouble)SCALE_10);

      out_msg[2] = (tU8) ( tmp1 & 0x00FFU);
      out_msg[3] = (tU8) ( tmp1 & 0xFF00U);

      out_msg[4] = (tU8) ( tmp2 & 0x00FFU);
      out_msg[5] = (tU8) ( tmp2 & 0xFF00U);

      out_msg[6] = (tU8) ( tmp3 & 0x00FFU);
      out_msg[7] = (tU8) ( tmp3 & 0xFF00U);
     }

     payload = (tU64 *)&out_msg[0];

     if( svc_can_send( can_handler->port, &obj, &msg_id, payload, dlc, LLD_CAN_STD_ID) == gpOS_FAILURE)
     {
        GPS_DEBUG_MSG(("[NoC] Can Send Msg4 error!\r\n"));
     }
  }
  else
  {
    GPS_DEBUG_MSG(("[NoC] Msg4 no data\r\n"));
  }
}

/********************************************//**
 * \brief   Sends the QIC Message 3
 *
 * \param   NoC_common_data_p
 *
 * \return  None
 *
 ***********************************************/
static void NoC_send_QIC_msg3( const NoC_outmsg_common_data_t *NoC_common_data_p)
{
   tU8 out_msg[8];
   tU32 obj;
   tU32 msg_id, dlc;
   tU64 *payload;

   msg_id  = 0x70A;
   obj = 22;
   dlc = 4;

   if ( NoC_common_data_p != NULL)
   {
     out_msg[0] = (tU8) ((  (tUInt)INT_ROUND(( NoC_common_data_p->speed * MS_TO_KPH) * SCALE_10)) & 0x00FFU);
     out_msg[1] = (tU8) ((( (tUInt)INT_ROUND(( NoC_common_data_p->speed * MS_TO_KPH) * SCALE_10)) & 0xFF00U) >> 8);

     out_msg[2] = (tU8) ((  (tUInt)INT_ROUND( NoC_common_data_p->course * SCALE_10)) & 0x00FFU);
     out_msg[3] = (tU8) ((( (tUInt)INT_ROUND( NoC_common_data_p->course * SCALE_10)) & 0xFF00U) >> 8);

     payload = (tU64 *)&out_msg[0];

     if( svc_can_send( can_handler->port, &obj, &msg_id, payload, dlc, LLD_CAN_STD_ID) == gpOS_FAILURE)
     {
        GPS_DEBUG_MSG(("[NoC] Can Send Msg3 error!\r\n"));
     }
   }
   else
   {
     GPS_DEBUG_MSG(("[NoC] Msg3 no data\r\n"));
   }

   //GPS_DEBUG_MSG(("[NoC] 0x%x 0x%x %f 0x%x 0x%x %f\r\n", out_msg[0], out_msg[1], NoC_common_data_p->course, out_msg[2], out_msg[3], NoC_common_data_p->speed));
}

/********************************************//**
 * \brief   Sends the QIC Message 2
 *
 * \param   NoC_common_data_p
 *
 * \return  None
 *
 ***********************************************/
static void NoC_send_QIC_msg2( const NoC_outmsg_common_data_t *NoC_common_data_p)
{
   tU8   out_msg[8];
   tInt  lat_deg;
   tInt  lat_min;
   tInt  lat_min_frac;
   tInt  lat_sec;
   tInt  lat_sec_frac;
   tInt  lon_deg;
   tInt  lon_min;
   tInt  lon_min_frac;
   tInt  lon_sec;
   tInt  lon_sec_frac;
   tChar lat_sense_ch;
   tChar lon_sense_ch;
   tU32  obj;
   tU32  msg_id, dlc;
   tU64  *payload;
   tU8 lat_sign_bit, lon_sign_bit;
   volatile tU16 secs;


   msg_id  = 0x709;
   obj = 21;
   dlc = 8;

   if ( NoC_common_data_p != NULL)
   {
     NoC_support_degrees_to_int( NoC_common_data_p->extrap_pos.latitude,  'N', 'S', 5, &lat_deg, &lat_min, &lat_min_frac, &lat_sec, &lat_sec_frac, &lat_sense_ch );
     NoC_support_degrees_to_int( NoC_common_data_p->extrap_pos.longitude, 'E', 'W', 5, &lon_deg, &lon_min, &lon_min_frac, &lon_sec, &lon_sec_frac, &lon_sense_ch );

     if( lat_sense_ch == 'N' ) /* north hemisphere */
     {
        lat_sign_bit = 0x80;
     }
     else /* south hemisphere */
     {
        lat_sign_bit = 0x00;
     }

     if( lon_sense_ch == 'E' ) /* east in respect to greenwich */
     {
        lon_sign_bit = 0x80;
     }
     else /* west in respect to greenwich */
     {
        lon_sign_bit = 0x00;
     }

     out_msg[0] = (tU8) ((lat_sign_bit | ( ((tU8)lat_deg) & ((tU8)LL_DEG_MASK))));
     out_msg[1] = (((tU8) lat_min) & ((tU8)LL_MIN_MASK));

     secs = (tU16)(( lat_sec + ( lat_sec_frac * 0.01 )) * 100);

     out_msg[2] = (tU8)( secs & 0x00FFU);
     out_msg[3] = (tU8)((secs & 0x1F00U) >> 8);

     //GPS_DEBUG_MSG(("Can Pos %5d %5d %5d %d 0x%x 0x%x 0x%x \n", lat_min_frac, lat_sec, lat_sec_frac, secs, secs, out_msg[2], out_msg[3] ));

     out_msg[4] = (tU8) ((lon_sign_bit | ( ((tU8) lon_deg) & ((tU8)LL_DEG_MASK))));
     out_msg[5] = (((tU8) lon_min) & ((tU8)LL_MIN_MASK));

     secs = (tU16)(( lon_sec + ( lon_sec_frac * 0.01 )) * 100);

     out_msg[6] = (tU8)( secs & 0x00FFU);
     out_msg[7] = (tU8)((secs & 0x1F00U) >> 8);

     payload = (tU64 *)&out_msg[0];

     if( svc_can_send( can_handler->port, &obj, &msg_id, payload, dlc, LLD_CAN_STD_ID) == gpOS_FAILURE)
     {
        GPS_DEBUG_MSG(("[NoC] Can Send Msg2 error!\r\n"));
     }
  }
  else
   {
     GPS_DEBUG_MSG(("[NoC] Msg2 no data\r\n"));
   }
}

/********************************************//**
 * \brief   Sends the QIC Message 1
 *
 * \param   NoC_common_data_p
 *
 * \return  None
 *
 ***********************************************/
static void  NoC_send_QIC_msg1( const NoC_outmsg_common_data_t *NoC_common_data_p)
{
   tU32 obj;
   tU32 msg_id, dlc;
   tU64 *payload;
   tU8 out_msg[8];

   msg_id  = 0x708;
   obj     = 20;
   dlc     = 8;

   if ( NoC_common_data_p != NULL)
   {
     out_msg[0] = (tU8)( NoC_common_data_p->day);
     out_msg[1] = (tU8)( NoC_common_data_p->month);
     out_msg[2] = (tU8)( NoC_common_data_p->year % 100);
     out_msg[3] = (tU8)( NoC_common_data_p->hours);
     out_msg[4] = (tU8)( NoC_common_data_p->mins);
     out_msg[5] = (tU8)( NoC_common_data_p->secs);
     out_msg[6] = (tU8)( ((tU16) NoC_common_data_p->extrap_pos.height) & 0x00FFU);
     out_msg[7] = (tU8)( (((tU16)NoC_common_data_p->extrap_pos.height) & 0xFF00U) >> 8);

     payload = (tU64 *)&out_msg[0];

     if( svc_can_send( can_handler->port, &obj, &msg_id, payload, dlc, LLD_CAN_STD_ID) == gpOS_FAILURE)
     {
        GPS_DEBUG_MSG(("[NoC] Can Send Msg1 error!\r\n"));
     }
  }
  else
  {
     GPS_DEBUG_MSG(("[NoC] Msg1 no data\r\n"));
  }
}

#ifdef DEBUG_ACCEPTANCE_FILTER
static void  NoC_send_dummy_msg( void)
{
   tU16 obj;
   tU32 msg_id, dlc;
   tU64 *payload;
   tU8 out_msg[8];


   //dummy_msg_id  = 0x808;
   dummy_msg_id++;
   obj     = 19;
   dlc     = 8;

   out_msg[0] = 0x11;
   out_msg[1] = 0x11;
   out_msg[2] = 0x11;
   out_msg[3] = 0x11;
   out_msg[4] = 0x11;
   out_msg[5] = 0x11;
   out_msg[6] = 0x11;
   out_msg[7] = 0x11;

   payload = (tU64 *)&out_msg[0];

   if( svc_can_send( can_handler->port, &obj, &dummy_msg_id, payload, dlc, LLD_CAN_STD_ID) == gpOS_FAILURE)
   {
      GPS_DEBUG_MSG(("[NoC] Can Send error!\r\n"));
   }

   GPS_DEBUG_MSG(("DUMMY CAN %x\r\n", dummy_msg_id ));
}
#endif

/********************************************//**
 * \brief   Sends the configured QIC messages
 *
 * \param   NoC_common_data_p
 * \param   utc_time
 *
 * \return  None
 *
 ***********************************************/
static void NoC_send_configured_base_msg( const NoC_outmsg_common_data_t *NoC_common_data_p, const gnss_time_t utc_time)
{

  if (( NoC_msg_list & NOC_MSG1) != FALSE)
  {
      /* NMEA over CAN - QIC GPS Msg1 */
      NoC_send_QIC_msg1( NoC_common_data_p);
  }

  if (( NoC_msg_list & NOC_MSG2) != FALSE)
  {
      /* NMEA over CAN - QIC GPS Msg2 */
      NoC_send_QIC_msg2( NoC_common_data_p);
  }

  if (( NoC_msg_list & NOC_MSG3) != FALSE)
  {
      /* NMEA over CAN - QIC GPS Msg3 */
      NoC_send_QIC_msg3( NoC_common_data_p);
  }

  if (( NoC_msg_list & NOC_MSG4) != FALSE)
  {
      /* NMEA over CAN - QIC GPS Msg4 */
      NoC_send_QIC_msg4( NoC_common_data_p);
  }

#ifdef DEBUG_ACCEPTANCE_FILTER
  NoC_send_dummy_msg();
#endif

}

/********************************************//**
 * \brief  Tx process for the NoC is triggered by the FIX event
 *
 * \param  void *p
 *
 * \return
 *
 ***********************************************/
static gpOS_task_exit_status_t NoC_tx_process( void *p)
{
  boolean_t exit_flag = FALSE;
  tInt week_n;
  gpOS_clock_t fix_clock;
  tDouble tow;
  gnss_time_t gnss_time = {0};
  gnss_time_t utc_time;
  NoC_outmsg_common_data_t  NoC_common_data;
  NoC_outmsg_common_data_t *NoC_common_data_p = &NoC_common_data;

  //gpOS_task_delay( 5 * gpOS_timer_ticks_per_sec());

  gnss_events_install( GNSS_EVENTID_FIXREADY, nmea_can_outmsg_synchdlr_ptr);

  while( exit_flag == FALSE)
  {
    gnss_events_wait( GNSS_EVENTID_FIXREADY, nmea_can_outmsg_synchdlr_ptr);

    gnss_fix_store_local( NULL );
    gnss_fix_get_time_local( &week_n, &tow, &fix_clock, NULL );
    gnss_time.week_n = week_n;
    gnss_time.tow    = tow;
    utc_time = gnss_time_to_utc_time( gnss_time, gnss_fix_get_time_sat_type_local( NULL ) );

    NoC_get_common_data( NULL, NoC_common_data_p, utc_time);

    NoC_send_configured_base_msg( NoC_common_data_p, utc_time);
  }

  // should never reach this
  return -1;
}

/********************************************//**
 * \brief  Rx process for the NoC
 *
 * \param void *p
 *
 * \return
 *
 ***********************************************/
static gpOS_task_exit_status_t NoC_rx_process( void *p)
{
  boolean_t exit_flag = FALSE;
  tU32 msg_id;
  tU32 obj_id;
  tU64 data;
  tInt cnt = 0;

  while( exit_flag == FALSE)
  {
     gpOS_semaphore_wait( can_handler->RxAccess_sem);

     if( svc_can_receive( can_handler->port, &obj_id, &msg_id, &data, gpOS_TIMEOUT_INFINITY) == gpOS_FAILURE)
     {
        GPS_DEBUG_MSG(("[NoC] Error Receive\r\n"));
     }

     GPS_DEBUG_MSG(("\n[CanRx][%d][0x%x][%d] 0x%x%x%x%x%x%x%x%x\r\n", obj_id, msg_id, cnt++,
                                                                     ((tU8 *)&data)[0],
                                                                     ((tU8 *)&data)[1],
                                                                     ((tU8 *)&data)[2],
                                                                     ((tU8 *)&data)[3],
                                                                     ((tU8 *)&data)[4],
                                                                     ((tU8 *)&data)[5],
                                                                     ((tU8 *)&data)[6],
                                                                     ((tU8 *)&data)[7] ));

     /* the msg list sent by the NoC Viewer is contained in the data[0] byte (first byte of the payload) */
     NoC_msg_list = ((tU8 *)&data)[0];

     gpOS_semaphore_signal( can_handler->RxAccess_sem);
  }

  // should never reach this
  return -1;
}

/*****************************************************************************
   function implementations (scope: module-exported)
*****************************************************************************/

/********************************************//**
 * \brief Initialize the Can module
 *
 * \param CAN_Com
 * \param part Pointer to user partition
 * \param SOM
 *
 * \return gpOS_error_t
 ***********************************************/
gpOS_error_t CAN_start( tU8 CAN_Com, gpOS_partition_t *part, tBool SOM)
{
  gpOS_error_t error = gpOS_SUCCESS;

  if( can_handler != NULL)
  {
      error = gpOS_SUCCESS;
  }
  else
  {
     can_handler = gpOS_memory_allocate_p( part, sizeof( can_handler_t));

     /**< Allocate space for can handler */
     if( can_handler == NULL)
     {
       //return gpOS_FAILURE;
       error = gpOS_FAILURE;
     }

     can_handler->RxAccess_sem = NULL;
     can_handler->RxTask       = NULL;
     can_handler->TxTask       = NULL;

     can_handler->part   = part;

     can_handler->port   = CAN_Com;

     /* setup the filter in order to receive only the 0xa1 msg_id (on Object 1) */
     svc_can_setup_rx_objects( can_handler->port, 1, 0x0A1, 0x7FF, SOM);

     /* the messagelist is initialized to output all the 4 Noc Messages */
     NoC_msg_list = 0xF;

     GPS_DEBUG_MSG(("Can NMEA Mode\r\n"));

     nmea_can_outmsg_synchdlr_ptr = gnss_events_synch_handler_create();

     if( nmea_can_outmsg_synchdlr_ptr == GNSS_EVENTS_SYNCHANDLER_NONE)
     {
        error = gpOS_FAILURE;
     }

     if( gnss_fix_create_local_copy( (gpOS_partition_t *)part, &noc_outmsg_fixdata_ptr ) == GNSS_ERROR)
     {
        GPS_DEBUG_MSG(("[NoC] Error!\r\n"));
     }

     can_handler->RxAccess_sem = gpOS_semaphore_create_p( SEM_FIFO, part, 1);

     can_handler->TxTask = gpOS_task_create_p( part, NoC_tx_process, NULL, CANTX_TASK_WORKSPACE, 8, "Can NMEA Tx Task", gpOS_TASK_FLAGS_ACTIVE);
     can_handler->RxTask = gpOS_task_create_p( part, NoC_rx_process, NULL, CANRX_TASK_WORKSPACE, 8, "Can NMEA Rx Task", gpOS_TASK_FLAGS_ACTIVE);

     if(( can_handler->TxTask       == NULL) ||
        ( can_handler->RxTask       == NULL) ||
        ( can_handler->RxAccess_sem == NULL))
     {
        error = can_fail();
     }

  }

  return error;
}
/* End of file */
