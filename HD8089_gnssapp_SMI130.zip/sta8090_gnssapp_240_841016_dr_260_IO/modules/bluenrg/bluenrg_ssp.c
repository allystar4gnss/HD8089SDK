/**
* @file    bluenrg_ssp.c
* @author  AAS,AMS
* @version V1.0.1
* @date    March 10, 2014
* @brief   This file provides all the low level SPI API to access to BlueNRG module
* @details
*
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
* TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
* DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
* FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
* CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*
* THIS SOURCE CODE IS PROTECTED BY A LICENSE.
* FOR MORE INFORMATION PLEASE CAREFULLY READ THE LICENSE AGREEMENT FILE LOCATED
* IN THE ROOT DIRECTORY OF THIS FIRMWARE PACKAGE.
*
* <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
*
*/

/* Includes ------------------------------------------------------------------*/
#include "bluenrg_app.h"
#include "clock.h"
#include "hci.h"
#include "bluenrg_utils.h"
#include "bluenrg_ssp.h"

#include "lld_gpio.h"
#if defined BLUENRG_SPI
#include "lld_ssp.h"
#include "svc_ssp.h"
#endif
#if defined BLUENRG_MSP
#include "lld_msp.h"
#include "svc_msp.h"
#endif

// OS related
#include "gpOS.h"
#include "typedefs.h"
#include "clibs.h"
#include "mapping_sta8090.h"
#include "gnss_debug.h"

/** @addtogroup SDK_EVAL_STM32L
* @{
*/

/** @addtogroup SDK_EVAL_Spi                    SDK EVAL Spi
* @brief SPI functions implementation.
* @details This file implements the BlueNRG Library SPI interface functions.
* @{
*/
#if defined BLUENRG_SPI
#define SPI_CS_GPIO_PORT        GPIO0_REG_START_ADDR
#define SPI_CS_GPIO_PIN         LLD_GPIO_PIN17
#define SPI_CS_GPIO_AF          LLD_GPIO_ALTERNATE_MODE_A

#define SW_RST_GPIO_PORT        GPIO0_REG_START_ADDR
#define SW_RST_GPIO_PIN         LLD_GPIO_PIN20
#define SW_RST_GPIO_AF          LLD_GPIO_ALTERNATE_MODE_C

#define SPI_IRQ_GPIO_PORT       GPIO0_REG_START_ADDR
#define SPI_IRQ_GPIO_PIN        LLD_GPIO_PIN11
#define SPI_IRQ_GPIO_AF         LLD_GPIO_ALTERNATE_MODE_A

#define SPI_ACC_CS_GPIO_PORT    GPIO0_REG_START_ADDR
#define SPI_ACC_CS_GPIO_PIN     LLD_GPIO_PIN14
#define SPI_ACC_CS_GPIO_AF      LLD_GPIO_ALTERNATE_MODE_A

#define SPI_GYRO_CS_GPIO_PORT   GPIO0_REG_START_ADDR
#define SPI_GYRO_CS_GPIO_PIN    LLD_GPIO_PIN18
#define SPI_GYRO_CS_GPIO_AF     LLD_GPIO_ALTERNATE_MODE_A

#define SPI_PRES_CS_GPIO_PORT   GPIO0_REG_START_ADDR
#define SPI_PRES_CS_GPIO_PIN    LLD_GPIO_PIN15
#define SPI_PRES_CS_GPIO_AF     LLD_GPIO_ALTERNATE_MODE_A

#define SPI_MAG_CS_GPIO_PORT    GPIO0_REG_START_ADDR
#define SPI_MAG_CS_GPIO_PIN     LLD_GPIO_PIN0
#define SPI_MAG_CS_GPIO_AF      LLD_GPIO_ALTERNATE_NONE

#define BLUENRG_SPI_BUS_FREQ    1000000

#define SSP_REG_START_ADDR      0x52003000


static svc_ssp_com_handler_t *BlueNRG_handler = NULL;
#endif
#if defined BLUENRG_MSP
#define SPI_CS_GPIO_PORT          GPIO0_REG_START_ADDR
#define SPI_CS_GPIO_PIN           LLD_GPIO_PIN4
#define SPI_CS_GPIO_AF            LLD_GPIO_ALTERNATE_MODE_C//LLD_GPIO_ALTERNATE_MODE_A

#define SPI_CLK_GPIO_PORT         GPIO0_REG_START_ADDR
#define SPI_CLK_GPIO_PIN          LLD_GPIO_PIN20
#define SPI_CLK_GPIO_AF           LLD_GPIO_ALTERNATE_MODE_A

#define SPI_MISO_GPIO_PORT        GPIO0_REG_START_ADDR
#define SPI_MISO_GPIO_PIN         LLD_GPIO_PIN21
#define SPI_MISO_GPIO_AF          LLD_GPIO_ALTERNATE_MODE_A

#define SPI_MOSI_GPIO_PORT        GPIO0_REG_START_ADDR
#define SPI_MOSI_GPIO_PIN         LLD_GPIO_PIN5
#define SPI_MOSI_GPIO_AF          LLD_GPIO_ALTERNATE_MODE_A

#define SW_RST_GPIO_PORT          GPIO0_REG_START_ADDR
#define SW_RST_GPIO_PIN           LLD_GPIO_PIN23 //LLD_GPIO_PIN17
#define SW_RST_GPIO_AF            LLD_GPIO_ALTERNATE_MODE_C //LLD_GPIO_ALTERNATE_MODE_A

#define SPI_IRQ_GPIO_PORT         GPIO0_REG_START_ADDR
#define SPI_IRQ_GPIO_PIN          LLD_GPIO_PIN11
#define SPI_IRQ_GPIO_AF           LLD_GPIO_ALTERNATE_MODE_A

static svc_msp_com_handler_t *BlueNRG_handler = NULL;
#endif

/**
* @brief  Enable SPI CS
* @param  None
* @retval None
*/
void BlueNRG_spi_cs_enable(void *par)
{
#if defined( BLUENRG_MS )
  LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
#endif
}

/**
* @brief  Disable SPI CS
* @param  None
* @retval None
*/
void BlueNRG_spi_cs_disable(void *par)
{
#if defined( BLUENRG_MS )
  LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
#endif
}

/**
  * @brief  Power down the BlueNRG (reset).
  * @param  None
  * @retval None
  */
void BlueNRG_Power_Down(void)
{
#if defined( BLUENRG_MS )
  LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN);
#endif
}/* end BlueNRG_Power_Down() */

/**
  * @brief  Power up the BlueNRG (release reset).
  * @param  None
  * @retval None
  */
void BlueNRG_Power_Up(void)
{
#if defined( BLUENRG_MS )
  LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN);
#if defined BLUENRG_SPI
  gpOS_task_delay( 7* gpOS_timer_ticks_per_msec());
#elif defined BLUENRG_MSP
  gpOS_task_delay( 7* gpOS_timer_ticks_per_msec());
#endif
#endif
}/* end BlueNRG_Power_Up() */

/**
* @brief  Return SPI IRQ pin value
* @param  None
* @retval SPI IRQ pin value
*/
tU8 SdkEvalSPI_Irq_Pin(void)
{
  tU8 ret = 0;
#if defined( BLUENRG_MS )
  ret = LLD_GPIO_GetPinState((LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN);
#endif
  return ret;
}/* end SdkEvalSPI_Irq_Pin() */

/**
* @brief  Initializes the SPI
* @param  xSpiMode: SPI mode - GPIO (polling) or EXTI (IRQ)
* @retval status
*/
tU8 BlueNRG_SpiInit(void)
{
#if defined( BLUENRG_MS )
#if defined BLUENRG_SPI
  svc_ssp_comconfig_t BlueNRG_spicom_init_config;

  BlueNRG_spicom_init_config.out_clk = BLUENRG_SPI_BUS_FREQ;
  BlueNRG_spicom_init_config.data_size = LLD_SSP_DATA_BITS_8;
  BlueNRG_spicom_init_config.clk_phase = LLD_SSP_CLK_FALLING_EDGE;
  BlueNRG_spicom_init_config.clk_pol = LLD_SSP_CLK_POL_IDLE_LOW;
  BlueNRG_spicom_init_config.pre_cb = NULL;
  BlueNRG_spicom_init_config.pre_cb_param = NULL;
  BlueNRG_spicom_init_config.post_cb = NULL;
  BlueNRG_spicom_init_config.post_cb_param = NULL;
  BlueNRG_spicom_init_config.ctrl_len = 0;
  BlueNRG_spicom_init_config.wait_state = 0;
  BlueNRG_spicom_init_config.duplex = 0;

  //BlueNRG_spicom_init_config_ptr = &BlueNRG_spicom_init_config;
  //BlueNRG_handler = svc_ssp_create_com(0, LLD_SSP_INTERFACE_MOTOROLA_SPI, BLUENRG_SPI_BUS_FREQ, LLD_SSP_DATA_BITS_8, NULL/*(svc_ssp_hook_t)BlueNRG_spi_cs_enable*/, NULL, NULL/*(svc_ssp_hook_t)BlueNRG_spi_cs_disable*/, NULL);
  BlueNRG_handler = svc_ssp_create_com_config(0, LLD_SSP_INTERFACE_MOTOROLA_SPI, BlueNRG_spicom_init_config);

  /*!< Configure BlueNRG reset line */
  LLD_GPIO_SetControlMode((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN, (LLD_GPIO_ModeTy)SW_RST_GPIO_AF);
  LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN);
  LLD_GPIO_SetDirection((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_OUTPUT);
  BlueNRG_Power_Down();

  /*!< Configure SPI pins: CS pin */
  LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_CS_GPIO_AF);
  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_OUTPUT);
  LLD_GPIO_SetStateHigh( (LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);

  /*!< Configure and manage SPI CS pins for other sensors on the SDB */
  LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_ACC_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_ACC_CS_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_ACC_CS_GPIO_AF);
  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_ACC_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_ACC_CS_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_OUTPUT);
  LLD_GPIO_SetStateHigh( (LLD_GPIO_idTy)SPI_ACC_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_ACC_CS_GPIO_PIN);

  LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_GYRO_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_GYRO_CS_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_GYRO_CS_GPIO_AF);
  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_GYRO_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_GYRO_CS_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_OUTPUT);
  LLD_GPIO_SetStateHigh( (LLD_GPIO_idTy)SPI_GYRO_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_GYRO_CS_GPIO_PIN);

  LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_PRES_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_PRES_CS_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_PRES_CS_GPIO_AF);
  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_PRES_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_PRES_CS_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_OUTPUT);
  LLD_GPIO_SetStateHigh( (LLD_GPIO_idTy)SPI_PRES_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_PRES_CS_GPIO_PIN);

  LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_MAG_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_MAG_CS_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_MAG_CS_GPIO_AF);
  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_MAG_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_MAG_CS_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_OUTPUT);
  LLD_GPIO_SetStateHigh( (LLD_GPIO_idTy)SPI_MAG_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_MAG_CS_GPIO_PIN);

  /*!< Configure SPI pins: IRQ pin */
  LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_IRQ_GPIO_AF);
  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_INPUT);
  LLD_GPIO_SetInterruptType ((LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN, (LLD_GPIO_IntTy)LLD_GPIO_RISE_EDGE_INT);

  GPS_DEBUG_MSG(("[bluenrg] SPI settings\r\n"));
#endif
#if defined BLUENRG_MSP
    svc_msp_comconfig_t BlueNRG_mspcom_init_config;

    BlueNRG_mspcom_init_config.out_clk = 125000;
    BlueNRG_mspcom_init_config.data_size = LLD_MSP_BITS4ELEM_8;
    BlueNRG_mspcom_init_config.spi_clk_mode = LLD_MSP_SPICLOCKMDODE_HALF_DELAY;
    BlueNRG_mspcom_init_config.frame_period = 8;
    BlueNRG_mspcom_init_config.pre_cb = NULL;
    BlueNRG_mspcom_init_config.pre_cb_param = NULL;
    BlueNRG_mspcom_init_config.post_cb = NULL;
    BlueNRG_mspcom_init_config.post_cb_param = NULL;
    // Open MSP port
    svc_msp_open_port( 0, gpOS_INTERRUPT_NOPRIORITY);

    LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_CS_GPIO_AF);
    LLD_GPIO_SetDirectionOutput( (LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
    LLD_GPIO_SetStateHigh( (LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);

    LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_CLK_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CLK_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_CLK_GPIO_AF);
    //LLD_GPIO_SetStateLow( (LLD_GPIO_idTy)MSP_SPI_CLK_GPIO_PORT, (LLD_GPIO_PinTy)MSP_SPI_CLK_GPIO_PIN);
    LLD_GPIO_SetDirectionOutput( (LLD_GPIO_idTy)SPI_CLK_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CLK_GPIO_PIN);

    LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_MISO_GPIO_PORT, (LLD_GPIO_PinTy)SPI_MISO_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_MISO_GPIO_AF);
    //LLD_GPIO_SetStateHigh( MSP_SPI_MISO_GPIO_PORT, MSP_SPI_MISO_GPIO_PIN);
    LLD_GPIO_SetDirectionInput( (LLD_GPIO_idTy)SPI_MISO_GPIO_PORT, (LLD_GPIO_PinTy)SPI_MISO_GPIO_PIN);

     LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_MOSI_GPIO_PORT, (LLD_GPIO_PinTy)SPI_MOSI_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_MOSI_GPIO_AF);
    //LLD_GPIO_SetStateHigh( MSP_SPI_MOSI_GPIO_PORT, MSP_SPI_MOSI_GPIO_PIN);
    LLD_GPIO_SetDirectionOutput( (LLD_GPIO_idTy)SPI_MOSI_GPIO_PORT, (LLD_GPIO_PinTy)SPI_MOSI_GPIO_PIN);

    if( BlueNRG_handler == NULL)
    {
      //BlueNRG_handler = svc_msp_create_com( 0, SVC_MSP_PROTOCOL_SPI, 125000/*20000*/, LLD_MSP_BITS4ELEM_8, NULL, NULL, NULL, NULL);
      BlueNRG_handler = svc_msp_create_com_config( 0, SVC_MSP_PROTOCOL_SPI, BlueNRG_mspcom_init_config);
    }

  /*!< Configure BlueNRG reset line */
  LLD_GPIO_SetControlMode((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN, (LLD_GPIO_ModeTy)SW_RST_GPIO_AF);
  LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN);
  LLD_GPIO_SetDirection((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_OUTPUT);
  BlueNRG_Power_Down();

  /*!< Configure SPI pins: IRQ pin */
  LLD_GPIO_SetControlMode( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN, (LLD_GPIO_ModeTy)SPI_IRQ_GPIO_AF);
  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_INPUT);
  LLD_GPIO_SetInterruptType ((LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN, (LLD_GPIO_IntTy)LLD_GPIO_RISE_EDGE_INT);

  GPS_DEBUG_MSG(("[bluenrg] MSP settings\r\n"));
#endif
#endif
  return(0);
}/* end SdkEvalSpiInit() */

/**
  * @brief  Set GPIO pin in Hi-Z state.
  * @param  GPIOx: GPIO port
  *         GPIO_Pin: GPIo pin
  * @retval None
  */
static void GPIO_SetHiZ(LLD_GPIO_idTy gpio_port, LLD_GPIO_PinTy gpio_pin)
{
#if defined( BLUENRG_MS )
  LLD_GPIO_SetDirection(gpio_port, gpio_pin, LLD_GPIO_OUTPUT);
  LLD_GPIO_SetStateHigh(gpio_port, gpio_pin);
#endif
}/* end GPIO_SetHiZ() */

/**
  * @brief  Disable SPI
  * @param  None
  * @retval None
  */
void BlueNRG_SpiDisable(void)
{
#if defined( BLUENRG_MS )
  GPIO_SetHiZ((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);

  GPIO_SetHiZ((LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN);
  LLD_GPIO_SetInterruptType ((LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, SPI_IRQ_GPIO_PIN, LLD_GPIO_DISABLED_INT);

  gpOS_interrupt_disable(VIC_GPIO_0_LINE);
  gpOS_interrupt_uninstall(VIC_GPIO_0_LINE);
#endif
}/* end SdkEvalSpiDisable() */

/**
  * @brief  Reset the BlueNRG
  * @param  None
  * @retval None
  */
void BlueNRG_RST(void)
{
#if defined( BLUENRG_MS )
  BlueNRG_Power_Down();
  gpOS_task_delay( 5* gpOS_timer_ticks_per_msec());
  BlueNRG_Power_Up();
  gpOS_task_delay( 5* gpOS_timer_ticks_per_msec());
#endif
}/* end BlueNRG_RST() */

/**
  * @brief  Reports if the BlueNRG has data for the host micro.
  * @param  None
  * @retval TRUE if data are present, FALSE otherwise
  */
tU8 BlueNRG_DataPresent(void)
{
  tU8 ret = FALSE;
#if defined( BLUENRG_MS )
  if (LLD_GPIO_GetPinState((LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN) == LLD_GPIO_HIGH)
    ret = TRUE;
  else
    ret = FALSE;
#endif
  return ret;
} /* end BlueNRG_DataPresent() */

/**
* @brief  Disable SPI IRQ
* @param  None
* @retval None
*/
void Disable_SPI_IRQ(void)
{
#if defined( BLUENRG_MS )
  gpOS_interrupt_disable(VIC_GPIO_0_LINE);
#endif
}/* end Disable_SPI_IRQ() */

/**
* @brief  Enable SPI IRQ
* @param  None
* @retval None
*/
void Enable_SPI_IRQ(void)
{
#if defined( BLUENRG_MS )
  gpOS_interrupt_enable(VIC_GPIO_0_LINE);
#endif
}/* end Enable_SPI_IRQ() */

/**
* @brief  Clear Pending SPI IRQ
* @param  None
* @retval None
*/
void Clear_SPI_IRQ(void)
{
#if defined( BLUENRG_MS )
  LLD_GPIO_ClearInterrupt((LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN);
#endif
}/* end Clear_SPI_IRQ() */

/**
* @brief  Clear Exti line for SPI IRQ
* @param  None
* @retval None
*/
void Clear_SPI_EXTI_Flag(void)
{
}/* end Clear_SPI_EXTI_Flag() */

/**
  * @brief  Activate internal bootloader using pin.
  * @param  None
  * @retval None
  */
void BlueNRG_HW_Bootloader(void)
{
#if defined( BLUENRG_MS )
  Disable_SPI_IRQ();

  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_OUTPUT);
  LLD_GPIO_SetStateHigh( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN);

  LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN);
  gpOS_task_delay( 5* gpOS_timer_ticks_per_msec());
  LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SW_RST_GPIO_PORT, (LLD_GPIO_PinTy)SW_RST_GPIO_PIN);

#if defined BLUENRG_SPI
  gpOS_task_delay( 5* gpOS_timer_ticks_per_msec());
#elif defined BLUENRG_MSP
  gpOS_task_delay( 7* gpOS_timer_ticks_per_msec());
#endif

  /* Restore IRQ port configuration. */
  LLD_GPIO_SetDirection( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN, (LLD_GPIO_DirectionTy)LLD_GPIO_INPUT);
  LLD_GPIO_SetStateLow( (LLD_GPIO_idTy)SPI_IRQ_GPIO_PORT, (LLD_GPIO_PinTy)SPI_IRQ_GPIO_PIN);

  Enable_SPI_IRQ();
#endif

  gpOS_task_delay(5*gpOS_timer_ticks_per_msec());
}

/**
* @brief  Read from BlueNRG SPI buffer and store data into local buffer
* @param  buffer:    buffer where data from SPI are stored
*         buff_size: buffer size
* @retval number of read bytes
*/
tU8 BlueNRG_SPI_Read_All(tU8 *buffer, tU8 buff_size)
{
  tU8 len = 0;

#if defined( BLUENRG_MS )
#if defined BLUENRG_SPI
    tU16 byte_count;
    tU8 i = 0;

    tU8 header_master[5] = {0x0b, 0x00, 0x00, 0x00, 0x00};
    tU8 header_slave[5];
    tU8 buffer_out[HCI_READ_PACKET_SIZE];

    LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);

    svc_ssp_write(BlueNRG_handler, header_master, 5, header_slave, gpOS_TIMEOUT_INFINITY);

    if (header_slave[0] == 0x02)
    {
      byte_count = (header_slave[4]<<8)|header_slave[3];
      if (byte_count > 0)
      {
        // avoid to read more data that size of the buffer
        if (byte_count > buff_size)
        {
          byte_count = buff_size;
        }
        for(i = 0; i < byte_count; i++)
        {
          buffer_out[i]= 0xFF;
        }
        len = byte_count;
        svc_ssp_write(BlueNRG_handler, buffer_out, byte_count, (tVoid*)buffer, gpOS_TIMEOUT_INFINITY);
      }
    }

    LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
#endif
#if defined BLUENRG_MSP
    tU16 byte_count;
    tU8 i = 0;

    tU8 header_master[5] = {0x0b, 0x00, 0x00, 0x00, 0x00};
    tU8 header_slave[5];
    tU8 buffer_out[HCI_READ_PACKET_SIZE];

    LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);

    svc_msp_write(BlueNRG_handler, header_master, 5, header_slave, gpOS_TIMEOUT_INFINITY);

    if (header_slave[0] == 0x02)
    {
      byte_count = (header_slave[4]<<8)|header_slave[3];
      if (byte_count > 0)
      {
        // avoid to read more data that size of the buffer
        if (byte_count > buff_size)
        {
          byte_count = buff_size;
        }
        for(i = 0; i < byte_count; i++)
        {
          buffer_out[i]= 0xFF;
        }
        len = byte_count;
        svc_msp_write(BlueNRG_handler, buffer_out, byte_count, (tVoid*)buffer, gpOS_TIMEOUT_INFINITY);
      }
    }

    LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
#endif
#endif

  return len;
}/* end BlueNRG_SPI_Read_All() */


/**
* @brief  Write data from local buffer to SPI
* @param  data1:    first data buffer to be written, used to send header of higher
*                   level protocol
*         data2:    second data buffer to be written, used to send payload of higher
*                   level protocol
*         Nb_bytes1: size of header to be written
*         Nb_bytes2: size of payload to be written
* @retval Number of payload bytes that has been sent. If 0 all bytes in the header
*/
tS16 BlueNRG_SPI_Write(tU8* data1, tU8* data2, tU16 Nb_bytes1, tU16 Nb_bytes2)
{
  tS16 result = 0;

#if defined( BLUENRG_MS )
#if defined BLUENRG_SPI
    tU8 i;
    tU16 tx_bytes;
    tU8 rx_bytes;
    tU8 buffer_out[HCI_READ_PACKET_SIZE];
    tU8 buffer_in[HCI_READ_PACKET_SIZE];

    unsigned char header_master[5] = {0x0a, 0x00, 0x00, 0x00, 0x00};
    unsigned char header_slave[5]  = {0x00};

    for(i = 0; i< HCI_READ_PACKET_SIZE; i++)
    {
      buffer_out[i] = 0;
    }

    Disable_SPI_IRQ();

    LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);

    svc_ssp_write(BlueNRG_handler, header_master, 5, header_slave, gpOS_TIMEOUT_INFINITY);

    if(header_slave[0] != 0x02)
    {
      result = -1;
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
      Enable_SPI_IRQ();
      return result; // BlueNRG not awake.
    }

    rx_bytes = header_slave[1];

    if(rx_bytes < Nb_bytes1)
    {
      result = -2;
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
      Enable_SPI_IRQ();
      return result; // BlueNRG .
    }

    for(i = 0; i < Nb_bytes1; i++)
    {
      buffer_out[i] = *(data1 + i);
      buffer_in[i] = 0;
    }

    svc_ssp_write(BlueNRG_handler, buffer_out, Nb_bytes1, buffer_in, gpOS_TIMEOUT_INFINITY);

    for(i = 0; i< HCI_READ_PACKET_SIZE; i++)
    {
       buffer_out[i] = 0;
    }

    rx_bytes -= Nb_bytes1;

    if(Nb_bytes2 > rx_bytes){
      tx_bytes = rx_bytes;
    }
    else{
      tx_bytes = Nb_bytes2;
    }

    for(i = 0; i < tx_bytes; i++)
    {
      buffer_out[i] = *(data2 + i);
      buffer_in[i] = 0;
    }

    svc_ssp_write(BlueNRG_handler, buffer_out, tx_bytes, buffer_in, gpOS_TIMEOUT_INFINITY);

    result = tx_bytes;

    LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
    Enable_SPI_IRQ();
#endif
#if defined BLUENRG_MSP
    tU8 i;
    //tS16 result = 0;
    tU16 tx_bytes;
    tU8 rx_bytes;
    tU8 buffer_out[HCI_READ_PACKET_SIZE];
    tU8 buffer_in[HCI_READ_PACKET_SIZE];

    unsigned char header_master[5] = {0x0a, 0x00, 0x00, 0x00, 0x00};
    unsigned char header_slave[5]  = {0x00};

    for(i = 0; i< HCI_READ_PACKET_SIZE; i++)
    {
      buffer_out[i] = 0;
    }

    Disable_SPI_IRQ();

    LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);

    svc_msp_write(BlueNRG_handler, header_master, 5, header_slave, gpOS_TIMEOUT_INFINITY);

    if(header_slave[0] != 0x02)
    {
      result = -1;
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
      Enable_SPI_IRQ();
      return result; // BlueNRG not awake.
    }

    rx_bytes = header_slave[1];

    if(rx_bytes < Nb_bytes1)
    {
      result = -2;
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
      Enable_SPI_IRQ();
      return result; // BlueNRG .
    }

    for(i = 0; i < Nb_bytes1; i++)
    {
      buffer_out[i] = *(data1 + i);
      buffer_in[i] = 0;
    }

    svc_msp_write(BlueNRG_handler, buffer_out, Nb_bytes1, buffer_in, gpOS_TIMEOUT_INFINITY);

    for(i = 0; i< HCI_READ_PACKET_SIZE; i++)
    {
       buffer_out[i] = 0;
    }

    rx_bytes -= Nb_bytes1;

    if(Nb_bytes2 > rx_bytes){
      tx_bytes = rx_bytes;
    }
    else{
      tx_bytes = Nb_bytes2;
    }

    for(i = 0; i < tx_bytes; i++)
    {
      buffer_out[i] = *(data2 + i);
      buffer_in[i] = 0;
    }

    svc_msp_write(BlueNRG_handler, buffer_out, tx_bytes, buffer_in, gpOS_TIMEOUT_INFINITY);

    result = tx_bytes;

    LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SPI_CS_GPIO_PORT, (LLD_GPIO_PinTy)SPI_CS_GPIO_PIN);
    Enable_SPI_IRQ();
#endif
#endif

  return result;
}/* end BlueNRG_SPI_Write() */
/******************* (C) COPYRIGHT 2014 STMicroelectronics *****END OF FILE****/
