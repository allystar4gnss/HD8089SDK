/*!
 * @file    extras_plugins.c
 * @brief   Plugin for extra features
 */

/*****************************************************************************
   includes
*****************************************************************************/

#include <math.h>
#include "clibs.h"
#include "gpOS.h"
#include "gnssapp.h"
#include "gnssapp_plugins.h"
#include "gnss_debug.h"
#include "sw_config.h"
#include "nmea_support.h"
#include "gnss_events.h"
#include "sw_config.h"

#include "logger.h"
#include "odometer.h"
#include "geofencing.h"

/*****************************************************************************
   external declarations
*****************************************************************************/

/*****************************************************************************
   defines and macros (scope: module-local)
*****************************************************************************/

#define EXTRAS_TASK_WS_SIZE       4096
#define EXTRAS_TASK_PRIORITY      5

/*****************************************************************************
   typedefs and structures (scope: module-local)
*****************************************************************************/

/*****************************************************************************
   global variable definitions  (scope: module-exported)
*****************************************************************************/

/*****************************************************************************
   global variable definitions (scope: module-local)
*****************************************************************************/

static gnss_events_synch_handler_t *extras_synchdlr_ptr;
static gpOS_task_t* extras_task;
static gpOS_partition_t *extras_part;
static boolean_t extras_logger_enabled = FALSE;
static boolean_t extras_geofencing_enabled = FALSE;
static boolean_t extras_odometer_enabled = FALSE;
static gpOS_wakelockid_t extras_wakelock_id;
static nmea_error_t extras_plugin_init(gpOS_partition_t *part);
/*****************************************************************************
   function prototypes (scope: module-local)
*****************************************************************************/

static gpOS_task_exit_status_t  extras_process( gpOS_task_param_t );

/*****************************************************************************
   function implementations (scope: module-local)
*****************************************************************************/

static gpOS_error_t extras_plugin_handle_output_msg( void *param)
{
  gpOS_error_t result;

  result = odometer_nmea_outmsg_transmit(param);
  if(result == gpOS_SUCCESS)
  {
    result = geofencing_nmea_outmsg_transmit(param);
    if(result == gpOS_SUCCESS)
    {
      result = logger_nmea_outmsg_transmit(param);
    }
    else
    {
      /**/
    }
  }
  else
  {
    /**/
  }

  return  result;
}

static tInt extras_plugin_cmdif_parse( tChar *input_cmd_msg, tUInt cmd_size, tChar *cmd_par)
{
  tInt result;

  result = logger_nmea_cmdif_parse(input_cmd_msg,cmd_size,cmd_par);

  if(result == (tInt)NMEA_NOT_VALID)
  {
    result = geofencing_nmea_cmdif_parse(input_cmd_msg,cmd_size,cmd_par);

    if(result == (tInt)NMEA_NOT_VALID)
    {
      result = odometer_nmea_cmdif_parse(input_cmd_msg,cmd_size,cmd_par);
    }
    else
    {
      /**/
    }
  }
  else
  {
    /**/
  }

  return result;
}

static nmea_error_t extras_plugin_init(gpOS_partition_t *part)
{
  nmea_error_t result = NMEA_OK;

  {
    tUInt cfg_temp = 0U;

    if(sw_config_get_param( CURRENT_CONFIG_DATA, LOGGER_CFG2_ID , &cfg_temp) == GNSS_NO_ERROR)
    {
      if((cfg_temp & 0x1U) != 0U)
      {
        extras_logger_enabled = TRUE;
      }
      else
      {
        /**/
        GPS_DEBUG_MSG(("[extras] logger enabled 0x%08x\r\n",cfg_temp));
      }
    }
    else
    {
      result = NMEA_ERROR;
    }

    if(sw_config_get_param( CURRENT_CONFIG_DATA, GEOFENCING_CFG0_ID , &cfg_temp) == GNSS_NO_ERROR)
    {
      if((cfg_temp & 0x1U) != 0U)
      {
        extras_geofencing_enabled = TRUE;
      }
      else
      {
        /**/
        GPS_DEBUG_MSG(("[extras] geofencing enabled 0x%08x\r\n",cfg_temp));
      }
    }
    else
    {
      result = NMEA_ERROR;
    }

    if(sw_config_get_param( CURRENT_CONFIG_DATA, ODOMETER_CFG0_ID , &cfg_temp) == GNSS_NO_ERROR)
    {
      if((cfg_temp & 0x1U) != 0U)
      {
        extras_odometer_enabled = TRUE;
      }
      else
      {
        /**/
        GPS_DEBUG_MSG(("[extras] odometer enabled 0x%08x\r\n",cfg_temp));
      }
    }
    else
    {
      result = NMEA_ERROR;
    }
  }

  if((extras_odometer_enabled == TRUE) || (extras_geofencing_enabled == TRUE) || (extras_logger_enabled == TRUE))
  {
    extras_part = part;
    if(gpOS_wakelock_register(&extras_wakelock_id) == gpOS_FAILURE)
    {
      /**/
    }
    else
    {
      /**/
    }
    extras_task = gpOS_task_create_p( part, extras_process, NULL, EXTRAS_TASK_WS_SIZE, EXTRAS_TASK_PRIORITY, "EXTRAS Process", gpOS_TASK_FLAGS_ACTIVE);

    if( extras_task == NULL )
    {
      if(gpOS_task_delete( extras_task ) == gpOS_FAILURE)
      {
        /**/
      }
      else
      {
        /**/
      }
      ERROR_MSG( "[extras][init] Error creating OS items.\r\n" );
      result = NMEA_ERROR;
    }
    else
    {
      extras_synchdlr_ptr = gnss_events_synch_handler_create();

      if ( extras_synchdlr_ptr == GNSS_EVENTS_SYNCHANDLER_NONE )
      {
        ERROR_MSG( "[extras][init] Event Create Error\r\n" );
        result = NMEA_ERROR;
      }
      else
      {
        if(extras_odometer_enabled == TRUE)
        {
          tUInt odo_cfg;
          if(sw_config_get_param( CURRENT_CONFIG_DATA, ODOMETER_CFG0_ID , &odo_cfg) == GNSS_NO_ERROR)
          {
            if(odometer_init(part,&odo_cfg) == gpOS_FAILURE)
            {
              ERROR_MSG( "[extras][init] Odometer Init Error\r\n" );
              result = NMEA_ERROR;
            }
            else
            {
              /**/
            }
          }
          else
          {
            result = NMEA_ERROR;
          }
        }
        else
        {
          /**/
        }

        if(result == NMEA_OK)
        {
          if(extras_geofencing_enabled == TRUE)
          {
            tUInt geofencing_config[GEOFENCING_CONFIG_PARAMS_N];

            if(sw_config_get_param( CURRENT_CONFIG_DATA, GEOFENCING_CFG0_ID , &geofencing_config[0U]) == GNSS_NO_ERROR)
            {
              if(sw_config_get_param( CURRENT_CONFIG_DATA, GEOFENCING_CFG1_ID , &geofencing_config[1U]) == GNSS_NO_ERROR)
              {
                if(geofencing_init(part,geofencing_config) == gpOS_FAILURE)
                {
                  ERROR_MSG( "[extras][init] Geofencing Init Error\r\n" );
                  result = NMEA_ERROR;
                }
                else
                {
                  tUInt p,i;
                  tDouble geo_cfg_param[GEO_MAX_CFG_POINT_PARAMS];

                  for(p=0U;p<GEO_MAX_CFG_POINTS;p++)
                  {
                    for(i=0U;i<GEO_MAX_CFG_POINT_PARAMS;i++)
                    {
                      tUInt temp;
                      tInt CFG_ID = GEOFENCING_P0_LAT_ID;

                      temp = (p * GEO_MAX_CFG_POINT_PARAMS);
                      CFG_ID += (tInt)temp;
                      CFG_ID += (tInt)i;
                      if(sw_config_get_param( CURRENT_CONFIG_DATA, CFG_ID , &geo_cfg_param[i]) == GNSS_ERROR)
                      {
                        result = NMEA_ERROR;
                      }
                      else
                      {
                         /**/
                         GPS_DEBUG_MSG(("[geofencing][cfg] %d %lf\r\n",i,geo_cfg_param[i]));
                      }
                    }

                    if(result == NMEA_OK)
                    {
                      geofencing_set_point(p,geo_cfg_param[0U],geo_cfg_param[1U],geo_cfg_param[2U]);
                      GPS_DEBUG_MSG(("[geofencing][set point] %d %lf %lf %lf\r\n",p,geo_cfg_param[0U],geo_cfg_param[1U],geo_cfg_param[2U]));
                    }
                    else
                    {
                      /**/
                    }
                  }
                }
              }
              else
              {
                result = NMEA_ERROR;
              }
            }
            else
            {
              result = NMEA_ERROR;
            }
          }
          else
          {
            /**/
          }
        }
        else
        {
          /**/
        }
      }
    }
  }
  else
  {
    /**/
  }

  return ( result );
}

static gpOS_error_t extras_plugin_api( const gnssapp_plugins_cmd_t cmd, gnssapp_plugins_cmd_param_t *param)
{
  gpOS_error_t error = gpOS_SUCCESS;

  switch( cmd)
  {
    case GNSSAPP_PLUGINS_CMD_INIT:
      if( extras_plugin_init( (gpOS_partition_t *)param->data_ptr) == NMEA_ERROR) /*lint !e9079 !e9076 !e9087 conversion from pointer to pointer to other type */
      {
        error = gpOS_FAILURE;
      }
      break;

    case GNSSAPP_PLUGINS_CMD_GETVER:
      break;

    case GNSSAPP_PLUGINS_CMD_START:
      break;

    case GNSSAPP_PLUGINS_CMD_SUSPEND:
      break;

    case GNSSAPP_PLUGINS_CMD_CUSTOM:

    default:
      error = gpOS_FAILURE;
      break;
  }

  return error;
}/*lint !e818*/

/*****************************extras_plugin_cmdif_parse************************************************
   function implementations (scope: module-exported)
*****************************************************************************/

gnssapp_plugins_handler_t extras_gnssapp_plugin_handler =/*lint !e9075*/
{
  NULL,
  GNSSAPP_PLUGINS_ID_EXTRAS,
  extras_plugin_api,
  extras_plugin_cmdif_parse,
  extras_plugin_handle_output_msg,
  (gnssapp_plugins_stbin_cmdif_callback_t)NULL,
  (gnssapp_plugins_stbin_outmsg_callback_t)NULL
};

static gpOS_task_exit_status_t extras_process( gpOS_task_param_t p )
{
  gnss_events_event_id_t extras_syncevent_id = GNSS_EVENTID_FIXREADY;
  tInt week_n;
  gpOS_clock_t fix_clock;
  tDouble tow;
  gnss_time_t utc_time;
  position_t pos;
  velocity_t vel;
  tUInt odometer = 0;
  tUInt odometer_timestamp;
  fix_status_t fix_status = NO_FIX;
  time_validity_t time_validity;
  tDouble n_cov, e_cov, v_cov,sigma,ehpe;
  raw_measure_list_t raw_meas, *raw_meas_ptr;
  logger_input_data_t logger_input_data;
  tUInt quality_status;
  tUInt geo_status = 0;
  tUInt logger_config[LOGGER_CONFIG_PARAMS_N];
  tUInt *logger_config_ptr;
  /*}}}  */

  if(extras_logger_enabled == TRUE)
  {
    if(sw_config_get_param( CURRENT_CONFIG_DATA, LOGGER_CFG0_ID , &logger_config[0U]) == GNSS_NO_ERROR)
    {
      if(sw_config_get_param( CURRENT_CONFIG_DATA, LOGGER_CFG1_ID , &logger_config[1U]) == GNSS_NO_ERROR)
      {
        if(sw_config_get_param( CURRENT_CONFIG_DATA, LOGGER_CFG2_ID , &logger_config[2U]) == GNSS_NO_ERROR)
        {
          if(sw_config_get_param( CURRENT_CONFIG_DATA, LOGGER_CFG3_ID , &logger_config[3U]) == GNSS_NO_ERROR)
          {
            logger_config_ptr = &logger_config[0U];
          }
          else
          {
            logger_config_ptr = NULL;
          }
        }
        else
        {
          logger_config_ptr = NULL;
        }
      }
      else
      {
        logger_config_ptr = NULL;
      }
    }
    else
    {
      logger_config_ptr = NULL;
    }

    if(logger_init(extras_part, logger_config_ptr) == gpOS_FAILURE)
    {
      ERROR_MSG( "[extras][init] Logger Init Error\r\n" );
      //return ( NMEA_ERROR );
    }
  }

  gnss_events_install( extras_syncevent_id, extras_synchdlr_ptr );


  while (TRUE == TRUE)
  {
    gnss_events_wait( extras_syncevent_id, extras_synchdlr_ptr ); // this works only for GNSs not for DR
    gnss_fix_store_local( NULL );
    gnss_fix_read_claim();
    gnss_fix_get_time_local( &week_n, &tow, &fix_clock, NULL );
    gnss_fix_get_fil_pos_vel_local(&pos, &vel, NULL);
    fix_status = gnss_fix_get_pos_status_local( NULL );
    time_validity = gnss_fix_get_time_validity_local(NULL);
    gnss_fix_get_position_covariance_local( &n_cov, &e_cov, &v_cov, NULL );
    ehpe = gnss_fix_get_ehpe();
    raw_meas_ptr = gnss_fix_get_raw_measurements_local( NULL );
    _clibs_memcpy(&raw_meas,raw_meas_ptr,sizeof(raw_measure_list_t));
    gnss_fix_read_release();
    {
      gnss_time_t gnss_time = {0};

      gnss_time.week_n = week_n;
      gnss_time.tow = tow;
      utc_time = gnss_time_to_utc_time( gnss_time, gnss_fix_get_time_sat_type_local( NULL ) );
    }

    if(gpOS_wakelock_acquire(extras_wakelock_id) == gpOS_FAILURE)
    {
      /**/
    }
    else
    {
      /**/
    }

    if(extras_odometer_enabled == TRUE)
    {
      odometer_update_data(&utc_time,&pos,&vel,fix_status);
      if(odometer_get_data(ODOMETER_TOTAL,&odometer_timestamp,&odometer) == GNSS_ERROR)
      {
        odometer = 0;
      }
      else
      {
        /**/
      }
    }
    else
    {
      /**/
    }

    if(extras_geofencing_enabled == TRUE)
    {
      sigma = sqrt(n_cov + e_cov);
      geo_status = (tUInt)geofencing_update_data(&utc_time,&pos,sigma,fix_status);
    }
    else
    {
      /**/
    }

    if(extras_logger_enabled == TRUE)
    {
      tDouble temp;
      logger_input_data.utc_time = utc_time;
      logger_input_data.fix_status = fix_status;
      logger_input_data.pos = pos;
      logger_input_data.vel = vel;
      logger_input_data.odometer = odometer;
      logger_input_data.time_validity = time_validity;
      logger_input_data.geo_status = geo_status;
      temp = (ehpe + 0.5);
      quality_status = (tUInt)temp;
      logger_input_data.quality_status = quality_status;

      logger_write_data(&logger_input_data);

      //logger_write_sat_data(&utc_time,time_validity,fix_status,&raw_meas);

      //GPS_DEBUG_MSG(("[loger] raw meas size %d\r\n)",sizeof(raw_measure_list_t) ));
    }
    else
    {
      /**/
    }

    if(gpOS_wakelock_release(extras_wakelock_id,gpOS_TIMEOUT_INFINITY) == gpOS_FAILURE)
    {
      /**/
    }
    else
    {
      /**/
    }
  }
}/*lint !e818*/

