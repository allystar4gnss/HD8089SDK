/*!
 * slld_3dacc.h
 * Defines the interface for 3Dcc driver.
 * \date 02/01/2017
 */
#ifndef SLLD_3DACC_H
#define SLLD_3DACC_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "lld_gpio.h"
#include "slld_common.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define SLLD_3D6DACC_WHO_AM_I               0x0FU
#define SLLD_3DACC_ID                       0x3AU   //For AIS326DQ/LIS3LV02DQ
#define SLLD_3DACC_ID_1                     0x32U   //AIS328D0
#define SLLD_6DACC_ASM330LXH_ID             0x61U   //ASM330LXH
#define SLLD_6DACC_LSM6DS3_ID               0x69U   //LSM6DS3
#define SLLD_6DACC_LSM6DSM_ID               0x6AU   //LSM6DSM
#define SLLD_6DACC_LSM6DSR_ID               0x6BU   //LSM6DSR

#define SLLD_3DACC_CTRL_REG1                0x20U
#define SLLD_3DACC_NORNAL_MODE_ENABLE       0x20U   /*(1<<5)*/
#define SLLD_3DACC_SELF_TEST_MODE_BIT       0x08U   /*(1<<3)*/
#define SLLD_3DACC_INCREMENT_ADDRESS        0x40U

#define SLLD_3D6DACC_READ_OPERATION         0x80U

#define SLLD_3DACC_SPI_READ_COMMAND_BYTE    (tU8)(SLLD_3D6DACC_OUT_X_L_ADDRESS | SLLD_3D6DACC_READ_OPERATION | SLLD_3DACC_INCREMENT_ADDRESS)
#define SLLD_6DACC_SPI_READ_COMMAND_BYTE    (tU8)(SLLD_3D6DACC_OUT_X_L_ADDRESS | SLLD_3D6DACC_READ_OPERATION )

#define SLLD_6DACC_BOSCH_SPI_READ_COMMAND_BYTE   (tU8)(SLLD_COMBO_BMI160_ACC_OUT_X_L_ADDRESS | SLLD_3D6DACC_READ_OPERATION )

#define SLLD_3DACC_SLAVE_ADDR               0x18U
#define SLLD_3DACC_I2C_AUTO_INC_MASK        0x80U   /* Register address in automatically incremented to allow multiple data r/w */
#define SLLD_3DACC_I2C_TEST_READ            0x80U   /*(1<<7)*/

#define SLLD_3D6DACC_SPI_BUS_TYPE           0x0U
#define SLLD_3D6DACC_I2C_BUS_TYPE           0x1U

#define SLLD_ST_MEMS_3DACC_TYPE             0x00U
#define SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE   0x01U
#define SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE     0x02U
#define SLLD_MEMS_6DACC_BMI160_TYPE         0x03U
#define SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE     0x04U
#define SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE     0x05U
#define SLLD_MEMS_6DACC_SMI130_TYPE         0x06U


#define SLLD_3D6DACC_SPI_ID             0U
#define SLLD_3D6DACC_SPI_INT_PRIORITY   10

#if defined(__STA8090__)
#define SLLD_3DACC_SPI_GPIO_ADDR        (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define SLLD_3DACC_SPI_CS_PIN           LLD_GPIO_PIN14
#else
#define SLLD_3DACC_SPI_GPIO_ADDR        (LLD_GPIO_idTy)GPIO1_REG_START_ADDR
#define SLLD_3DACC_SPI_CS_PIN           LLD_GPIO_PIN0
#endif
#define SLLD_3DACC_SPI_CS_PIN_MODE      LLD_GPIO_MODE_ALTA
#define SLLD_3D6DACC_SPI_BUS_FREQUENCY  1000000
#define SLLD_3D6DACC_CONF_GPIO_MASK     0x3fU
#define SLLD_3D6DACC_NOT_CONFIG         ((tU32)0xffffffffU)
#define SLLD_3D6DACC_GPIO0_LAST_CH      (32U)
#define SLLD_3D6DACC_GPIO1_LAST_CH      (tU32)LLD_GPIOCHUNDEF

//SMI130
#define SLLD_ACC_ID_SMI130             0xFAU   // SMI130

// Registers address
#define SLLD_SMI130_ACC_RANGE           0x0FU   // ACC Register (RANGE)
#define SLLD_SMI130_ACC_BW              0x10U   // ACC Register (BW)
#define SLLD_SMI130_ACC_HBW             0x13U   // ACC Register (HBW)
#define SLLD_SMI130_ACC_OUT_X_L_ADDRESS 0x02U   // ACCD_X_LSB register address

// Registers values
#define SLLD_SMI130_ACC_RANGE_FS_2G    0x03U   // FS= +2g resolution= 1024 LSB/g
#define SLLD_SMI130_ACC_BW_MAX         0x0FU   // Acc BW MAX= 1000Hz. ODR = 2*BW
#define SLLD_SMI130_ACC_BW_31          0x0AU   // Acc BW = 31.25Hz. ODR = 2*BW
#define SLLD_SMI130_ACC_HBW_FILT       0x00U   // data high bw filtered
#define SLLD_SMI130_ACC_HBW_SHADOW_EN  0x00U   // MSB is locked until it is read


/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct slld_3Dacc_msg_tag
{
  gpOS_clock_t  acc_3D_cpu_time;
  tU16          acc_3D_x_data;
  tU16          acc_3D_y_data;
  tU16          acc_3D_z_data;
} slld_3Dacc_sample_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
extern gnss_error_t             slld_3Dacc_init           ( const tU8 , const tU8 , const tU8 , const slld_fifo_info_t  );
extern gnss_error_t             slld_3Dacc_CS_init        ( const tU8 , const tU8 , const tU8 );
extern void                     slld_3Dacc_get_sample     (slld_3Dacc_sample_t *);
extern void                     slld_3Dacc_get_fifo       (slld_3Dacc_sample_t *, slld_fifo_msg_t*, const slld_fifo_info_t );
extern boolean_t                slld_get_acc_Init_Status  (void);


#ifdef __cplusplus
}
#endif

#endif /* DR_3DACC_H */
