/*!
 * slld_common.c
 * combo control registers reading functions .
 * used for debug purpose
 * \date 23/01/2017
 */

#include "gpOS.h"
#include "clibs.h"
#include "slld_api.h"

#if defined(__linux__)

#else
#include "lld_gpio.h"
#include "svc_ssp.h"
#include "svc_i2c.h"
#include "gnss_debug.h"

slld_fifo_info_t LL_fifo_info;

/* Prototypes */
gnss_error_t slld_combo_read_CtrlReg_i2c(void);
gnss_error_t slld_combo_read_CtrlReg_spi(void);
gnss_error_t slld_combo_read_CtrlReg(void);

// check the CTRL registers for LSM6DS3
gnss_error_t slld_combo_read_CtrlReg_spi(void)
{
  tU8 slld_combo_spi_command[8];
  tU8 slld_combo_spi_command_response[8];

  switch (slld_3D6Dacc_type)
  {
    case SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE:
    case SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE:
    {
      // Read MASTER_CONFIG register
      slld_combo_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_LSM6DS3_MASTER_CONFIG);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_combo_spi_command,2,slld_combo_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[SLLD_combo] SPI read MASTER_CONFIG error!\r\n"));
      }
      else
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_LSM6DS3_MASTER_CONFIG : %x\r\n",slld_combo_spi_command_response[1]));
      }
      // Read CTRL3_C CTRL4_C register
      slld_combo_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_CTRL3_C);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_combo_spi_command,3,slld_combo_spi_command_response,NULL) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read CTRL4_C error!\r\n"));
      }
      else
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_CTRL3_C : %x\r\n",slld_combo_spi_command_response[1]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_CTRL4_C : %x\r\n",slld_combo_spi_command_response[2]));
      }

      // Read CTRL1_XL register
      slld_combo_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_6DACC_CTRL1_XL);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_combo_spi_command,2,slld_combo_spi_command_response,NULL) == gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read CTRL1_XL error!\r\n"));
      }
      else
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_6DACC_CTRL1_XL : %x\r\n",slld_combo_spi_command_response[1]));
      }
      // Read FIFO_CTRL1,FIFO_CTRL2,FIFO_CTRL3,FIFO_CTRL4,FIFO_CTRL5 register
      slld_combo_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_LSM6DS3_FIFO_CTRL1);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_combo_spi_command,6,slld_combo_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read FIFO_CTRLx error!\r\n"));
      }
      else
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_LSM6DS3_FIFO_CTRL1 : %x\r\n",slld_combo_spi_command_response[1]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_LSM6DS3_FIFO_CTRL2 : %x\r\n",slld_combo_spi_command_response[2]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_LSM6DS3_FIFO_CTRL3 : %x\r\n",slld_combo_spi_command_response[3]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_LSM6DS3_FIFO_CTRL4 : %x\r\n",slld_combo_spi_command_response[4]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_LSM6DS3_FIFO_CTRL5 : %x\r\n",slld_combo_spi_command_response[5]));
      }
    }
    break;

    case SLLD_MEMS_6DACC_BMI160_TYPE:
    {
      // Read Ctrl registers
      slld_combo_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_BMI160_ACC_CONF);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_combo_spi_command,7,slld_combo_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_BMI160_ACC_CONF error!\r\n"));
      }
      else
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_BMI160_ACC_CONF : 0x%x\r\n",slld_combo_spi_command_response[1]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_BMI160_ACC_RANGE : 0x%x\r\n",slld_combo_spi_command_response[2]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_BMI160_GYR_CONF : 0x%x\r\n",slld_combo_spi_command_response[3]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_BMI160_GYR_RANGE : 0x%x\r\n",slld_combo_spi_command_response[4]));
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_BMI160_FIFO_CONFIG1 : 0x%x\r\n",slld_combo_spi_command_response[7]));
      }

      // Read the Err and PMU_STATUS registers
      slld_combo_spi_command[0] = (tU8)(SLLD_3D6DACC_READ_OPERATION | SLLD_COMBO_BMI160_ERR_REG);
      if (svc_ssp_write(slld_3D6Dacc_spi_com_hnd,slld_combo_spi_command,3,slld_combo_spi_command_response,NULL)== gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[sld_combo] SPI read SLLD_COMBO_BMI160_ERR_REG error!\r\n"));
      }
      else
      {
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_ERR_REG : 0x%x\r\n",slld_combo_spi_command_response[1]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_PMU_STATUS : 0x%x\r\n",slld_combo_spi_command_response[2]));
      }
    }
    break;

    default:
    break;
  }

  return GNSS_NO_ERROR;
}

// check the CTRL registers for LSM6DS3
gnss_error_t slld_combo_read_CtrlReg_i2c(void)
{
  tU8 CtrlRegisterValue[21];
  gpOS_clock_t timeout;
  gnss_error_t error = GNSS_NO_ERROR;

  switch (slld_3D6Dacc_type)
  {
    case SLLD_ST_MEMS_6DACC_LSM6DS3_TYPE:
    case SLLD_ST_MEMS_6DACC_ASM330LXH_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DSM_TYPE:
    case SLLD_ST_MEMS_6DACC_LSM6DSR_TYPE:
   {
      // Read CTRL registers
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_LSM6DS3_FIFO_CTRL1, 1, &CtrlRegisterValue[0], 21, &timeout) != gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_LSM6DS3_FIFO_CTRL1 : 0x%x\r\n",CtrlRegisterValue[0]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_LSM6DS3_FIFO_CTRL2 : 0x%x\r\n",CtrlRegisterValue[1]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_LSM6DS3_FIFO_CTRL3 : 0x%x\r\n",CtrlRegisterValue[2]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_LSM6DS3_FIFO_CTRL4 : 0x%x\r\n",CtrlRegisterValue[3]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_LSM6DS3_FIFO_CTRL5 : 0x%x\r\n",CtrlRegisterValue[4]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_6DACC_CTRL1_XL : 0x%x\r\n",CtrlRegisterValue[10]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_CTRL3_C : 0x%x\r\n",CtrlRegisterValue[12]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_LSM6DS3_MASTER_CONFIG : 0x%x\r\n",CtrlRegisterValue[20]));
      }
      else
      {
        error = GNSS_ERROR;
      }
    }
    break;

    case SLLD_MEMS_6DACC_BMI160_TYPE:
    {
      // Read the Ctrl registers
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_BMI160_ACC_CONF, 1, &CtrlRegisterValue[0], 8, &timeout) != gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_ACC_CONF : 0x%x\r\n",CtrlRegisterValue[0]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_ACC_RANGE : 0x%x\r\n",CtrlRegisterValue[1]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_GYR_CONF : 0x%x\r\n",CtrlRegisterValue[2]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_GYR_RANGE : 0x%x\r\n",CtrlRegisterValue[3]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_FIFO_CONFIG1 : 0x%x\r\n",CtrlRegisterValue[7]));
      }
      else
      {
        error = GNSS_ERROR;
      }

      // Read the Err and PMU_STATUS registers
      timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
      if( svc_i2c_read( slld_3D6Dacc_i2c_com_hnd, SLLD_COMBO_BMI160_ERR_REG, 1, &CtrlRegisterValue[0], 2, &timeout) != gpOS_FAILURE)
      {
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_ERR_REG : 0x%x\r\n",CtrlRegisterValue[0]));
        DR_DEBUG_MSG(("[sld_combo] I2c read SLLD_COMBO_BMI160_PMU_STATUS : 0x%x\r\n",CtrlRegisterValue[1]));
      }
      else
      {
        error = GNSS_ERROR;
      }
    }
    break;

    default:
    {
      error = GNSS_ERROR;
    }
    break;
  }
  return error;
}

// check the CTRL registers for LSM6DS3
gnss_error_t slld_combo_read_CtrlReg(void)
{
  gnss_error_t return_value = GNSS_NO_ERROR;

  if ( (SLLD_3D6DACC_SPI_BUS_TYPE == slld_3D6Dacc_bus_type) ||  (SLLD_3D6DGYRO_SPI_BUS_TYPE == slld_3D6Dgyro_bus_type))
  {
    return_value = slld_combo_read_CtrlReg_spi();
  }

  if ( (SLLD_3D6DACC_I2C_BUS_TYPE == slld_3D6Dacc_bus_type) ||  (SLLD_3D6DGYRO_I2C_BUS_TYPE == slld_3D6Dgyro_bus_type))
  {
    return_value = slld_combo_read_CtrlReg_i2c();
  }

  return return_value;

}

 #endif  //__linux__

