/*!
 * slld_pres.h
 * Defines the interface for Pressure sensor.  Introduce for STA8090EXG
 */
#ifndef SLLD_PRES_H
#define SLLD_PRES_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "lld_gpio.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define SLLD_PRES_SPI_ID                  0U

#define SLLD_PRES_SPI_BUS_TYPE             0x00U
#define SLLD_PRES_I2C_BUS_TYPE             0x01U

#define SLLD_ST_MEMS_PRES_LPS25H_TYPE     0xBD

#define SLLD_PRES_SPI_GPIO_ADDR           (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define SLLD_PRES_SPI_CS_PIN              LLD_GPIO_PIN15
#define SLLD_PRES_SPI_CS_PIN_MODE         LLD_GPIO_MODE_ALTA
#define SLLD_PRES_SPI_BUS_FREQUENCY       1000000

#define SLLD_PRES_CONF_GPIO_MASK          0x3fU
#define SLLD_PRES_GPIO0_LAST_CH           (32U)
#define SLLD_PRES_GPIO1_LAST_CH           (tU32)LLD_GPIOCHUNDEF
#define SLLD_PRES_NOT_CONFIG              ((tU32)0xffffffffU)

#define SLLD_PRES_RES_CONF_REG            0x10U
#define SLLD_PRES_STATUS_REG              0x27U
#define SLLD_PRES_CTRL_REG1               0x20U
#define SLLD_PRES_CTRL_REG2               0x21U
#define SLLD_PRES_ACTIVE_MODE_ENABLE      0x80U
#define SLLD_PRES_OUTPUT_RATE_RESET       0x8FU
#define SLLD_PRES_OUTPUT_DATA_RATE        0x20U
#define SLLD_PRES_OUT_XL_ADDRESS          0x28U

#define SLLD_PRES_WHO_AM_I                0x0FU

#define SLLD_PRES_READ_OPERATION          0x80U
#define SLLD_PRES_INCREMENT_ADDRESS       0x40U
#define SLLD_PRES_SPI_READ_COMMAND_BYTE   (tU8)(SLLD_PRES_OUT_XL_ADDRESS | SLLD_PRES_READ_OPERATION | SLLD_PRES_INCREMENT_ADDRESS)

#define SLLD_PRES_SLAVE_ADDR              0x5CU
#define SLLD_PRES_I2C_AUTO_INC_MASK       0x80U  /* Register address in automatically incremented to allow multiple data r/w */

#define SLLD_PRES_BDU                     0x04U
#define SLLD_PRES_RESET_AZ                0x02U
#define SLLD_PRES_SW_RESET                0x04U
#define SLLD_PRES_BOOT                    0x80U
#define SLLD_PRES_AUTO_ZERO               0x02U


/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct slld_Pres_msg_tag
{
  gpOS_clock_t  pres_cpu_time;
  tU32          pres_data;
} slld_Pres_sample_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t   slld_Pres_init            ( const tU8 , const tU8  ) ;
extern gnss_error_t   slld_Pres_CS_init         ( const tU8 , const tU8 , const tU8 );
extern void           slld_Pres_get_sample      ( slld_Pres_sample_t *);
extern boolean_t      slld_get_Pres_Init_Status (void);

#ifdef __cplusplus
}
#endif

#endif /* SLLD_PRES_H */
