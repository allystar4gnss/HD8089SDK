/*!
 * slld_magn.h
 * Defines the interface for Magnetometer.  Introduce for STA8090EXG
 */
#ifndef SLLD_MAGN_H
#define SLLD_MAGN_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "lld_gpio.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define SLLD_MAGN_SPI_ID            0

#define SLLD_MAGN_SPI_BUS_TYPE            0x00U
#define SLLD_MAGN_I2C_BUS_TYPE            0x01U

#define SLLD_ST_MAGN_LIS3MDL_TYPE         0x00U
#define SLLD_ST_MAGN_LSM303AGR_TYPE       0x01U

#define SLLD_MAGN_TEMP_SENSOR_SENSITIVITY 0x10U

#define SLLD_MAGN_SPI_GPIO_ADDR     (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define SLLD_MAGN_SPI_CS_PIN        LLD_GPIO_PIN0
#define SLLD_MAGN_SPI_CS_PIN_MODE   LLD_GPIO_MODE_SOFTWARE
#define SLLD_MAGN_SPI_BUS_FREQUENCY 1000000

#define SLLD_MAGN_CONF_GPIO_MASK    0x3fU
#define SLLD_MAGN_GPIO0_LAST_CH     (32U)
#define SLLD_MAGN_GPIO1_LAST_CH     (tU32)LLD_GPIOCHUNDEF
#define SLLD_MAGN_NOT_CONFIG         ((tU32)0xffffffffU)

#define SLLD_MAGN_WHO_AM_I                  0x0FU
#define SLLD_MAGN_WHO_AM_I_M                0x4FU
#define SLLD_MAGN_ID_LIS3MDL                0x3DU    //LIS3MDL
#define SLLD_MAGN_ID_LSM303AGR              0x40U    //LSM303AGR

#define SLLD_MAGN_CTRL_REG1                 0x20U
#define SLLD_MAGN_CTRL_REG2                 0x21U
#define SLLD_MAGN_CTRL_REG3                 0x22U
#define SLLD_MAGN_CTRL_REG4                 0x23U
#define SLLD_MAGN_CTRL_REG5                 0x24U

#define SLLD_MAGN_OFFSET_X_REG_L            0x45U
#define SLLD_MAGN_OFFSET_X_REG_H            0x46U
#define SLLD_MAGN_OFFSET_Y_REG_L            0x47U
#define SLLD_MAGN_OFFSET_Y_REG_H            0x48U
#define SLLD_MAGN_OFFSET_Z_REG_L            0x49U
#define SLLD_MAGN_OFFSET_Z_REG_H            0x4AU
#define SLLD_MAGN_CFG_REG_A                 0x60U
#define SLLD_MAGN_CFG_REG_B                 0x61U
#define SLLD_MAGN_CFG_REG_C                 0x62U

#define SLLD_MAGN_INCREMENT_ADDRESS         0x40U
#define SLLD_MAGN_READ_OPERATION            0x80U

#define SLLD_MAGN_OUT_X_L_ADDRESS           0x28U
#define SLLD_MAGN_OUT_TEMP_ADDRESS          0x2EU

#define SLLD_MAGN_OUT_X_L_REG               0x68U

#define SLLD_MAGN_SPI_READ_COMMAND_BYTE         (tU8)(SLLD_MAGN_OUT_X_L_ADDRESS | SLLD_MAGN_READ_OPERATION | SLLD_MAGN_INCREMENT_ADDRESS)
#define SLLD_MAGN_SPI_READ_TEMP_COMMAND_BYTE    (tU8)(SLLD_MAGN_OUT_TEMP_ADDRESS | SLLD_MAGN_READ_OPERATION)


/*****************************************************************************
   typedefs and structures
*****************************************************************************/
typedef struct slld_Magn_msg_tag
{
  gpOS_clock_t  magn_cpu_time;
  tU16          magn_x_data;
  tU16          magn_y_data;
  tU16          magn_z_data;
  fp_s16_t      magn_temp;
} slld_Magn_sample_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t slld_Magn_init              ( const tU8 , const tU8 );
extern gnss_error_t slld_Magn_CS_init           ( const tU8 , const tU8 , const tU8 );
extern void         slld_Magn_get_sample        (slld_Magn_sample_t *);
extern boolean_t    slld_get_Magn_Init_Status   (void);

#ifdef __cplusplus
}
#endif

#endif /* SLLD_MAGN_H */
