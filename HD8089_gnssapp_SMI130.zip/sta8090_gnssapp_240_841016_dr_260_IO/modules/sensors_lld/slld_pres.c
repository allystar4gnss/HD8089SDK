/*!
 * slld_pres.c
 * Implements the basic driver blocks for a pressure sensor.
 * Initialization, get message functions
 * \date 23/01/2017
 */

#ifndef __linux__
#include "gpOS.h"
#include "clibs.h"
#include "slld_api.h"
#include "svc_ssp.h"
#include "svc_i2c.h"
#include "gnss_debug.h"

static svc_ssp_com_handler_t *slld_Pres_spi_com_hnd=NULL;
static svc_i2c_com_handler_t *slld_Pres_i2c_com_hnd=NULL;
static boolean_t slld_Pres_initialized = FALSE;
static tU8 slld_Pres_bus_type = SLLD_PRES_SPI_BUS_TYPE;
static tU32 slld_Pres_cs_gpio_id = SLLD_PRES_NOT_CONFIG;
static tU8 slld_pres_spi_read_command[4] = {SLLD_PRES_SPI_READ_COMMAND_BYTE,0,0,0};


/*Prototype*/
gnss_error_t slld_Pres_setup(void) ;
gnss_error_t slld_Pres_init_CtrlReg_i2c(void) ;
gnss_error_t slld_Pres_init_CtrlReg_spi(void);
void slld_Pres_spi_cs_enable( void *);
void slld_Pres_spi_cs_disable( void *);


void slld_Pres_get_sample(slld_Pres_sample_t *sample)
{
  if(SLLD_PRES_SPI_BUS_TYPE == slld_Pres_bus_type)
  {
    tU8 *in_buf_ptr;
    in_buf_ptr = (tU8 *)((tUInt)&sample->pres_data - 1) ;

    if ( svc_ssp_write(slld_Pres_spi_com_hnd,slld_pres_spi_read_command,4,in_buf_ptr,NULL) == gpOS_FAILURE )
    {
      DR_DEBUG_MSG(("[slld_Pres] SPI read sample error!\r\n"));
    }
  }
  else
  {
     gpOS_clock_t timeout;

     /* Pres ST Mems type */
     tU8 slld_Pres_i2c_command_response[3]={0,0,0};

     timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
     if( svc_i2c_read( slld_Pres_i2c_com_hnd, SLLD_PRES_OUT_XL_ADDRESS|SLLD_PRES_I2C_AUTO_INC_MASK, 1, slld_Pres_i2c_command_response, 3, &timeout) == gpOS_FAILURE)
     {
       DR_DEBUG_MSG(("[slld_Pres] I2c read error!\r\n"));
     }

     sample->pres_data = (tU32)slld_Pres_i2c_command_response[0] + ((tU32)slld_Pres_i2c_command_response[1] << 8) + ((tU32)slld_Pres_i2c_command_response[2] << 16);
    DR_DEBUG_MSG(("[slld_Pres] I2c pressure:0x%u\r\n",sample->pres_data));
  }
  sample->pres_cpu_time = gpOS_time_now();
}


gnss_error_t slld_Pres_init_CtrlReg_i2c(void)
{
  gpOS_clock_t timeout;
  tU8 slld_Pres_i2c_command_response;
  gnss_error_t return_error = GNSS_NO_ERROR;

  DR_DEBUG_MSG(("[slld_Pres] I2C Device LPS25H recognized!\r\n"));

  // Read CTRL_REG1 register
  timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
  if( svc_i2c_read( slld_Pres_i2c_com_hnd, SLLD_PRES_CTRL_REG1, 1, &slld_Pres_i2c_command_response, 1, &timeout) == gpOS_FAILURE)
  {
    DR_DEBUG_MSG(("[slld_Pres] I2c read SLLD_PRES_CTRL_REG1 error!\r\n"));
    return_error = GNSS_ERROR;
  }

  slld_Pres_i2c_command_response = (slld_Pres_i2c_command_response|SLLD_PRES_ACTIVE_MODE_ENABLE);  //set active mode
  slld_Pres_i2c_command_response = (slld_Pres_i2c_command_response&SLLD_PRES_OUTPUT_RATE_RESET);  // reset output data rate
  slld_Pres_i2c_command_response = (slld_Pres_i2c_command_response|SLLD_PRES_OUTPUT_DATA_RATE); //set output data rate to 25 Hz
  slld_Pres_i2c_command_response = (slld_Pres_i2c_command_response|SLLD_PRES_BDU); //set BDU
  slld_Pres_i2c_command_response = (slld_Pres_i2c_command_response|SLLD_PRES_RESET_AZ); //set RESET_AZ --> reset REF_P to RPDS register

  // Write in CTRL_REG1 register
  timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());
  if( svc_i2c_write( slld_Pres_i2c_com_hnd, SLLD_PRES_CTRL_REG1, 1, &slld_Pres_i2c_command_response, 1, 1,&timeout) == gpOS_FAILURE)
  {
    DR_DEBUG_MSG(("[slld_Pres] I2c write SLLD_PRES_CTRL_REG1 error!\r\n"));
    return_error = GNSS_ERROR;
  }

  return return_error;
}

gnss_error_t slld_Pres_init_CtrlReg_spi(void)
{
  tU8 slld_pres_spi_command[7];
  tU8 slld_pres_spi_command_response[7];
  gnss_error_t return_error = GNSS_NO_ERROR;

  DR_DEBUG_MSG(("[slld_Pres] SPI Device LPS25H recognized!\r\n"));

  // Read CTRL_REG1 register
  slld_pres_spi_command[0] = (tU8) (SLLD_PRES_READ_OPERATION | SLLD_PRES_CTRL_REG1);
  if (svc_ssp_write(slld_Pres_spi_com_hnd,slld_pres_spi_command,2,slld_pres_spi_command_response,NULL) == gpOS_FAILURE)
  {
    DR_DEBUG_MSG(("[slld_Pres] SPI read CTRL_REG1 error!\r\n"));
    return_error = GNSS_ERROR;
  }

  // Write in the CTRL_REG1 register
  slld_pres_spi_command[0] = SLLD_PRES_CTRL_REG1;
  slld_pres_spi_command[1] = (((slld_pres_spi_command_response[1] | SLLD_PRES_ACTIVE_MODE_ENABLE)&SLLD_PRES_OUTPUT_RATE_RESET)|SLLD_PRES_OUTPUT_DATA_RATE);
  slld_pres_spi_command[1] |= SLLD_PRES_BDU; //set BDU
  slld_pres_spi_command[1] |= SLLD_PRES_RESET_AZ; //set RESET_AZ --> reset REF_P to RPDS register

  if (svc_ssp_write(slld_Pres_spi_com_hnd,slld_pres_spi_command,2,slld_pres_spi_command_response,NULL)== gpOS_FAILURE)
  {
    DR_DEBUG_MSG(("[slld_Pres] SPI write CTRL_REG1 error!\r\n"));
    return_error = GNSS_ERROR;
  }

  return return_error;
}


void slld_Pres_spi_cs_enable(void *par)
{
  /* GPIO for Pressure not set in DRAW FW Config */
  if(SLLD_PRES_NOT_CONFIG == slld_Pres_cs_gpio_id)
  {
     LLD_GPIO_SetStateLow((LLD_GPIO_idTy)SLLD_PRES_SPI_GPIO_ADDR,(LLD_GPIO_PinTy)SLLD_PRES_SPI_CS_PIN);
  }
  else
  { /* GPIO ID management for N ports target */
    if((tInt)slld_Pres_cs_gpio_id < SLLD_PRES_GPIO0_LAST_CH)
    {
       LLD_GPIO_SetStateLow((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (LLD_GPIO_PinTy) (((tU32)1U) << slld_Pres_cs_gpio_id));
    }
    else
      if((tInt)slld_Pres_cs_gpio_id < SLLD_PRES_GPIO1_LAST_CH)
      {
       LLD_GPIO_SetStateLow((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (LLD_GPIO_PinTy)(((tU32)1U) << (slld_Pres_cs_gpio_id-32U)));
      }
      else
      {
        // Impossible case
      }
  }
}

void slld_Pres_spi_cs_disable(void *par)
{
  /* GPIO for Pressure not set in DRAW FW Config */
  if(SLLD_PRES_NOT_CONFIG == slld_Pres_cs_gpio_id)
  {
     LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SLLD_PRES_SPI_GPIO_ADDR,(LLD_GPIO_PinTy)SLLD_PRES_SPI_CS_PIN);
  }
  else
  { /* GPIO ID management for N ports target */
    if((tInt)slld_Pres_cs_gpio_id < SLLD_PRES_GPIO0_LAST_CH)
    {
       LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO0_REG_START_ADDR, (LLD_GPIO_PinTy)(((tU32)1U) << slld_Pres_cs_gpio_id));
    }
    else
      if((tInt)slld_Pres_cs_gpio_id < SLLD_PRES_GPIO1_LAST_CH)
      {
       LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (LLD_GPIO_PinTy)(((tU32)1U) << (slld_Pres_cs_gpio_id-32U)));
      }
      else
      {
        // Impossible case
      }
   }
}

gnss_error_t slld_Pres_setup(void)
{
  gnss_error_t return_error = GNSS_NO_ERROR;

  if(SLLD_PRES_SPI_BUS_TYPE == slld_Pres_bus_type)
  {
     tU8 slld_pres_spi_command = (tU8)(SLLD_PRES_READ_OPERATION | SLLD_PRES_WHO_AM_I);
     tU8 slld_pres_spi_command_response[2];

    if (svc_ssp_write(slld_Pres_spi_com_hnd,&slld_pres_spi_command,2,slld_pres_spi_command_response,NULL)== gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Pres] SPI read WHO_AM_I error!\r\n"));
      return_error = GNSS_ERROR;
    }

    if((tInt)slld_pres_spi_command_response[1] != SLLD_ST_MEMS_PRES_LPS25H_TYPE)
    {
      DR_DEBUG_MSG(("[slld_Pres] Device not recognized!\r\n"));
      return_error = GNSS_ERROR;
    }

    if ( return_error == GNSS_NO_ERROR)
    {
      return_error = slld_Pres_init_CtrlReg_spi();
    }
  }
  else
  {
    tU8 slld_Pres_i2c_command_response[1] = {0};
    gpOS_clock_t timeout;

    timeout = gpOS_time_plus( gpOS_time_now(), gpOS_timer_ticks_per_sec());

    if( svc_i2c_read( slld_Pres_i2c_com_hnd, SLLD_PRES_WHO_AM_I, 1, &slld_Pres_i2c_command_response[0], 1, &timeout) == gpOS_FAILURE)
    {
      DR_DEBUG_MSG(("[slld_Pres] I2c read SLLD_PRES_WHO_AM_I error!\r\n"));
      return_error = GNSS_ERROR;
    }

    if((tInt)slld_Pres_i2c_command_response[0] != SLLD_ST_MEMS_PRES_LPS25H_TYPE)
    {
      DR_DEBUG_MSG(("[slld_Pres] Device not recognized!\r\n"));
      return_error = GNSS_ERROR;
    }

    if ( return_error == GNSS_NO_ERROR)
    {
      return_error = slld_Pres_init_CtrlReg_i2c();
    }
  }

  return return_error;
}

gnss_error_t slld_Pres_init( const tU8 bus_type,  const tU8 i2c_SlaveAd_conf )
{
  gnss_error_t return_error = GNSS_NO_ERROR;

  /* SPI mode */
  if(SLLD_PRES_SPI_BUS_TYPE == bus_type)
  {
    slld_Pres_spi_com_hnd = svc_ssp_create_com((tUInt)SLLD_PRES_SPI_ID, LLD_SSP_INTERFACE_MOTOROLA_SPI,(tU32)SLLD_PRES_SPI_BUS_FREQUENCY, LLD_SSP_DATA_BITS_8,(svc_ssp_hook_t)slld_Pres_spi_cs_enable, NULL, (svc_ssp_hook_t)slld_Pres_spi_cs_disable, NULL);

    if(slld_Pres_spi_com_hnd == NULL)
    {
      DR_DEBUG_MSG(("[slld_Pres] SPI com handler error\r\n"));
      return_error =  GNSS_ERROR;
    }
    slld_Pres_bus_type = SLLD_PRES_SPI_BUS_TYPE;
  }
  else
  /* I2c mode */
  {
     /* Backward Compatibility */
    if (0x00U == i2c_SlaveAd_conf)
    {
      DR_DEBUG_MSG(("[slld_Pres] I2C Slave Address: 0x%x\r\n",SLLD_PRES_SLAVE_ADDR));
      slld_Pres_i2c_com_hnd = svc_i2c_create_com( 0U, (LLD_I2C_SpeedModeTy)LLD_I2C_STANDARD_MODE, (tU16)(SLLD_PRES_SLAVE_ADDR));
    }
    else
    {
      /* i2c Slave Address for Acc is in Param 672 */
      DR_DEBUG_MSG(("[slld_Pres] I2C Slave Address: 0x%x\r\n",i2c_SlaveAd_conf));
      slld_Pres_i2c_com_hnd = svc_i2c_create_com( 0U, (LLD_I2C_SpeedModeTy)LLD_I2C_STANDARD_MODE, (tU16)i2c_SlaveAd_conf);
    }

    if (svc_i2c_set_port_mode( 0U, LLD_I2C_BUSCTRLMODE_MASTER) != gpOS_SUCCESS )
    {
      return_error =  GNSS_ERROR;
    }

    if(slld_Pres_i2c_com_hnd == NULL)
    {
      DR_DEBUG_MSG(("[slld_Pres] I2C com handler error\r\n"));
      return_error =  GNSS_ERROR;
    }
    slld_Pres_bus_type = SLLD_PRES_I2C_BUS_TYPE;

  }

  if ( return_error == GNSS_NO_ERROR)
  {
    return_error = slld_Pres_setup();

    if ( return_error == GNSS_NO_ERROR)
    {
      slld_Pres_initialized = TRUE;
    }
  }

  return return_error;
}

gnss_error_t slld_Pres_CS_init( const tU8 bus_type, const tU8 cs_gpio_conf, const tU8 cs_pullup)
{
  tU32 cs_gpio;
  LLD_GPIO_ModeTy cs_mode;

  // if mode is SPI and cs gpio config is not set in DRAW FW Config
  // Check for back compatibility
  if((SLLD_PRES_SPI_BUS_TYPE == bus_type) && (0x0U == cs_gpio_conf))
  {
    LLD_GPIO_SetControlMode((LLD_GPIO_idTy)SLLD_PRES_SPI_GPIO_ADDR,SLLD_PRES_SPI_CS_PIN,(LLD_GPIO_ModeTy)SLLD_PRES_SPI_CS_PIN_MODE);
    LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)SLLD_PRES_SPI_GPIO_ADDR,SLLD_PRES_SPI_CS_PIN);
    LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SLLD_PRES_SPI_GPIO_ADDR,SLLD_PRES_SPI_CS_PIN);
  }

  // if mode is SPI and cs gpio config is set in nvm or mode is I2C but cs pull up is set in nvm
  // pull up the cs
  if ( ((SLLD_PRES_SPI_BUS_TYPE == bus_type)&&(0x0U != cs_gpio_conf)) || ((SLLD_PRES_I2C_BUS_TYPE == bus_type) && (cs_pullup == 0x01U)) )
  {
    cs_gpio = ((( tU32)cs_gpio_conf) & SLLD_PRES_CONF_GPIO_MASK);
    cs_mode = ( LLD_GPIO_ModeTy)(cs_gpio_conf >> 6U);
    slld_Pres_cs_gpio_id = cs_gpio;

    if((tInt)cs_gpio < SLLD_PRES_GPIO0_LAST_CH)
    {
      LLD_GPIO_SetControlMode((LLD_GPIO_idTy)SLLD_PRES_SPI_GPIO_ADDR, (((tU32)1U) << cs_gpio), cs_mode);
      LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)SLLD_PRES_SPI_GPIO_ADDR, (((tU32)1U) << cs_gpio));
      LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)SLLD_PRES_SPI_GPIO_ADDR, (((tU32)1U) << cs_gpio));
    }
    else
      if((tInt)cs_gpio < SLLD_PRES_GPIO1_LAST_CH)
      {
        LLD_GPIO_SetControlMode((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (((tU32)1U) << (cs_gpio-32U)), cs_mode);
        LLD_GPIO_SetDirectionOutput((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (((tU32)1U) << (cs_gpio-32U)));
        LLD_GPIO_SetStateHigh((LLD_GPIO_idTy)GPIO1_REG_START_ADDR, (((tU32)1U) << (cs_gpio-32U)));
      }
      else
      {
        // Impossible case
      }
  }
  else
  {
    // case managed previously
  }

  return GNSS_NO_ERROR;
}

boolean_t slld_get_Pres_Init_Status(void)
{
  return slld_Pres_initialized;
}
#endif   //__linux__

