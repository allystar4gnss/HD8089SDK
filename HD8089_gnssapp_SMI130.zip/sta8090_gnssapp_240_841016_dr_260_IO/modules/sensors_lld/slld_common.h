/*!
 * slld_common.h
 * Defines special types for combo sensor.
 */
#ifndef SLLD_COMMON_H
#define SLLD_COMMON_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "svc_ssp.h"
#include "svc_i2c.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define SLLD_FIFO_MSG_PAYLOAD                       27U             // The Max size for the 6x Fifo is 15. Depends on the FW Config param 674 (sensors_raw_req)! see dr_fifo_info.number_elements_in_Fifo to deduce the max size

// ASM330LXH
#define SLLD_COMBO_ASM330LXH_ODR_100Hz              0x60U   /*(3<<5)*/
#define SLLD_COMBO_ASM330LXH_ODR_50Hz               0x40U   /*(1<<6)*/
#define SLLD_COMBO_ASM330LXH_ODR_MASK               0xE0U   /*(7<<5)*/
#define SLLD_COMBO_ASM330LXH_BW_SCAL_ODR_0          0x04U   /*(1<<2)*/
#define SLLD_COMBO_ASM330LXH_FIFO_CTRL              0x1AU
#define SLLD_COMBO_ASM330LXH_FIFO_MODE_MASK         0x07U
#define SLLD_COMBO_ASM330LXH_FIFO_MODE              0x20U   /*(1<<5)*/
#define SLLD_COMBO_ASM330LXH_FIFO_EN                0x02U   /*(1<<1)*/
#define SLLD_COMBO_ASM330LXH_FIFO_STOP_ON_FTH       0x01U
#define SLLD_COMBO_ASM330LXH_FIFO_TEMP_EN           0x10U   /*(1<<4)*/
#define SLLD_COMBO_ASM330LXH_REG00                  0x00U
#define SLLD_COMBO_ASM330LXH_REG45                  0x45U
#define SLLD_COMBO_ASM330LXH_REG46                  0x46U
#define SLLD_COMBO_ASM330LXH_REG47                  0x47U

//LSM6DS3
#define SLLD_COMBO_LSM6DS3_ODR_52Hz                 0x30U   // ODR set to 52Hz FS_XL:00 BW_XL:00
#define SLLD_COMBO_LSM6DS3_ODR_104Hz                0x40U   /*(1<<6)*/
#define SLLD_COMBO_LSM6DS3_ODR_MASK                 0xF0U   /*(0x0F<<4)*/
#define SLLD_COMBO_LSM6DS3_ODR_BW_SCAL_ODR          0x80U   /*(1<<7)*/    // ODR set to 52Hz FS_XL:00 BW_XL:00
#define SLLD_LSM6DS3_MASTER_CONFIG                  0x1AU
#define SLLD_LSM6DS3_DATA_VALID_SEL_FIFO            0x40U
#define SLLD_LSM6DS3_PATH_THROUGH_MODE              0x04U
#define SLLD_LSM6DS3_START_CONFIG                   0x10U
#define SLLD_LSM6DS3_PUSLLD_UP_EN                     0x08U
#define SLLD_COMBO_LSM6DS3_FIFO_CTRL1               0x06U
#define SLLD_COMBO_LSM6DS3_FIFO_CTRL2               0x07U
#define SLLD_COMBO_LSM6DS3_FIFO_CTRL3               0x08U
#define SLLD_COMBO_LSM6DS3_FIFO_CTRL4               0x09U
#define SLLD_COMBO_LSM6DS3_FIFO_CTRL5               0x0AU
#define SLLD_COMBO_LSM6DS3_BYPASS_MODE_MASK         0x07U
#define SLLD_COMBO_LSM6DS3_FIFO_CONT_MODE           0x06U
#define SLLD_COMBO_LSM6DS3_FIFO_FULL_MODE           0x01U
#define SLLD_COMBO_LSM6DS3_FIFO_STATUS1             0x3AU
#define SLLD_COMBO_LSM6DS3_FIFO_OVERRUN_MASK        0x40U
#define SLLD_COMBO_LSM6DS3_FIFO_FULL_MASK           0x20U
#define SLLD_COMBO_LSM6DS3_FIFO_EMPTY_MASK          0x10U
#define SLLD_COMBO_LSM6DS3_FIFO_FTH_MASK            0x80U
#define SLLD_COMBO_LSM6DS3_FIFO_DATA_OUT_L          0x3EU
#define SLLD_LSM6DS3_ODR_STEP                       0x0DU   // 13Hz: Min ODR for LSM6DS3

// Common ASM330LXH; LSM6DS3
#define SLLD_6DACC_CTRL1_XL                         0x10U
#define SLLD_3D6DACC_OUT_X_L_ADDRESS                0x28U
#define SLLD_COMBO_CTRL3_C                          0x12U
#define SLLD_COMBO_CTRL4_C                          0x13U
#define SLLD_COMBO_IF_ADD_INC                       0x04U   /*(1<<2)*/
#define SLLD_COMBO_BDU_MASK                         0x40U
#define SLLD_6DACC_CTRL9_XL                         0x18U
#define SLLD_6DACC_ACC_XYZ_ENABLED                  0x38U   /*(7<<3)*/
#define SLLD_6DACC_CTRL8_XL                         0x17U
#define SLLD_COMBO_STOP_ON_FTH                      0x01U   // in CTRL4_C register; used for FIFO mode

// LSM6DSR
#define SLLD_LSM6DSR_BASIC_REG                      0x00U
#define SLLD_LSM6DSR_DUMP_MODE                      0x40U
#define SLLD_LSM6DSR_DUMP_REG                       0x2EU

// ASM330LXH Constants for Gyro
#define SLLD_6DGYRO_ASM330LXH_FS_125                0x04U   /*(1<<2)*/
#define SLLD_6DGYRO_ASM330LXH_FS_MASK               0x1CU   /*(7<<2)*/
#define SLLD_COMBO_ASM330LXH_INT2_CTRL              0x0EU
#define SLLD_COMBO_ASM330LXH_INT2_DISABLED          0x03U

//LSM6DS3 Constants for Gyro
#define SLLD_6DGYRO_LSM6DS3_FS_125                  0x02U   /*(1<<1)*/
#define SLLD_6DGYRO_LSM6DS3_FS_MASK                 0x0FU

// Common ASM330LXH; LSM6DS3/LSM6DSM Constants for Gyro
#define SLLD_6DGYRO_OUT_TEMP_ADDRESS                0x20U
#define SLLD_6DGYRO_OUT_X_G_ADDRESS                 0x22U
#define SLLD_6DGYRO_CTRL2_G                         0x11U
#define SLLD_6DGYRO_CTRL10_C                        0x19U
#define SLLD_6DGYRO_G_XYZ_ENABLED                   0x38U   /*(7<<3)*/

#define SLLD_6DGYRO_TEMP_SENSOR_SENSITIVITY         0x10U   // ASM330LXH-LSM6DS3 Temperature sensitivity = 16 LSB/�C
#define SLLD_6DGYRO_TEMP_SENSOR_SENS_256            256.0    // ASM330LXH-LSM6DS3 Temperature sensitivity = 16 LSB/�C

// BOSCH sensors
#define SLLD_COMBO_CHIPID_REGISTER                  0x00U
// BMI160
#define SLLD_COMBO_ID_BMI160                        0xD1U   // BMI160

#define SLLD_COMBO_BMI160_ACC_CONF                  0x40U   // ACC_CONF register address
#define SLLD_COMBO_BMI160_ACC_US_NORMAL             0x00U   // acc_us =0b0  undersampling disable in normal mode
#define SLLD_COMBO_BMI160_ACC_BWP_NORMAL            0x20U   // acc_bwp =0b10
#define SLLD_COMBO_BMI160_ACC_ODR_50Hz              0x07U   // acc_odr =0b0111

#define SLLD_COMBO_BMI160_ACC_RANGE                 0x41U   // ACC_RANGE register address
#define SLLD_COMBO_BMI160_ACC_RANGE_RESET           0xF0U   // acc_range reset value
#define SLLD_COMBO_BMI160_ACC_RANGE_FS_2G           0x03U   // acc_odr =0b011

#define SLLD_COMBO_BMI160_GYR_CONF                  0x42U   // GYR_CONF register address
#define SLLD_COMBO_BMI160_GYR_BWP_NORMAL            0x20U   // gyr_bwp =0b10
#define SLLD_COMBO_BMI160_GYR_ODR_50Hz              0x07U   // gyr_odr =0b0111
#define SLLD_COMBO_BMI160_GYR_CONF_RES              0xC0U   // reserved
#define SLLD_COMBO_BMI160_GYR_RANGE_FS_125          0x04U   // gyr_odr =0b100
#define SLLD_COMBO_BMI160_GYR_RANGE_RES             0xF8U   // reserved

#define SLLD_COMBO_BMI160_FIFO_CONFIG1              0x47U   // FIFO_CONFIG1 register address
#define SLLD_COMBO_BMI160_NO_FIFO                   0x10U   // fifo_gyr_en =0; fifo_acc_en=0; fifo_mag_en=0; fifo_header_en=1
#define SLLD_COMBO_BMI160_FIFO1_RES                 0x01U   // reserved value

#define SLLD_COMBO_BMI160_ACC_OUT_X_L_ADDRESS       0x12U   // ACC_X register address

#define SLLD_COMBO_BMI160_GYR_OUT_X_L_ADDRESS       0x0CU   // GYR_X register address

#define SLLD_COMBO_BMI160_TEMP_ADDRESS              0x20U   // Temperature register address
#define SLLD_COMBO_BMI160_TEMP_SENSOR_SENSITIVITY   512.0   //  =2^9 BMI160 Temperature sensitivity = 1/2^9 K/LSB
#define SLLD_COMBO_TEMP_CONST                       23.0    // Value 0 -> 23�c

#define SLLD_COMBO_BMI160_CMD_REGISTER              0x7EU   // CMD Register
#define SLLD_COMBO_BMI160_ACC_SET_PMU_NORMAL_MODE   0x11U   // acc_pmu_status=0b01 normal mode
#define SLLD_COMBO_BMI160_GYR_SET_PMU_NORMAL_MODE   0x15U   // gyr_pmu_status=0b01 normal mode

#define SLLD_COMBO_BMI160_ERR_REG                   0x02U   // ERR Register address

/*****************************************************************************
   typedefs and structures
*****************************************************************************/
typedef enum slld_sensors_type_e
{
  SLLD_6XCOMBO_LSM6DS3 = 0U,
  SLLD_6XCOMBO_ASM330_LXH,
  SLLD_6XCOMBO_LSM6DSM,
  SLLD_UNKNOWN_SENSOR_TYPE
}slld_sensors_id_t;

typedef enum slld_sensors_odr_fifo_value_LSM6DS3_e
{
  SLLD_LSM6DS3_ODR_13Hz = 1U,
  SLLD_LSM6DS3_ODR_26Hz,
  SLLD_LSM6DS3_ODR_52Hz,
  SLLD_LSM6DS3_ODR_104Hz,
  SLLD_LSM6DS3_ODR_208Hz,
  SLLD_LSM6DS3_ODR_416Hz,
  SLLD_LSM6DS3_ODR_833Hz,
  SLLD_LSM6DS3_ODR_1660Hz,
  SLLD_LSM6DS3_ODR_3330Hz,
  SLLD_LSM6DS3_ODR_6660Hz
}slld_sensors_odr_fifo_value_LSM6DS3_t;

typedef enum slld_sensors_odr_fifo_value_ASM330LXH_e
{
  SLLD_ASM330LXH_ODR_12_5Hz = 1U,
  SLLD_ASM330LXH_ODR_50Hz,
  SLLD_ASM330LXH_ODR_100Hz,
  SLLD_ASM330LXH_ODR_200Hz,
  SLLD_ASM330LXH_ODR_400Hz,
  SLLD_ASM330LXH_ODR_800Hz
 }slld_sensors_odr_fifo_value_ASM330LXH_t;


/*{{{  dr_sensors_odr_fifo_value_t*/
typedef union
{
  slld_sensors_odr_fifo_value_LSM6DS3_t      odr_fifo_LSM6DS3;
  slld_sensors_odr_fifo_value_ASM330LXH_t    odr_fifo_ASM330LXH;
} slld_sensors_odr_fifo_value_t;

typedef struct slld_fifo_info_tag
{
  tUShort                     odr_freq;
  tUShort                     number_elements_in_Fifo;
  tUInt                       slld_sampling;
  slld_sensors_odr_fifo_value_t odr_val;
  slld_sensors_id_t             combo_id_req;
  boolean_t                   slld_3Dacc_FiFoModeEn;
  boolean_t                   slld_3DGyro_FiFoModeEn;
  tU8                         Decimation_Fifo_Acc;
  tU8                         Decimation_Fifo_Gyro;
} slld_fifo_info_t;


typedef enum dr_fifo_pattern_tag
{
  DR_ACC_XYZ = 0U,
  DR_GYRO_XYZ_ACC_XYZ,
  DR_GYRO_XYZ
} slld_fifo_pattern_t;

typedef struct dr_fifo_msg_tag
{
  gpOS_clock_t        first_elem_cpu_time;
  tU16                fifo_buf[SLLD_FIFO_MSG_PAYLOAD];
  tU8                 number_words_fifo_read;
  slld_fifo_pattern_t   fifo_pattern;
} slld_fifo_msg_t;


/*****************************************************************************
   exported variables
*****************************************************************************/
extern svc_ssp_com_handler_t *  slld_3D6Dacc_spi_com_hnd;
extern svc_i2c_com_handler_t *  slld_3D6Dacc_i2c_com_hnd;
extern tU8                      slld_3D6Dacc_bus_type;
extern tU8                      slld_3D6Dgyro_bus_type;
extern tU8                      slld_3D6Dacc_type;

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
extern gnss_error_t slld_combo_read_CtrlReg_i2c(void);
extern gnss_error_t slld_combo_read_CtrlReg_spi(void);
extern gnss_error_t slld_combo_read_CtrlReg(void);
#ifdef __cplusplus
}
#endif

#endif /* DR_COMBO_COMMON_H */
