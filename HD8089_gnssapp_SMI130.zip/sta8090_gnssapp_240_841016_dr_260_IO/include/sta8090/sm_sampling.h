/*!
 * sm_sampling.h
 */
#ifndef SM_SAMPLING_H
#define SM_SAMPLING_H

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gnss_defs.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#define SM_SAMPLING_FREQUENCY       (15U) /*Hz*/
#define SM_SAMPLING_FREQ_MIN        (5U) /*Hz*/
#define SM_SAMPLING_FREQ_MAX        (150U) /*Hz*/
#define SM_SAMPLING_PERIOD          (1.0/SM_SAMPLING_FREQUENCY) /*s*/
#define SM_SAMPLING_PERIOD_TICKS    (tInt)(SM_SAMPLING_PERIOD * NAV_CPU_TICKS_PER_SECOND) /*ticks*/

/* number of messages in sampling queue */
#define SM_SAMPLING_NUM_OF_MSGS 1
/*****************************************************************************
   typedefs and structures
*****************************************************************************/
typedef enum
{
  SM_SAMPLING_SUSPENDED,
  SM_SAMPLING_RUNNING
} sm_sampling_state_t;

typedef struct sm_sampling_manager_s
{
  gpOS_message_queue_t * msg_queue;
  sm_sampling_state_t   state;
} sm_sampling_manager_t;

/*{{{  sm_sampling_msg_type_t*/
typedef enum sm_sampling_msg_type_e
{
  SM_SAMPLING_RUN_CMD,
  SM_SAMPLING_SUSPENDED_CMD
} sm_sampling_msg_type_t;

/*{{{  sm_sampling_message_t*/
typedef struct sm_sampling_message_s
{
  sm_sampling_msg_type_t type;
} sm_sampling_message_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t sm_sampling_init              ( const tUInt);
extern tUInt        sm_sampling_get_sampling_freq ( void);
extern gpOS_clock_t sm_sampling_get_period_ticks  ( void);
extern void         sm_sampling_suspend           ( void);
extern void         sm_sampling_resume            ( void);

#ifdef __cplusplus
}
#endif
#endif /* SM_SAMPLING_H */
