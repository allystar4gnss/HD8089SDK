/*!
 * dr_3dgyro.h
 * Defines the interface for DR 3Dgyro sampling.
 * \author Andrea Di Girolamo
 * \date 14/07/2011
 */
#ifndef DR_3DGYRO_H
#define DR_3DGYRO_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_bsp_defs.h"
#include "gnss_defs.h"
#include "lld_gpio.h"
#if defined(__STA8088__) || defined(__STA8090__)
#include "dr_combo_common.h"
#endif

/*****************************************************************************
   defines and macros
*****************************************************************************/

#define DR_3D6DGYRO_SAMPLING_FREQUENCY      (15) /*Hz*/
#define DR_3D6DGYRO_SAMPLING_PERIOD         (1.0/DR_3D6DGYRO_SAMPLING_FREQUENCY) /*s*/
#define DR_3D6DGYRO_SAMPLING_PERIOD_TICKS   (tInt)(DR_3D6DGYRO_SAMPLING_PERIOD * NAV_CPU_TICKS_PER_SECOND) /*ticks*/
#define NUM_DR_3D6DGYRO_MSGS                (5 * DR_3DG6DYRO_SAMPLING_FREQUENCY)

#define DR_3D6DGYRO_WHO_AM_I                0x0FU

#define DR_3DGYRO_ID                        0xD4U
#define DR_3DGYRO_ID_1                      0xD3U   //A3G4250D
#define DR_6DGYRO_ID_ASM330LXH              0x61U   //ASM330LXH
#define DR_6DGYRO_ID_LSM6DS3                0x69U   //LSM6DS3
#define DR_6DGYRO_ID_LSM6DSM                0x6AU   //LSM6DSM

#define DR_3DGYRO_CTRL_REG1                 0x20U
#define DR_3DGYRO_NORNAL_MODE_ENABLE        0x08U   /*(1<<3)*/
#define DR_3DGYRO_OUT_TEMP_ADDRESS          0x26U
#define DR_3DGYRO_OUT_X_L_ADDRESS           0x28U
#define DR_3DGYRO_INCREMENT_ADDRESS         0x40U

#define DR_3D6DGYRO_READ_OPERATION          0x80U

// A3G4250
#define DR_3DGYRO_TEMP_RANGE_OFFSET         128 // Value to be substracted to temperature value to fit the fp conversion macro range

#define DR_3DGYRO_SPI_READ_COMMAND_BYTE             (DR_3DGYRO_OUT_X_L_ADDRESS | DR_3D6DGYRO_READ_OPERATION | DR_3DGYRO_INCREMENT_ADDRESS)
#define DR_3DGYRO_SPI_READ_TEMP_COMMAND_BYTE        (DR_3DGYRO_OUT_TEMP_ADDRESS | DR_3D6DGYRO_READ_OPERATION)
#define DR_6DGYRO_SPI_READ_COMMAD_BYTE              (DR_6DGYRO_OUT_X_G_ADDRESS | DR_3D6DGYRO_READ_OPERATION )
#define DR_6DGYRO_SPI_READ_TEMP_COMMAND_BYTE        (DR_6DGYRO_OUT_TEMP_ADDRESS | DR_3D6DGYRO_READ_OPERATION )
#if defined(__STA8088__) || defined(__STA8090__)
#define DR_6DGYRO_BOSCH_SPI_READ_COMMAND_BYTE       (DR_COMBO_BMI160_GYR_OUT_X_L_ADDRESS | DR_3D6DGYRO_READ_OPERATION )
#define DR_6DGYRO_BOSCH_SPI_READ_TEMP_COMMAND_BYTE  (DR_COMBO_BMI160_TEMP_ADDRESS | DR_3D6DGYRO_READ_OPERATION )
#endif

#define DR_3DGYRO_SLAVE_ADDR                0x68U
#define DR_3DGYRO_I2C_AUTO_INC_MASK         0x80U  /* Register address in automatically incremented to allow multiple data r/w */

#define DR_3D6DGYRO_SPI_BUS_TYPE            0x00U
#define DR_3D6DGYRO_I2C_BUS_TYPE            0x01U

#define DR_ST_MEMS_3DGYRO_TYPE              0x00U
#define DR_ST_MEMS_6DGYRO_ASM330XLH_TYPE    0x01U
#define DR_ST_MEMS_6DGYRO_LSM6DS3_TYPE      0x02U
#define DR_MEMS_6DGYRO_BMI160_TYPE          0x03U
#define DR_ST_MEMS_6DGYRO_LSM6DSM_TYPE      0x04U


#define DR_3D6DGYRO_SPI_ID                  0
#define DR_3D6DGYRO_SPI_INT_PRIORITY        10


#define DR_3DGYRO_SPI_GPIO_ADDR       (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define DR_3DGYRO_SPI_CS_PIN          LLD_GPIO_PIN18
#define DR_3DGYRO_SPI_CS_PIN_MODE     LLD_GPIO_MODE_ALTA
#define DR_3D6DGYRO_SPI_BUS_FREQUENCY 1000000
#define DR_3DGYRO_SCALING_FACTOR      (-0.00009)
#define DR_3DGYRO_OFFSET              (1.47)
#define DR_3D6DGYRO_CONF_GPIO_MASK    0x3f
#define DR_3D6DGYRO_NOT_CONFIG        ((tU32)0xffffffffU)
#define DR_3D6DGYRO_GPIO0_LAST_CH     (32)
#define DR_3D6DGYRO_GPIO1_LAST_CH     LLD_GPIOCHUNDEF

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct dr_3Dgyro_msg_tag
{
  gpOS_clock_t  gyro_3D_cpu_time;
  tU16          gyro_3D_x_data;
  tU16          gyro_3D_y_data;
  tU16          gyro_3D_z_data;
  tInt          odo_count;
  fp_s16_t      gyro_3D_temp;
  tU8           reverse;
} dr_3Dgyro_sample_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

extern tU8 dr_3D6Dgyro_type;
extern tU8 dr_3D6Dgyro_bus_type;

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t dr_3D6Dgyro_init            ( tUInt operating_mode, tU8 bus_type, tU8 SA0, tU8 i2c_SlaveAd_conf);
extern gnss_error_t dr_3D6Dgyro_CS_init         ( tU8 bus_type, tU8 cs_gpio_conf, tU8 cs_pullup);
extern gpOS_error_t dr_3Dgyro_receive_sample    ( dr_3Dgyro_sample_t *msg);
extern void         dr_3Dgyro_enable_solution   ( boolean_t onoff);
extern void         dr_3Dgyro_enable_log        ( boolean_t onoff);
extern void         dr_3Dgyro_capture_sample    ( void);
extern void         dr_3Dgyro_set_gyro_polarity_inversion(boolean_t onoff);

#ifdef __cplusplus
}
#endif

#endif /* DR_3DGYRO_H */
