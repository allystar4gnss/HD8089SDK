/*!
 * dr_gyro.h
 * Defines the interface to the DR GYRO driver abstraction module.
 * \author Andrea Di Girolamo
 * \date 24/05/2011
 */
#ifndef DR_GYRO_H
#define DR_GYRO_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#define DR_ADC_SCALING_FACTOR      (0.0032)

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

typedef struct dr_analog_msg_tag
{
  gpOS_clock_t    cpu_time;
  tInt            gyro_volts;
  tInt            odo_count;
	tU8  reverse;
} dr_analog_sample_t;

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t dr_adc_init                           ( void);
extern gnss_error_t dr_gyro_init                          ( gpOS_partition_t *part, tUInt operating_mode);
//extern tDouble dr_gyro_get_sample(void);
extern tUInt        dr_gyro_get_sample                    ( void);
extern void         dr_analog_capture_sample              ( void);
extern gpOS_error_t dr_analog_receive_sample              ( dr_analog_sample_t *sample);
extern void         dr_analog_enable_solution             ( boolean_t onoff);
extern void         dr_analog_set_gyro_polarity_inversion ( boolean_t onoff);
extern void         dr_analog_set_rev_polarity_inversion  ( boolean_t onoff);

#ifdef __cplusplus
}
#endif

#endif /* DR_GYRO_H */
