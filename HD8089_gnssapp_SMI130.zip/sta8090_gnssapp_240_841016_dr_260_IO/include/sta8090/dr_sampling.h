/*!
 * dr_sampling.h
 */
#ifndef DR_SAMPLING_H
#define DR_SAMPLING_H

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "dr_sensors.h"
#include "gnss_defs.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#define DR_SAMPLING_FREQUENCY       (15U) /*Hz*/
#define DR_SAMPLING_FREQ_MIN        (5U) /*Hz*/
#define DR_SAMPLING_FREQ_MAX        (20U) /*Hz*/
#define DR_SAMPLING_PERIOD          (1.0/DR_SAMPLING_FREQUENCY) /*s*/
#define DR_SAMPLING_PERIOD_TICKS    (tInt)(DR_SAMPLING_PERIOD * NAV_CPU_TICKS_PER_SECOND) /*ticks*/

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t dr_sampling_init              ( const tUInt);
extern tUInt        dr_sampling_get_sampling_freq ( void);
extern gpOS_clock_t dr_sampling_get_period_ticks  ( void);

#ifdef __cplusplus
}
#endif
#endif /* DR_SAMPLING_H */
