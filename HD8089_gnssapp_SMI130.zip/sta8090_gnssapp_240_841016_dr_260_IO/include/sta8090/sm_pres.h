/*!
 * sm_pres.h
 * Defines the interface for Pressure sensor.  Introduce for STA8090EXG
 */
#ifndef SM_PRES_H
#define SM_PRES_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "slld_api.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define SM_PRES_DATA_MASK               0x00ffffffU
#define SM_PRES_DEFAULT_RESOLUTION      4096U

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gpOS_error_t   sm_pres_receive_sample  ( slld_Pres_sample_t *);
extern void           sm_Pres_capture_sample  ( void);

#ifdef __cplusplus
}
#endif

#endif /* SM_PRES_H */
