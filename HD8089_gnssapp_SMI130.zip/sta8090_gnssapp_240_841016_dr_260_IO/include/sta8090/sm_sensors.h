/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : sm_sensors.h
Author :

 sensor management typedef and exported API

Date        Modification                                    Initials
----        ------------                                    --------
************************************************************************/
/*!
 * @file    sm_sensors.h
 * @brief   sensor management typedef
 */
#ifndef SM_SENSORS_H
#define SM_SENSORS_H

/*****************************************************************************
   includes
*****************************************************************************/
#include "sm_combo_common.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define SM_CAN_MAX_INPUT_MSG            10
#define SM_DUMMY_PULSES_PER_METER           50

/* Odometer Types */
#define SM_SENSORS_ANALOG_ODOMETER_TYPE     0x0U
#define SM_SENSORS_CAN_ODOMETER_TYPE        0x1U
#define SM_SENSORS_CAN_SPEED_TYPE           0x2U
#define SM_SENSORS_CAN_DWP_TYPE             0x3U

/* Operating Modes */
#define SM_SENSORS_GYRO_ODO_REV_MODE            0x0
#define SM_SENSORS_3DGYRO_ODO_REV_MODE          0x1
#define SM_SENSORS_GYRO_CAN_ODO_REV_MODE        0x2
#define SM_SENSORS_3DGYRO_CAN_ODO_REV_MODE      0x3
#define SM_SENSORS_GYRO_CAN_SPEED_MODE          0x4
#define SM_SENSORS_3DGYRO_CAN_SPEED_MODE        0x5
#define SM_SENSORS_CAN_GYRO_CAN_ODO_REV_MODE    0x6
#define SM_SENSORS_CAN_GYRO_CAN_SPEED_MODE      0x7
#define SM_SENSORS_DWP_2W_MODE                  0x8
#define SM_SENSORS_DWP_2W_REV_MODE              0x9
#define SM_SENSORS_DWP_4W_MODE                  0xA
#define SM_SENSORS_DWP_4W_REV_MODE              0xB
#define SM_SENSORS_GYRO_CAN_SPEED_RX_MODE       0xC
#define SM_SENSORS_3DGYRO_CAN_SPEED_RX_MODE     0xD
#define SM_SENSORS_CAN_GYRO_CAN_SPEED_RX_MODE   0xE
#define SM_SENSORS_CAN_GYRO_CAN_DWP             0xF
#define SM_SENSORS_CAN_GYRO_CAN_DWP_SPEED_MODE  0x14
#define SM_SENSORS_DWP_2W_SPEED_MODE            0x10
#define SM_SENSORS_DWP_2W_REV_SPEED_MODE        0x11
#define SM_SENSORS_DWP_4W_SPEED_MODE            0x12
#define SM_SENSORS_DWP_4W_REV_SPEED_MODE        0x13
#define SM_SENSORS_3DGYRO_CAN_DWP_SPEED_MODE    0x15
/* Default Operating mode */
#define SM_SENSORS_OM_ONLY_MEMS                 0xFFFF


/* Sensor messages IDs */
#define SM_ODO_DATA_MSG_ID                  0x1
#define SM_REV_DATA_MSG_ID                  0x2
#define SM_ODO_REV_DATA_MSG_ID              0x3
#define SM_GYRO_DATA_MSG_ID                 0x4
#define SM_GYRO_ODO_REV_DATA_MSG_ID         0x5
#define SM_DWP_ODO_MSG_ID                   0x6
#define SM_DWP_2W_F_DATA_MSG_ID             0x7
#define SM_DWP_2W_F_REV_DATA_MSG_ID         0x8
#define SM_DWP_2W_R_DATA_MSG_ID             0x9
#define SM_DWP_2W_R_REV_DATA_MSG_ID         0xA
#define SM_DWP_4W_DATA_MSG_ID               0xB
#define SM_DWP_4W_REV_DATA_MSG_ID           0xC
#define SM_IGNITION_DATA_MSG_ID             0xD
#define SM_SPEED_DATA_MSG_ID                0xE

#define SM_DWP_ODO_SPEED_MSG_ID             0xF
#define SM_DWP_2W_F_SPEED_DATA_MSG_ID       0x10
#define SM_DWP_2W_F_REV_SPEED_DATA_MSG_ID   0x11
#define SM_DWP_2W_R_SPEED_DATA_MSG_ID       0x12
#define SM_DWP_2W_R_REV_SPEED_DATA_MSG_ID   0x13
#define SM_DWP_4W_SPEED_DATA_MSG_ID         0x15
#define SM_DWP_4W_REV_SPEED_DATA_MSG_ID     0x16

#define SM_TEMPERATURE_MSG_ID               0x18

#define SM_3A_ACC_DATA_MSG_ID               0x1E
#define SM_3A_GYRO_DATA_MSG_ID              0x1F
#define SM_PRES_DATA_MSG_ID                 0x20
#define SM_MOUNT_ANGLES_DATA_MSG_ID         0x28

#define SM_RESET_ODO_COUNTER_MSG_ID         0x30

/*****************************************************************************
   typedefs and structures
*****************************************************************************/
/*{{{ Typedefs*/
typedef enum sm_sensor_type_e
{
  GYRO2           = 2,
  GYRO3           = 3,
  DWP_GYRO        = 4,
  CAN_GYRO        = 5
} sm_sensor_type_t;

typedef enum sm_sensors_imu_type_tag
{
  SM_SENSORS_IMU_UNKNOWN          =  0U,
  SM_SENSORS_IMU_3_PLUS_3_GENERIC =  1U,
  SM_SENSORS_IMU_3_PLUS_3_T2_EVB  =  2U,
  SM_SENSORS_IMU_3_PLUS_3_T2_SDB  =  3U,
  SM_SENSORS_IMU_3_PLUS_3_T3_EVB  =  4U,
  SM_SENSORS_IMU_3_PLUS_3_T3_SDB  =  5U,
  SM_SENSORS_IMU_ASM330LXH        =  6U,
  SM_SENSORS_IMU_LSM6DS3          =  7U,
  SM_SENSORS_IMU_BMI160           =  8U, // NOTE: Reference to Bosch sensors can or cannot be made explicit in the released source code? (ask marketing)
  SM_SENSORS_IMU_A3G4250D_ONLY    =  9U,
  SM_SENSORS_IMU_LSM6DSM          = 10U,
  SM_SENSORS_IMU_LSM6DSR          = 11U,
  SM_SENSORS_IMU_SMI130           = 12U,
  SM_SENSORS_IMU_ENUM_MAX_VAL     = 13U
} sm_sensors_imu_type;

typedef struct sm_imu_config_s
{
  tUInt installation_yaw          :  9;
  tUInt installation_roll         :  9;
  tUInt installation_pitch        :  9;
  tUInt spare1                    :  5;
  tUInt match_gyro_z_axis         :  4;
  tUInt match_gyro_y_axis         :  4;
  tUInt match_gyro_x_axis         :  4;
  tUInt match_acc_z_axis          :  4;
  tUInt match_acc_y_axis          :  4;
  tUInt match_acc_x_axis          :  4;
  sm_sensors_imu_type imu_type    :  8;
} sm_sensors_imu_config_t;


typedef struct sm_can_msg_parms_tag
{
  tUInt msg_obj;
  tUInt msg_id;
  tUInt msg_mask;
}sm_can_msg_parms_t;

typedef struct sm_can_msg_config_tag
{
  tInt                n_messages;
  sm_can_msg_parms_t  msg_params[SM_CAN_MAX_INPUT_MSG];
}sm_can_msg_config_t;

typedef struct sm_can_gyro_setting_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 4;
  tUInt msbyte     : 4;
  tUInt bitmask    : 16;
}sm_can_gyro_setting_t;

typedef struct sm_can_dwp_odo_setting_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 4;
  tUInt msbyte     : 4;
  tUInt bitmask    : 16;
}sm_can_dwp_odo_setting_t;

typedef struct sm_can_dwp_odo_validity_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 8;
  tUInt bitmask    : 8;
  tUInt logic      : 8;
}sm_can_dwp_odo_validity_t;

typedef struct sm_can_dwp_params_tag
{
  tUInt dwp_counter_max_value      : 16;
  tUInt dwp_speed_resolution       : 14;
  tUInt dwp_speed_unit             : 2;
} sm_can_dwp_params_t;

typedef struct sm_can_dwp_rev_setting_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 8;
  tUInt bitmask    : 8;
  tUInt logic      : 8;
}sm_can_dwp_rev_setting_t;

typedef struct sm_can_dwp_rev_validity_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 8;
  tUInt bitmask    : 8;
  tUInt logic      : 8;
}sm_can_dwp_rev_validity_t;

typedef struct sm_can_spd_pid_setting_tag
{
  tUInt msg_obj    : 8;
  tUInt lsbyte     : 8;
  tUInt bitmask    : 8;
  tUInt spare      : 8;
}sm_can_spd_pid_setting_t;

typedef struct sm_can_filtering_setting_tag
{
  sm_can_dwp_odo_setting_t      dwp_odo_front_left;
  sm_can_dwp_odo_validity_t     dwp_odo_front_left_val;
  sm_can_dwp_odo_setting_t      dwp_odo_front_right;
  sm_can_dwp_odo_validity_t     dwp_odo_front_right_val;
  sm_can_dwp_odo_setting_t      dwp_odo_rear_left;
  sm_can_dwp_odo_validity_t     dwp_odo_rear_left_val;
  sm_can_dwp_odo_setting_t      dwp_odo_rear_right;
  sm_can_dwp_odo_validity_t     dwp_odo_rear_right_val;
  sm_can_dwp_rev_setting_t      dwp_front_left_rev;
  sm_can_dwp_rev_validity_t     dwp_front_left_rev_val;
  sm_can_dwp_rev_setting_t      dwp_front_right_rev;
  sm_can_dwp_rev_validity_t     dwp_front_right_rev_val;
  sm_can_dwp_rev_setting_t      dwp_rear_left_rev;
  sm_can_dwp_rev_validity_t     dwp_rear_left_rev_val;
  sm_can_dwp_rev_setting_t      dwp_rear_right_rev;
  sm_can_dwp_rev_validity_t     dwp_rear_right_rev_val;
  sm_can_dwp_params_t			      dwp;
  sm_can_gyro_setting_t         gyro;
  sm_can_spd_pid_setting_t      spd_pid;
}sm_can_filtering_setting_t;

typedef struct sm_can_car_parameters_tag
{
  tUInt tire_circ_mm  : 12;
  tUInt track_mm      : 12;
  tUInt ticks_per_rev : 8;
}sm_can_car_parameters_t;

typedef struct sm_can_gyro_parameters_tag
{
  tUInt gyro_msg_rate   : 8;
  tUInt gyro_adc_res    : 4;
  tUInt gyro_sign_bit   : 4;
  tUInt gyro_raw_offset : 16;
}sm_can_gyro_parameters_t;

typedef struct sm_can_config_tag
{
  tUInt                       car_maker_id;
  tUInt                       can_baudrate;
  sm_can_msg_config_t         msg_config;
  sm_can_filtering_setting_t  can_filtering;
  sm_can_car_parameters_t     car_params;
  sm_can_gyro_parameters_t    gyro_params;
} sm_can_config_t;

typedef struct sm_kal_config_s
{
  tUInt   p_odo_scale               : 32;
  tUInt   q_odo_scale               : 32;
  tUInt   p_gyro_offset             : 32;
  tUInt   q_gyro_offset             : 32;
  tUInt   p_gyro_gain               : 32;
  tUInt   q_gyro_gain               : 32;
  tUInt   max_cn0_noise             : 14;
  tUInt   spare1                    :  2;
  tUInt   gnss_cn0_thr              :  6;
  tUInt   spare2                    : 10;
  tUInt   odo_scale_lock            :  1;
  tUInt   gyro_offset_lock          :  1;
  tUInt   gyro_gain_lock            :  1;
  tUInt   gyro_offset_static_cal    :  1;
  tUInt   ovst_calibration          :  2;
  tUInt   auto_tilt_enable          :  1;
  tUInt   dr_vfb_enable             :  1;
  tUInt   mmfb_enable               :  1;
  tUInt   gtd_enable                :  1;
  tUInt   dr_3d_enable              :  1;
  tUInt   spare3                    : 17;
  tUInt   dr_ahrs_quat_mech_enable  :  1;
  tUInt   DrNvmSave_stop_disable    :  1;
  tUInt   gyro_gain_cal_fix_disable :  1;
  tUInt   gyro_int_stop_disable     :  1;
} dr_kal_config_t;

typedef struct sm_meas_weight_cfg_s
{
  tUInt   pos_filter_weight         : 32;
  tUInt   heading_filter_weight     : 32;
  tUInt   height_filter_weight      : 32;
  tUInt   vert_vel_filter_weight    : 32;
} dr_meas_weight_cfg_t;

typedef struct sm_sensors_config_s
{
  tUInt   enable_analog           :  1;
  tUInt   enable_3Dgyro           :  1;
  tUInt   enable_3Dacc            :  1;
  tUInt   enable_can              :  1;
  tUInt   enable_pressure         :  1;
  tUInt   enable_magn             :  1;
  tUInt   spare1                  :  2;
  tUInt   operating_mode          :  8;
  tUInt   bus_type                :  1;
  tUInt   SA0_3Dgyro              :  1;
  tUInt   SA0_3Dacc               :  1;
  tUInt   can_port                :  1;
  tUInt   sm_fix_rate             :  4;
  tUInt   sm_sampling_rate        :  7;
/*  tUInt   pnmea_msg_disable       :  1;*/
  tUInt   sm_msg_disable          :  1;

  sm_can_config_t           can_config;

  tUInt   odo_scale_enable        :  1;
  tUInt   gyro_offset_enable      :  1;
  tUInt   gyro_gain_enable        :  1;
  tUInt   rev_invertion           :  1;
  tUInt   gyro_invertion          :  1;
  tUInt   gyro_offset_vs_temp     : 11;
  tUInt   odo_gpio_config         :  8;
  tUInt   rev_gpio_config         :  8;
  tUInt   odo_scale               : 32;
  tUInt   gyro_offset             : 32;
  tUInt   gyro_gain               : 32;
  tUInt   sens_en                 :  1;
  tUInt   sens_buf_size           : 11;
  tUInt   CAN_buf_size            : 12;
  tUInt   spare4                  :  5;
  tUInt   en_3dgyro_log           :  1;
  tUInt   en_3dacc_log            :  1;
  tUInt   en_can_log              :  1;

  dr_kal_config_t           dr_kal_config;
  sm_sensors_imu_config_t   sm_sensors_imu_config;

  tUInt   cs_3Dgyro_gpio_conf     :  8;
  tUInt   cs_3Dacc_gpio_conf      :  8;
  tUInt   cs_3Dgyro_gpio_cspullup :  1;
  tUInt   cs_3Dacc_gpio_cspullup  :  1;
  tUInt   spare5                  : 14;
  tUInt   acc_res                 : 32;
  tUInt   gyro_i2c_SlaveAd_conf   :  8;
  tUInt   acc_i2c_SlaveAd_conf    :  8;
  tUInt   magn_i2c_SlaveAd_conf   :  8;
  tUInt   pres_i2c_SlaveAd_conf   :  8;
  tUInt   cs_magn_gpio_conf       :  8;
  tUInt   cs_pres_gpio_conf       :  8;
  tUInt   cs_magn_gpio_cspullup   :  1;
  tUInt   cs_pres_gpio_cspullup   :  1;
  tUInt   spare7                  : 14;

  sm_raw_sensors_config_t   sensors_raw_req;

  tUInt   pres_sensitivity        : 32;

  dr_meas_weight_cfg_t      dr_meas_weight;
} sm_sensors_config_t;

typedef struct sm_odo_data_s
{
  tUInt       counter;
} sm_odo_data_t;

typedef struct sm_rev_data_s
{
  boolean_t   status;
} sm_rev_data_t;

typedef struct sm_odo_rev_data_s
{
  tUInt       odo_counter;
  boolean_t   rev_status;
} sm_odo_rev_data_t;

typedef struct sm_gyro_data_s
{
  tU16        volts;
} sm_gyro_data_t;

typedef struct sm_gyro_odo_rev_data_s
{
  tU16        gyro_volts;
  tUInt       odo_counter;
  boolean_t   rev_status;
} sm_gyro_odo_rev_data_t;

typedef struct sm_speed_data_s
{
  tDouble     value_kmh;
} sm_speed_data_t;

typedef struct sm_dwp_odo_s
{
  tUInt       left_wheel;
  tUInt       right_wheel;
  tUInt       left_wheel_speed;
  tUInt       right_wheel_speed;
} sm_dwp_odo_data_t;

typedef struct sm_dwp_2w_data_s
{
  tUInt       left_wheel;
  tUInt       right_wheel;
  tUInt       left_wheel_speed;
  tUInt       right_wheel_speed;
} sm_dwp_2w_data_t;

typedef struct sm_dwp_4w_data_s
{
  tUInt       front_left_wheel;
  tUInt       front_right_wheel;
  tUInt       rear_left_wheel;
  tUInt       rear_right_wheel;
  tUInt       front_left_wheel_speed;
  tUInt       front_right_wheel_speed;
  tUInt       rear_left_wheel_speed;
  tUInt       rear_right_wheel_speed;
} sm_dwp_4w_data_t;

typedef struct sm_dwp_2w_rev_data_s
{
  tUInt       left_wheel;
  tUInt       right_wheel;
  tUInt       left_wheel_speed;
  tUInt       right_wheel_speed;
  boolean_t   left_wheel_dir;
  boolean_t   right_wheel_dir;
} sm_dwp_2w_rev_data_t;

typedef struct sm_dwp_4w_rev_data_s
{
  tUInt       front_left_wheel;
  tUInt       front_right_wheel;
  tUInt       rear_left_wheel;
  tUInt       rear_right_wheel;
  tUInt       front_left_wheel_speed;
  tUInt       front_right_wheel_speed;
  tUInt       rear_left_wheel_speed;
  tUInt       rear_right_wheel_speed;
  boolean_t   front_left_wheel_dir;
  boolean_t   front_right_wheel_dir;
  boolean_t   rear_left_wheel_dir;
  boolean_t   rear_right_wheel_dir;
} sm_dwp_4w_rev_data_t;

typedef struct sm_ignition_data_s
{
  tUInt       cpu_time;
  tUInt       status;
} sm_ignition_data_t;


typedef struct sm_temperature_data_s
{
  tUInt       cpu_time;
  tInt        value;
  boolean_t   validity;
} sm_temperature_data_t;

typedef struct sm_3axis_gyro_data_s
{
  tInt        xvolts;
  tInt        yvolts;
  tInt        zvolts;
} sm_3axis_gyro_data_t;

typedef struct sm_3axis_acc_data_s
{
  tInt        xvolts;
  tInt        yvolts;
  tInt        zvolts;
} sm_3axis_acc_data_t;

typedef struct sm_pres_data_s
{
  tU32        pressure;
} sm_pres_data_t;

typedef struct sm_installation_angle_data_s
{
  tInt        roll;
  tInt        pitch;
  tInt        yaw;
} sm_installation_angle_data_t;

typedef struct sm_sensors_msg_s
{
  tUInt             msg_id;
  gpOS_clock_t      cpu_time;
  union
  {
    sm_odo_data_t                 odo;
    sm_rev_data_t                 rev;
    sm_odo_rev_data_t             odo_rev;
    sm_gyro_data_t                gyro;
    sm_gyro_odo_rev_data_t        gyro_odo_rev;
    sm_dwp_odo_data_t             dwp_odo;
    sm_dwp_2w_data_t              dwp_2w;
    sm_dwp_4w_data_t              dwp_4w;
    sm_dwp_2w_rev_data_t          dwp_2w_rev;
    sm_dwp_4w_rev_data_t          dwp_4w_rev;
    sm_ignition_data_t            ignition;
    sm_temperature_data_t         temperature;
    sm_speed_data_t               speed;
    sm_3axis_acc_data_t           acc_3a;
    sm_3axis_gyro_data_t          gyro_3a;
    sm_installation_angle_data_t  mount_angles;
    sm_pres_data_t                pres;
  } msg_data;
} sm_sensors_msg_t;


/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
/*{{{ Function Decls*/

#endif

