/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : dr_sensor_api.h
Author :

DR sensor management typedef and exported API

Date        Modification                                    Initials
----        ------------                                    --------
************************************************************************/
/*!
 * @file    dr_sensor_api.h
 * @brief   DR sensor management typedef and exported API
 */
#ifndef DR_SENSORS_API_H
#define DR_SENSORS_API_H

/*****************************************************************************
   includes
*****************************************************************************/
#include "dr_api.h"
#include "dr_can.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/
#define DR_FIFO_MSG_PAYLOAD                         27U             // The Max size for the 6x Fifo is 15. Depends on the FW Config param 674 (sensors_raw_req)! see dr_fifo_info.number_elements_in_Fifo to deduce the max size
#define DR_SENSORS_ODO_SCALE_INIT_VALUE             ( 0.0229  )     //[m/tick]

/*****************************************************************************
   typedefs and structures
*****************************************************************************/
/*{{{ Typedefs*/
typedef enum dr_sensors_imu_type_tag
{
  DR_SENSORS_IMU_UNKNOWN          =  0U,
  DR_SENSORS_IMU_3_PLUS_3_GENERIC =  1U,
  DR_SENSORS_IMU_3_PLUS_3_T2_EVB  =  2U,
  DR_SENSORS_IMU_3_PLUS_3_T2_SDB  =  3U,
  DR_SENSORS_IMU_3_PLUS_3_T3_EVB  =  4U,
  DR_SENSORS_IMU_3_PLUS_3_T3_SDB  =  5U,
  DR_SENSORS_IMU_ASM330LXH        =  6U,
  DR_SENSORS_IMU_LSM6DS3          =  7U,
  DR_SENSORS_IMU_BMI160           =  8U, // NOTE: Reference to Bosch sensors can or cannot be made explicit in the released source code? (ask marketing)
  DR_SENSORS_IMU_A3G4250D_ONLY    =  9U,
  DR_SENSORS_IMU_LSM6DSM          = 10U,
  DR_SENSORS_IMU_ENUM_MAX_VAL     = 11U
} dr_sensors_imu_type;

typedef struct dr_imu_config_s
{
  tUInt installation_yaw          :  9;
  tUInt installation_roll         :  9;
  tUInt installation_pitch        :  9;
  tUInt spare1                    :  5;
  tUInt match_gyro_z_axis         :  4;
  tUInt match_gyro_y_axis         :  4;
  tUInt match_gyro_x_axis         :  4;
  tUInt match_acc_z_axis          :  4;
  tUInt match_acc_y_axis          :  4;
  tUInt match_acc_x_axis          :  4;
  dr_sensors_imu_type imu_type    :  8;
} dr_sensors_imu_config_t;

typedef struct  dr_raw_sensors_config_s{
  tUInt   raw_data_type_req       :  4;
  tUInt   dr_sensors_id           :  4;
  tUInt   odr_fifo_acc            :  8;
  tUInt   odr_fifo_gyro           :  8;
  tUInt   spare                   :  6;
  tUInt   Speed_odo_RealTime      :  1;
  tUInt   Mems_RealTime           :  1;
 } dr_raw_sensors_config_t;

typedef struct dr_sensors_config_s
{
  tUInt   enable_analog           :  1;
  tUInt   enable_3Dgyro           :  1;
  tUInt   enable_3Dacc            :  1;
  tUInt   enable_can              :  1;
  tUInt   enable_pressure         :  1;
  tUInt   spare1                  :  3;
  tUInt   operating_mode          :  8;
  tUInt   bus_type                :  1;
  tUInt   SA0_3Dgyro              :  1;
  tUInt   SA0_3Dacc               :  1;
  tUInt   can_port                :  1;
  tUInt   dr_fix_rate             :  4;
  tUInt   dr_sampling_rate        :  5;
  tUInt   spare2                  :  1;
  tUInt   pnmea_msg_disable       :  1;
  tUInt   dr_msg_disable          :  1;

  dr_can_config_t           can_config;

  tUInt   odo_scale_enable        :  1;
  tUInt   gyro_offset_enable      :  1;
  tUInt   gyro_gain_enable        :  1;
  tUInt   rev_invertion           :  1;
  tUInt   gyro_invertion          :  1;
  tUInt   gyro_offset_vs_temp     : 11;
  tUInt   odo_gpio_config         :  8;
  tUInt   rev_gpio_config         :  8;
  tUInt   odo_scale               : 32;
  tUInt   gyro_offset             : 32;
  tUInt   gyro_gain               : 32;
  tUInt   sens_en                 :  1;
  tUInt   sens_buf_size           : 11;
  tUInt   CAN_buf_size            : 12;
  tUInt   spare4                  :  5;
  tUInt   en_3dgyro_log           :  1;
  tUInt   en_3dacc_log            :  1;
  tUInt   en_can_log              :  1;

  dr_kal_config_t           dr_kal_config;
  dr_sensors_imu_config_t   dr_sensors_imu_config;

  tUInt   cs_3Dgyro_gpio_conf     :  8;
  tUInt   cs_3Dacc_gpio_conf      :  8;
  tUInt   cs_3Dgyro_gpio_cspullup :  1;
  tUInt   cs_3Dacc_gpio_cspullup  :  1;
  tUInt   spare5                  : 14;
  tUInt   acc_res                 : 32;
  tUInt   gyro_i2c_SlaveAd_conf   :  8;
  tUInt   acc_i2c_SlaveAd_conf    :  8;
  tUInt   magn_i2c_SlaveAd_conf   :  8;
  tUInt   pres_i2c_SlaveAd_conf   :  8;
  tUInt   cs_magn_gpio_conf       :  8;
  tUInt   cs_pres_gpio_conf       :  8;
  tUInt   cs_magn_gpio_cspullup   :  1;
  tUInt   cs_pres_gpio_cspullup   :  1;
  tUInt   spare7                  : 14;

  dr_raw_sensors_config_t   sensors_raw_req;

  tUInt   pres_sensitivity        : 32;

  dr_meas_weight_cfg_t      dr_meas_weight;
} dr_sensors_config_t;


typedef enum dr_fifo_pattern_tag
{
  DR_ACC_XYZ = 0U,
  DR_GYRO_XYZ_ACC_XYZ,
  DR_GYRO_XYZ
} dr_fifo_pattern_t;

typedef struct dr_fifo_msg_tag
{
  gpOS_clock_t        first_elem_cpu_time;
  tU16                fifo_buf[DR_FIFO_MSG_PAYLOAD];
  tU8                 number_words_fifo_read;
  dr_fifo_pattern_t   fifo_pattern;
} dr_fifo_msg_t;


/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
/*{{{ Function Decls*/
/* INIT */
extern gnss_error_t dr_sensors_init                             ( const dr_sensors_config_t *dr_sensors_config);
extern gnss_error_t dr_sensors_init_p                           ( gpOS_partition_t *part, const dr_sensors_config_t *dr_sensors_config);
extern void         dr_sensors_init_default_sensors_parameters  ( const dr_sensors_config_t *dr_config_block_ptr);

/*CLASSIC GYRO/ODO/REV*/
extern tInt   dr_sensors_update_odo           ( const tUInt timestamp, const tUInt counter);
extern tInt   dr_sensors_update_rev           ( const tUInt timestamp, const boolean_t rev_status);
extern tInt   dr_sensors_update_odo_rev       ( const tUInt timestamp, const tUInt counter, const boolean_t status);
extern tInt   dr_sensors_update_gyro          ( const tUInt timestamp, const tU16 volts);
extern tInt   dr_sensors_update_gyro_odo_rev  ( const tUInt timestamp, const tU16 volts, const tUInt counter, const boolean_t status);

/* TEMPERATURE */
extern tInt   dr_sensors_update_temperature   ( const tUInt , const tInt , const boolean_t );

/* DWP TRAVELLED PATH */
extern tInt   dr_sensors_update_dwp_odo                 ( const tUInt, const tUInt, const tUInt);
extern tInt   dr_sensors_update_dwp_2w_front_wheels     ( const tUInt, const tUInt, const tUInt);
extern tInt   dr_sensors_update_dwp_2w_rear_wheels      ( const tUInt,  const tUInt, const tUInt);
extern tInt   dr_sensors_update_dwp_2w_rev_front_wheels ( const tUInt, const tUInt, const boolean_t,const tUInt, const boolean_t);
extern tInt   dr_sensors_update_dwp_2w_rev_rear_wheels  ( const tUInt, const tUInt, const boolean_t, const tUInt, const boolean_t);
extern tInt   dr_sensors_update_dwp_4w                  ( const tUInt, const tUInt, const tUInt, const tUInt, const tUInt);
extern tInt   dr_sensors_update_dwp_4w_rev              ( const tUInt, const tUInt, const boolean_t, const tUInt, const boolean_t, const tUInt, const boolean_t, const tUInt, const boolean_t);

/* DWP SPEED */
extern tInt   dr_sensors_update_dwp_odo_speed                 ( const tUInt, const tUInt, const tUInt);
extern tInt   dr_sensors_update_dwp_2w_front_wheels_speed     ( const tUInt, const tUInt, const tUInt);
extern tInt   dr_sensors_update_dwp_2w_rear_wheels_speed      ( const tUInt, const tUInt, const tUInt);
extern tInt   dr_sensors_update_dwp_2w_rev_front_wheels_speed ( const tUInt, const tUInt, const boolean_t,const tUInt, const boolean_t);
extern tInt   dr_sensors_update_dwp_2w_rev_rear_wheels_speed  ( const tUInt, const tUInt, const boolean_t, const tUInt, const boolean_t);
extern tInt   dr_sensors_update_dwp_4w_speed                  ( const tUInt, const tUInt, const tUInt, const tUInt, const tUInt);
extern tInt   dr_sensors_update_dwp_4w_rev_speed              ( const tUInt, const tUInt, const boolean_t, const tUInt, const boolean_t, const tUInt, const boolean_t, const tUInt, const boolean_t);

/* IGNITION */
extern tInt dr_sensors_update_ignition            ( const tUInt timestamp, const tUInt status);

/* SPEED PID */
extern tInt dr_sensors_update_speed               ( const tUInt timestamp, const tDouble speed);

/* MEMS */
extern tInt         dr_sensors_update_3axis_acc           ( const tUInt timestamp, const tInt xvolts, const tInt yvolts, const tInt zvolts);
extern tInt         dr_sensors_update_3axis_gyro          ( const tUInt timestamp, const tInt xvolts, const tInt yvolts, const tInt zvolts);
extern tInt         dr_sensors_update_installation_angles ( const tUInt timestamp, const  tInt phi, const  tInt theta, const  tInt psi);
extern gnss_error_t dr_sensors_update_pres                ( const tUInt timestamp, const tU32 pressure);

/* API BLOCKING */
extern void         dr_sensors_set_api_blocking_mode    ( const boolean_t blocking_mode);
extern boolean_t    dr_sensors_get_api_blocking_mode    ( void);

/* ODO SOURCE */
extern tU8          dr_sensors_get_odometer_source_type ( tUInt);

/* OPERATING MODE*/
extern void         dr_sensors_set_operating_mode       ( const tU8 operating_mode);
extern tU8          dr_sensors_get_operating_mode       ( void);
extern tUInt        dr_sensors_get_can_operating_mode   ( tUInt operating_mode);

extern void         dr_sensors_set_raw_data_req         ( const dr_raw_sensors_config_t raw_sensors_config );
extern void         dr_sensors_get_raw_data_req         ( dr_raw_sensors_config_t* raw_sensors_config );

/* LOGGING MASK */
extern void         dr_sensors_set_logging_mask         ( const tU8 logging_mask);
extern tU8          dr_sensors_get_logging_mask         ( void);

extern tUInt        dr_sensors_get_gyro_sensor_type     ( tUInt operating_mode);

extern void         dr_sensors_select                   ( tUInt );

/* ODO TICKS RESET */
extern gnss_error_t dr_sensors_reset_wheel_ticks_counter  ( const tUInt timestamp );
/*}}} */


#endif

