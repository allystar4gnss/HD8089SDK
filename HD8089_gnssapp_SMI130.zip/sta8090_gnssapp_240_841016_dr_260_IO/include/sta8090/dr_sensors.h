/************************************************************************
COPYRIGHT (C) STMicroelectronics 1998-2014

Source file name : dr_sensor.h
Author :Mark Griffiths

Defines the interface to the module responsible for handling DR sensors

Date        Modification                                    Initials
----        ------------                                    --------
************************************************************************/
/*!
 * @file    dr_sensor.h
 * @brief   Defines the interface to the module responsible for handling DR sensors
 */
#ifndef DR_SENSORS_H
#define DR_SENSORS_H

#ifdef __cplusplus
extern "C" {
#endif

/*****************************************************************************
   includes
*****************************************************************************/
#include "dr_defs.h"
#include "sm_sensors.h"
#include "sm_sensors_api.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#define DR_SENSORS_SAMPLING_FACTOR        1
#define DR_SENSORS_SAMPLING_FREQUENCY     DR_SAMPLING_FREQUENCY /* 15 Hz*/

#ifndef NAVIREPLAY
#define DR_SENSORS_BUFFERING_TIME         10 /*seconds*/
#else
#define DR_SENSORS_BUFFERING_TIME         50 /*seconds*/
#endif

#define DR_SAMPLE_BUFFER_SIZE             (DR_SENSORS_SAMPLING_FREQUENCY * DR_SENSORS_SAMPLING_FACTOR * DR_SENSORS_BUFFERING_TIME)
#define DR_SAMPLE_BUFFER_ROLLOVER         DR_SAMPLE_BUFFER_SIZE
#define SENSOR_SAMPLE_RATE_PER_SEC        15

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
/* External function declarations */
extern void           dr_sensor_data_enable_debug   ( const boolean_t );

#ifdef __cplusplus
}
#endif

#endif /* DR_SENSORS_H */
