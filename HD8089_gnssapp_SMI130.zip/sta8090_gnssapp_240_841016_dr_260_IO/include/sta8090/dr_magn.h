/*!
 * dr_magn.h
 * Defines the interface for Magnetometer.  Introduce for STA8090EXG
 */
#ifndef DR_MAGN_H
#define DR_MAGN_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_bsp_defs.h"
#include "gnss_defs.h"
#include "lld_gpio.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

#define DR_MAGN_SPI_ID            0
#define DR_MAGN_SPI_INT_PRIORITY  10


#define DR_MAGN_SPI_GPIO_ADDR     (LLD_GPIO_idTy)GPIO0_REG_START_ADDR
#define DR_MAGN_SPI_CS_PIN        LLD_GPIO_PIN0
#define DR_MAGN_SPI_CS_PIN_MODE   LLD_GPIO_MODE_SOFTWARE
#define DR_MAGN_SPI_BUS_FREQUENCY 1000000

#define DR_MAGN_CONF_GPIO_MASK    0x3f
#define DR_MAGN_GPIO0_LAST_CH     (32)
#define DR_MAGN_GPIO1_LAST_CH     LLD_GPIOCHUNDEF


/*****************************************************************************
   typedefs and structures
*****************************************************************************/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/

extern gnss_error_t dr_Magn_init    ( tU8 bus_type, tU8 SA0);
extern gnss_error_t dr_Magn_CS_init ( tU8 bus_type, tU8 cs_gpio_conf, tU8 cs_pullup);

#ifdef __cplusplus
}
#endif

#endif /* DR_MAGN_H */
