/*!
 * sm_ll_sens.h
 * Defines the interface for sm low latency sensor.
 */
#ifndef SM_LL_SENS_H
#define SM_LL_SENS_H

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
   includes
*****************************************************************************/

#include "gpOS.h"
#include "gnss_defs.h"
#include "gnss_bsp_defs.h"
#include "lld_gpio.h"
#include "sm_combo_common.h"

/*****************************************************************************
   defines and macros
*****************************************************************************/

/*****************************************************************************
   typedefs and structures
*****************************************************************************/

/*****************************************************************************
   exported variables
*****************************************************************************/

/*****************************************************************************
   exported function prototypes
*****************************************************************************/
extern boolean_t    sm_lowlatency_senmsg_read                ( sm_sensors_msg_t * );
extern void         sm_lowlatency_sens_SENMSG   ( const sm_sensors_msg_t *sm_sensors_msg);
extern gpOS_error_t sm_lowlatency_sensors_process_init( const sm_raw_sensors_config_t );
#ifdef __cplusplus
}
#endif

#endif /* SM_3DACC_H */
